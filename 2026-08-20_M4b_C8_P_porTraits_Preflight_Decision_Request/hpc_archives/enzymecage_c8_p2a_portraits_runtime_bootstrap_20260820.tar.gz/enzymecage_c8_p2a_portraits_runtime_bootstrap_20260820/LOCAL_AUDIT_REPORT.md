# Local Audit Report

## Boundary Compliance Checklist

| Question | Answer |
|----------|--------|
| Did this task avoid running porTraits? | YES — no porTraits prediction was run |
| Did this task avoid running nextflow run? | YES — only nextflow -version and nextflow help were run |
| Did this task avoid genome download? | YES — no genome FASTA downloaded |
| Did this task avoid model/database download? | YES — no databases downloaded |
| Did this task avoid installing Docker? | YES — Docker was not installed |
| Did this task avoid using sudo/apt/yum/dnf? | YES — only user-space Nextflow bootstrap was used |
| Did this task avoid patching porTraits code? | YES — code was only inspected, not patched |
| Did this task avoid production data mutation? | YES — no production data modified |
| Did this task avoid including fungi? | YES — no target list manipulation |
| Did this task avoid trait_score/hard_rejection? | YES — none emitted |
| Did this task avoid F5 prediction? | YES — no predictions of any kind |

## Scope Violation Check

No scope violations occurred. All hard boundaries were respected.

## What Was Resolved

1. **Nextflow 24.10.5** installed via user-space bootstrap (Java prerequisite was met)
2. **query_metatraits=none** confirmed supported in official latest v0.2.1 (default="none")
3. **porTraits official repository** cloned for version inspection

## What Remains Blocked

1. **Container runtime** — Singularity/Apptainer not available; requires admin/module installation
2. **porTraits model/database assets** — 0 of 10 found; requires teacher-authorized transfer
3. **Genome FASTA** — no local files; requires teacher-authorized download for smoke test
4. **Teacher approval** needed to switch from v0.1.7 to v0.2.1

## Tool Root

Installed at: /usrdata/EnzymeCAGE_data/tools/c8_p_portraits_runtime_20260820/
- nextflow/nextflow (Nextflow 24.10.5)
- source_probe/porTraits/ (cloned official repo, v0.2.1)

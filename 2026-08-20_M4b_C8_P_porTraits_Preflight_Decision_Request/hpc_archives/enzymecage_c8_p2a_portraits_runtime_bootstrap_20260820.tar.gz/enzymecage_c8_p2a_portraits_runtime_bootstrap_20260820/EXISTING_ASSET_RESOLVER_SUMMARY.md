# Existing Asset Resolver Summary

## Search Strategy

Searched the following roots for existing porTraits assets:
- `/usrdata` (NFS mount, 423T)
- `/public` (does not exist)
- `/share` (does not exist)
- `/mnt` (exists, nothing found)
- `/opt` (exists, nothing found)
- `/vol` (does not exist)
- `${PROJECT_ROOT}` (EnzymeCAGE-master)

Also searched for:
- `.sif` files (Singularity images) — none found
- `singularity-cache` / `apptainer-cache` directories — none found

## Results

| Asset | Present |
|-------|---------|
| metatraits_models | NO |
| BacDive-AI models | NO |
| GenomeSPOT models | NO |
| MICROPHERRET | NO |
| Traitar | NO |
| reCOGnise marker genes | NO |
| GTDB-Tk database | NO |
| eggNOG database | NO |
| PFAM mapping | NO |
| Container images/cache | NO |

**Total: 0 of 10 assets found.**

## Conclusion

No existing porTraits model/database assets exist on this machine. All assets remain
missing. This requires teacher-authorized transfer or download of large databases,
which is outside the scope of this runtime bootstrap task.

# Blockers and Next Steps

## Resolved Blockers (from C8-P1)

### R1: Nextflow Not Installed → RESOLVED
- **Resolution**: Nextflow 24.10.5 installed via user-space bootstrap
- **Path**: /usrdata/EnzymeCAGE_data/tools/c8_p_portraits_runtime_20260820/nextflow/nextflow
- **Method**: Official bootstrap script (curl https://get.nextflow.io | bash)

### R2: query_metatraits=none Not Supported → RESOLVED
- **Resolution**: Official latest version v0.2.1 natively supports query_metatraits=none with default="none"
- **Evidence**: nextflow_schema.json, main.nf, nextflow.config, docs/usage.md all confirm
- **Requirement**: Teacher must approve switching from v0.1.7 to v0.2.1

## Remaining Blockers

### B1: No Container Runtime (CRITICAL)
- **Problem**: No Singularity or Apptainer available. Docker is forbidden by prompt.
- **Status**: BLOCKED_ADMIN_OR_MODULE_REQUIRED
- **Next Step**: Request admin to install Singularity/Apptainer, or use a real HPC with module system
- **Approval Needed**: Admin/teacher

### B2: No porTraits Model/Database Assets
- **Problem**: 0 of 10 required assets found on this machine
- **Status**: NOT_FOUND
- **Next Step**: Transfer or download metatraits_models, GTDB-Tk DB, eggNOG DB, reCOGnise markers, etc.
- **Approval Needed**: Teacher

### B3: Teacher Approval for v0.2.1
- **Problem**: Current local version is v0.1.7 (does not support query_metatraits=none).
  Official latest v0.2.1 supports it but requires teacher approval to use.
- **Next Step**: Present evidence to teacher; request approval to use v0.2.1
- **Approval Needed**: Teacher

### B4: No Local Genome FASTA
- **Problem**: No genome FASTA files on this machine for the 412 C8-P targets
- **Next Step**: Request teacher-authorized tiny smoke genome download (2+ bacteria + 2 archaea)
- **Approval Needed**: Teacher/user (separate prompt)

## Recommended Next Steps (Priority Order)

1. Resolve B1 (install Singularity/Apptainer via admin or move to real HPC)
2. Resolve B3 (get teacher approval for porTraits v0.2.1)
3. Resolve B2 (transfer model/database assets)
4. Resolve B4 (authorize tiny smoke genome download)
5. Submit C8-P smoke test plan for teacher review

# Environment Recheck

## Basic System Information

| Item | Value |
|------|-------|
| hostname | 674db4f51184 |
| date | 2026-08-20 06:45:55 UTC |
| user | root |
| pwd | /usrdata/EnzymeCAGE_data/EnzymeCAGE-master |
| OS/kernel | Linux 674db4f51184 5.15.0-118-generic #128-Ubuntu SMP x86_64 GNU/Linux |

## Disk Free Summary

| Mount | Size | Used | Available | Use% |
|-------|------|------|-----------|------|
| / (overlay) | 100G | 5.2G | 95G | 6% |
| /usrdata (NFS) | 423T | 264T | 159T | 63% |

## Software Availability

| Software | Available | Version |
|----------|-----------|---------|
| Java | YES | OpenJDK 17.0.19 (2026-04-21) |
| Python | YES | 3.12.3 |
| Nextflow (pre-existing) | NO | - |
| Nextflow (after bootstrap) | YES | 24.10.5 build 5935 |
| Docker | NO | - |
| Singularity | NO | - |
| Apptainer | NO | - |
| conda | NO | - |
| mamba | NO | - |
| SLURM (sinfo/sbatch) | NO | - |
| module | NO | - |

## Changes Since C8-P1

- Nextflow 24.10.5 was installed via user-space bootstrap at TOOL_ROOT/nextflow/nextflow
- No other software was installed (Docker/Singularity/Apptainer installation is forbidden by prompt boundaries)

# Nextflow User-Space Bootstrap

## Status: SUCCESS

## Method

Official Nextflow bootstrap script was used:
```bash
export NXF_VER=24.10.5
curl -sSf https://get.nextflow.io | bash
```

## Installation Details

| Item | Value |
|------|-------|
| Version | 24.10.5 build 5935 |
| Created | 04-03-2025 17:55 UTC |
| Install path | /usrdata/EnzymeCAGE_data/tools/c8_p_portraits_runtime_20260820/nextflow/nextflow |
| Java prerequisite | OpenJDK 17.0.19 (met) |
| Network access | YES (curl to get.nextflow.io succeeded) |

## Verification

```bash
/usrdata/EnzymeCAGE_data/tools/c8_p_portraits_runtime_20260820/nextflow/nextflow -version
```

Output:
```
      N E X T F L O W
      version 24.10.5 build 5935
      created 04-03-2025 17:55 UTC
      cite doi:10.1038/nbt.3820
      http://nextflow.io
```

## Boundary Compliance

- No sudo used: YES
- No apt/yum/dnf/systemctl used: YES
- No Docker installed: YES
- No nextflow run executed: YES
- No pipeline launched: YES
- No container pulled: YES

## Usage

To use this Nextflow installation:
```bash
export PATH=/usrdata/EnzymeCAGE_data/tools/c8_p_portraits_runtime_20260820/nextflow:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin
nextflow -version
```

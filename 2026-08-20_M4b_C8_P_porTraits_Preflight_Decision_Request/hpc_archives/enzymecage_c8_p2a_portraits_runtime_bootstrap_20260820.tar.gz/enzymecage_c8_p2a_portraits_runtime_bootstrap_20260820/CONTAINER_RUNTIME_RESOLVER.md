# Container Runtime Resolver

## Status: BLOCKED_ADMIN_OR_MODULE_REQUIRED

## Search Results

| Search Target | Found | Path |
|---------------|-------|------|
| singularity (which) | NO | - |
| apptainer (which) | NO | - |
| module command | NO | - |
| /usr/bin search | NO | - |
| /usr/local/bin search | NO | - |
| /opt search | NO | - |
| /usrdata search | NO | - |
| /mnt search | NO | - |
| /vol search | NO | - |
| .sif files (any) | NO | - |
| singularity-cache dirs | NO | - |
| apptainer-cache dirs | NO | - |

## Conclusion

No Singularity or Apptainer binary exists anywhere on this machine. The `module`
command is also not available (no environment modules system). Docker is forbidden
by the prompt boundaries.

## Impact

porTraits v0.1.7 (and v0.2.1) require Docker or Singularity for container-based
process execution. Without a container runtime, porTraits cannot execute its
workflow processes (recognise_genome, gtdbtk_classify, genomespot, eggnog_mapper,
emapper2matrix, micropherret, bacdive_ai, traitar, prodigal).

The only process that does NOT require a container is `metatraits_speci_call`
(which uses `executor = "local"`), but with `query_metatraits=none` (supported in v0.2.1),
this process would be skipped entirely.

## Required Next Steps

1. Request admin installation of Singularity or Apptainer (preferred for HPC)
2. Or, if a module system is available on the real HPC, load the singularity/apptainer module
3. This requires teacher/user/admin action — cannot be resolved by user-space bootstrap

# porTraits Version Resolver for query_metatraits=none

## Classification

```
NEWER_OFFICIAL_VERSION_SUPPORTS_QUERY_METATRAITS_NONE
```

## Baseline (v0.1.7)

The C8-P1 preflight found that porTraits v0.1.7 (commit 742d0c6) does NOT support
`query_metatraits=none`:
- `nextflow_schema.json` has no `query_metatraits` parameter
- `main.nf` unconditionally calls `metatraits_speci_call`
- `metatraits.nf` makes live HTTP API calls to `https://metatraits.embl.de/api/v1`

## Official Repository Investigation

The official porTraits repository was cloned from `https://github.com/grp-bork/porTraits.git`
into `${TOOL_ROOT}/source_probe/porTraits/`.

### Available Tags (from git ls-remote)

| Tag | Commit | query_metatraits=none Support |
|-----|--------|-------------------------------|
| v0.1.7 | 742d0c6 | NOT SUPPORTED (baseline) |
| v0.1.17 | 076c8b4 | Not checked individually |
| v0.2.0 | 1d18e05 | Supported (changelog confirms "added toggle for metatraits reference queries") |
| main (v0.2.1) | 945795b | SUPPORTED (verified by direct code inspection) |

### Latest Version (main, v0.2.1) Evidence

1. **nextflow_schema.json**: `query_metatraits` parameter defined:
   ```json
   "query_metatraits": {
     "type": "string",
     "enum": ["none", "NCBI", "GTDB", "both"],
     "description": "Add metatraits query results.",
     "default": "none"
   }
   ```

2. **nextflow.config**: Default set in params block:
   ```
   query_metatraits = "none"
   ```

3. **main.nf**: Conditional logic skips metatraits when "none":
   ```nextflow
   if (params.query_metatraits && params.query_metatraits != "none") {
       // Only executes metatraits queries if not "none"
   }
   ```

4. **docs/usage.md**: Documents the parameter:
   > `--query_metatraits`: This can be set to `none`, `both`, `NCBI`, or `GTDB`.

5. **CHANGELOG.md** (v0.2.0): "added toggle for metatraits reference queries"

### Additional Changes in v0.2.1

- Added result collation (`collate_results` process with `assets/` reference files)
- Added GTDB-based metatraits queries (`metatraits_taxon_call`)
- Fixed NCBI-based metatraits reference queries
- Fixed output bug in PFAM2Traitar
- Made gtdbtk --mash_db parameter optional
- Process outputs are now prefixed with genome id
- Updated container image for recognise: `ghcr.io/grp-bork/recognise:v0.8.0`

## Conclusion

The official latest porTraits version (v0.2.1) fully supports `query_metatraits=none`
with a **default value of "none"**. This means when using v0.2.1, the MetaTraits API
calls would be skipped by default — exactly what C8-P needs for MetaTraits-uncovered
targets.

However, using v0.2.1 requires:
1. Teacher approval to switch from v0.1.7 to v0.2.1
2. The v0.2.1 code has additional dependencies (e.g., `collate_results` module, `assets/` directory)
3. Container runtime is still required for all other processes
4. No code patching is needed — the feature is natively supported

## Forbidden Actions (Not Performed)

- No code was patched
- No porTraits was run
- No production code was switched
- No claim that v0.2.1 is teacher-approved

# porTraits Model/Database Asset Inventory Summary

## Search Strategy

Searched the filesystem and checked the default paths defined in `nextflow_schema.json`:

| Asset | Schema Default Path | Exists |
|-------|---------------------|--------|
| metatraits_models | /vol/data/databases/clowm/CLDB-019837cec3377dd58298a00a9328680c/latest/ | NO |
| recognise_marker_genes | /vol/data/databases/clowm/CLDB-0190075fa6117f75add6ee173932d013/latest/recognise_marker_genes/ | NO |
| gtdbtk_data | /vol/data/databases/clowm/CLDB-018e12ef116275458ea149715133b0ec/latest/release220 | NO |
| eggnog_db | /vol/data/databases/clowm/CLDB-018e846affa774508716ac5b5a20386e/latest/eggnog-mapper/5.0.2/ | NO |

Also searched the filesystem for any of these directories — none found.

## Asset Status Summary

| Asset | Present | Notes |
|-------|---------|-------|
| metatraits_models | NO | Expected to contain subdirs: GenomeSPOT/models, MICROPHERRET, BacDive-AI/models, Traitar/ |
| BacDive-AI models | NO | |
| GenomeSPOT models | NO | |
| MICROPHERRET assets | NO | |
| Traitar assets | NO | |
| reCOGnise marker genes | NO | |
| GTDB-Tk database | NO | |
| eggNOG database | NO | |
| PFAM assets/mappings | NO | Depends on eggnog_db |
| Container images/cache | NO | Docker/Singularity/Apptainer all absent |

**Total assets checked: 10**
**Present: 0**
**Missing: 10**

## Available Related Data (NOT porTraits Assets)

| Data | Path | Notes |
|------|------|-------|
| MetaTraits bulk TSV snapshot | /usrdata/EnzymeCAGE_data/data/metatraits/incoming/metatraits_bulk_tsv_snapshot_20260818 | 14 gzip files; raw trait data, not porTraits models |
| porTraits code | In C8-P dependency payload | Code only, no models/databases |
| Genome download pilot manifests | In C8-P dependency payload | Manifests only, no FASTA files |

## Conclusion

No porTraits model or database assets are present on this machine. All 10 required asset categories
are missing. All schema default paths point to `/vol/data/databases/clowm/...` which does not exist
on this machine. No container images are available (Docker/Singularity/Apptainer all absent).

This is a critical blocker for any porTraits smoke test.

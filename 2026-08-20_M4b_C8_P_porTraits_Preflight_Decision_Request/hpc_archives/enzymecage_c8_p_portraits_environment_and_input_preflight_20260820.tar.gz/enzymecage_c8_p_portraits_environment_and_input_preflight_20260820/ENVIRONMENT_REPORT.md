# Environment Report

## Basic System Information

| Item | Value |
|------|-------|
| hostname | 674db4f51184 |
| date | 2026-08-20 03:19:51 UTC |
| user | root |
| pwd | /usrdata/EnzymeCAGE_data/EnzymeCAGE-master |
| OS/kernel | Linux 674db4f51184 5.15.0-118-generic #128-Ubuntu SMP Fri Jul 5 09:28:49 UTC 2024 x86_64 GNU/Linux |

## Disk Free Summary

| Mount | Size | Used | Available | Use% |
|-------|------|------|-----------|------|
| / (overlay) | 100G | 5.1G | 95G | 6% |

## Software Availability

| Software | Available | Version |
|----------|-----------|---------|
| Python | YES | 3.12.3 |
| Java | YES | OpenJDK 17.0.19 (2026-04-21) |
| conda | NO | - |
| mamba | NO | - |
| Nextflow | NO | - |
| Docker | NO | - |
| Singularity | NO | - |
| Apptainer | NO | - |
| SLURM (sinfo/sbatch) | NO | - |

## Network Policy Observation

No network policy metadata commands were executed beyond local filesystem checks.
The environment appears to be a container/sandbox (hostname 674db4f51184, overlay filesystem).
No evidence of HPC scheduler (SLURM), no evidence of container runtimes (Docker/Singularity/Apptainer).

## GPU

GPU is NOT required for this Stage 0 preflight task. GPU was NOT used.

## Project Root Resolution

- Primary path `/home/a/EnzymeCAGE` does NOT exist on this machine.
- Fallback path `/usrdata/EnzymeCAGE_data/EnzymeCAGE-master` EXISTS and is the effective PROJECT_ROOT.
- The workspace symlink `/root/projects/EnzymeCAGE-master` points to `/usrdata/EnzymeCAGE_data/EnzymeCAGE-master`.

## Critical Environment Gaps

1. **No Nextflow** - porTraits is a Nextflow pipeline; Nextflow is not installed.
2. **No container runtime** - Docker, Singularity, and Apptainer are all absent.
3. **No conda/mamba** - No conda environments available for porTraits dependency management.
4. **No SLURM** - No HPC scheduler available.

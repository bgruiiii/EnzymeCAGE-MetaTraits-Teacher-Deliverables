# C8-P Target Derivation Audit

## Derivation Method

1. Read the 2,478-row denominator file `bacdive_metatraits_overlap_by_source_signature.csv`
2. Validated row count and taxonomy counts
3. Read the coverage probe `source_signature_metatraits_coverage.csv` (3,234 rows) for `union_in_ncbi_all` evidence
4. Read `enzyme_to_microbe_source.csv` (145,607 rows) for `assembly_accession` — ALL 2,478 source_signatures have assembly_accession
5. Read genome download pilot manifests (pilot_100: 100 targets, smoke_5: 5 targets) for prior download evidence
6. Joined by `source_signature` between denominator, coverage probe, and enzyme_to_microbe_source
7. Kept source_signatures where taxonomy_group is `target_bacteria` or `target_archaea`
8. Selected MetaTraits-uncovered (metatraits_covered=False) bacteria/archaea targets
9. Preserved fungi as excluded identity-only count; did not output fungi as porTraits targets

## Observed Counts

| Metric | Observed | Expected | Match |
|--------|----------|----------|-------|
| Total denominator rows | 2478 | 2478 | YES |
| target_bacteria | 1897 | 1897 | YES |
| target_archaea | 153 | 153 | YES |
| target_fungi | 428 | 428 | YES |
| metatraits_covered=True | 1638 | 1638 | YES |
| target_bacteria_uncovered | 322 | 322 | YES |
| target_archaea_uncovered | 90 | 90 | YES |
| total_c8_p_targets | 412 | 412 | YES |
| target_fungi_excluded_identity_only | 428 | 428 | YES |
| targets_with_assembly_accession | 412 | - | - |
| targets_in_genome_pilot_100 | 18 | - | - |
| targets_in_genome_smoke_5 | 0 | - | - |

## Mismatches

No mismatches found. All counts match expected values.

## Input File Paths Used

- Denominator: `/tmp/enzymecage_c8_p_portraits_environment_and_input_preflight_20260820/payload_extracted/enzymecage_c8_p_portraits_preflight_dependency_payload_20260820/inputs/main_2478_universe/bacdive_metatraits_overlap_by_source_signature.csv`
- Coverage probe: `/tmp/enzymecage_c8_p_portraits_environment_and_input_preflight_20260820/payload_extracted/enzymecage_c8_p_portraits_preflight_dependency_payload_20260820/inputs/metatraits_coverage_probe/source_signature_metatraits_coverage.csv`
- enzyme_to_microbe_source: `/tmp/enzymecage_c8_p_portraits_environment_and_input_preflight_20260820/payload_extracted/enzymecage_c8_p_portraits_preflight_dependency_payload_20260820/inputs/enzyme_to_microbe_source/enzyme_to_microbe_source.csv`
- Pilot_100 manifest: `/tmp/enzymecage_c8_p_portraits_environment_and_input_preflight_20260820/payload_extracted/enzymecage_c8_p_portraits_preflight_dependency_payload_20260820/inputs/genome_download_pilot/pilot_100/genome_download_probe_manifest.csv`
- Smoke_5 manifest: `/tmp/enzymecage_c8_p_portraits_environment_and_input_preflight_20260820/payload_extracted/enzymecage_c8_p_portraits_preflight_dependency_payload_20260820/inputs/genome_download_pilot/smoke_5/genome_download_probe_manifest.csv`

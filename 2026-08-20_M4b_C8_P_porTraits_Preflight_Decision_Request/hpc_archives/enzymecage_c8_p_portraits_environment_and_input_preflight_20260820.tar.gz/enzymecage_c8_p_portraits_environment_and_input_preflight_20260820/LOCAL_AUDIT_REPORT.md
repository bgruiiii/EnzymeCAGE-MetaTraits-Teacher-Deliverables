# Local Audit Report

## Boundary Compliance Checklist

| Question | Answer |
|----------|--------|
| Did this task avoid full porTraits prediction? | YES — no porTraits prediction was run; only code inspection performed |
| Did this task avoid small-sample phenotype prediction? | YES — no phenotype prediction of any kind was performed |
| Did this task avoid bulk genome download? | YES — no genome FASTA download was performed; pilot manifests used as evidence only |
| Did this task exclude fungi from porTraits targets? | YES — all 428 target_fungi were excluded from the C8-P target list; fungi are identity-only |
| Did this task preserve the original 2,478 denominator? | YES — the 2,478-row denominator was read read-only and not modified |
| Did this task keep the 137 outside-universe rescued sources out of the target list? | YES — only sources within the original 2,478 universe were considered |
| Did this task avoid production D4/pool/formal asset mutation? | YES — no production D4, pool, or formal asset was modified |
| Did this task avoid trait_score, hard rejection, and uncalibrated confidence? | YES — no trait_score, hard rejection, or uncalibrated confidence was emitted |
| Did this task avoid F5 prediction? | YES — no F5 or any trait prediction was performed |
| Can Chenyu currently run a later query_metatraits=none smoke without code changes? | NO — porTraits v0.1.7 does NOT support query_metatraits=none; classification: NOT_SUPPORTED_BY_CURRENT_CHENYU_CODE |
| Are all required model/database assets present? | NO — all 10 required porTraits asset categories are missing; schema default paths under /vol/data/databases/ do not exist |
| How many bacteria/archaea targets have assembly_accession present? | 412 of 412 (100%) — ALL targets have assembly_accession from enzyme_to_microbe_source.csv |
| How many already have local FASTA available? | 0 — no local FASTA files on this machine; 18 targets have prior pilot_100 download evidence |
| What are the exact blockers before a later teacher-approved smoke test? | See BLOCKERS_AND_NEXT_STEPS.md |

## Scope Violation Check

No scope violations occurred during this task. No accidental command started full prediction,
downloaded bulk genomes, included fungi as porTraits targets, or mutated production/staged C8 assets.

## Input File Resolution

The primary PROJECT_ROOT `/home/a/EnzymeCAGE` does not exist on this machine.
The fallback PROJECT_ROOT `/usrdata/EnzymeCAGE_data/EnzymeCAGE-master` was used.

All key input files were available via the C8-P dependency payload
(`HPC_Inputs/enzymecage_c8_p_portraits_preflight_dependency_payload_20260820.tar.gz`):
- Denominator (2,478 rows)
- Coverage probe (3,234 rows)
- enzyme_to_microbe_source.csv (145,607 rows, all 2,478 source_signatures with assembly_accession)
- C8_INPUT_SOURCE_AUDIT.md and .json
- porTraits v0.1.7 code (zip + extracted)
- Genome download pilot manifests (pilot_100, smoke_5)

Authority files under `/home/a/EnzymeCAGE/custom/` remain missing but are referenced
in C8_INPUT_SOURCE_AUDIT.json with SHA256 checksums for teacher verification.

## Derived Target Universe

| Metric | Observed | Expected | Match |
|--------|----------|----------|-------|
| Total denominator rows | 2,478 | 2,478 | YES |
| target_bacteria | 1,897 | 1,897 | YES |
| target_archaea | 153 | 153 | YES |
| target_fungi | 428 | 428 | YES |
| metatraits_covered=True | 1,638 | 1,638 | YES |
| target_bacteria_uncovered | 322 | 322 | YES |
| target_archaea_uncovered | 90 | 90 | YES |
| total_c8_p_targets | 412 | 412 | YES |
| target_fungi_excluded_identity_only | 428 | 428 | YES |
| targets_with_assembly_accession | 412 | - | - |
| targets_in_genome_pilot_100 | 18 | - | - |

All counts match expected values with zero mismatches.

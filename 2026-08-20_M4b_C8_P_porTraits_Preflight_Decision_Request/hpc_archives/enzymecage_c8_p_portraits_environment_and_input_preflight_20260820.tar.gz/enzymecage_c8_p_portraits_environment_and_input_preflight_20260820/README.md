# C8-P porTraits Environment and Input Preflight

## Task Identity

```text
TASK_ID=enzymecage_c8_p_portraits_environment_and_input_preflight_20260820
RUN_TYPE=read_only_environment_and_input_feasibility_preflight
TAXONOMY_SCOPE=target_bacteria,target_archaea
EXPLICITLY_EXCLUDED_TAXONOMY=target_fungi
PREDICTION_SCOPE=none_for_this_stage
FULL_RUN_AUTHORIZED=false
PRODUCTION_AUTHORIZED=false
FINAL_STATUS=C8_P_ENV_INPUT_PREFLIGHT_BLOCKED_WITH_ACTIONABLE_GAPS
```

## Summary

This is the Stage 0 evidence package for the C8-P porTraits environment and input
feasibility preflight. It is NOT a full porTraits run, NOT production, and NOT
the C8 main staged implementation.

The package was produced on Chenyu (hostname: 674db4f51184) on 2026-08-20.

## Key Findings

1. **C8-P target universe derived successfully**: 412 targets (322 uncovered bacteria + 90 uncovered archaea)
   from the original 2,478 denominator. All counts match expected values with zero mismatches.
2. **ALL 412 targets have assembly_accession**: 100% coverage from enzyme_to_microbe_source.csv.
3. **porTraits v0.1.7 code fully inspected**: 9 modules, main.nf, nextflow_schema.json, nextflow.config.
4. **query_metatraits=none NOT SUPPORTED**: porTraits v0.1.7 always calls metatraits_speci_call which
   makes live HTTP API calls to https://metatraits.embl.de/api/v1. No skip/offline mode exists.
   Classification: NOT_SUPPORTED_BY_CURRENT_CHENYU_CODE.
5. **Nextflow NOT installed**: No Nextflow runtime available (Java 17 is present).
6. **No container runtime**: Docker, Singularity, and Apptainer all absent.
7. **No porTraits model/database assets**: All 10 required asset categories missing.
   Schema defaults point to /vol/data/databases/clowm/ which does not exist.
8. **Genome FASTA**: 0 local FASTA files; 18 targets have prior pilot_100 download evidence;
   NCBI datasets API v2 download route proven (100% success in pilot).
9. **No scope violations**: All hard boundaries respected.

## Input Resolution

All key inputs were available via the C8-P dependency payload
(`HPC_Inputs/enzymecage_c8_p_portraits_preflight_dependency_payload_20260820.tar.gz`):
- Denominator (2,478 rows), coverage probe (3,234 rows), enzyme_to_microbe_source.csv (145,607 rows)
- C8_INPUT_SOURCE_AUDIT.md and .json
- porTraits v0.1.7 code (zip + extracted)
- Genome download pilot manifests (pilot_100, smoke_5)

## Final Status

```text
C8_P_ENV_INPUT_PREFLIGHT_BLOCKED_WITH_ACTIONABLE_GAPS
```

The package is complete but Chenyu lacks required Nextflow runtime, container runtime,
porTraits model/database assets, query_metatraits=none support, and local genome FASTA
for a later smoke test. See BLOCKERS_AND_NEXT_STEPS.md for the full list of actionable gaps.

## File Manifest

See MANIFEST.files and MANIFEST.sha256 for the complete file listing and checksums.

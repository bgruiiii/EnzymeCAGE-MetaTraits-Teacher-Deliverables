# query_metatraits=none Feasibility Assessment

## Classification

```
NOT_SUPPORTED_BY_CURRENT_CHENYU_CODE
```

## Rationale

The porTraits v0.1.7 code was inspected from the C8-P dependency payload. Direct code evidence
from three sources confirms that `query_metatraits=none` is NOT supported:

### 1. nextflow_schema.json — `query_metatraits` NOT defined

The schema defines only 6 parameters: `input_dir`, `output_dir`, `recognise_marker_genes`,
`gtdbtk_data`, `metatraits_models`, `eggnog_db`. There is NO `query_metatraits` parameter.

### 2. main.nf — `metatraits_speci_call` is ALWAYS called

The workflow in `main.nf` unconditionally includes and calls `metatraits_speci_call`:

```nextflow
include { metatraits_speci_call } from "./portraits/modules/metatraits"
...
workflow {
    ...
    metatraits_speci_call(metatraits_speci_call_ch)
    ...
}
```

There is no `if` conditional, no `params.query_metatraits` check, and no skip logic.
The MetaTraits query is always executed.

### 3. metatraits.nf — makes live HTTP API calls

The `metatraits_speci_call` process makes HTTP `curl` calls to the MetaTraits API:

```nextflow
process metatraits_speci_call {
    ...
    script:
    """
    taxid=\$(curl -H "Accept: application/json" ... ${METATRAITS_URL}/species_taxonomy/${speci} ...)
    curl -H "Accept: application/json" ... https://metatraits.embl.de/api/v1/traits/taxonomy/\$taxid ...
    """
}
```

Where `METATRAITS_URL = "https://metatraits.embl.de/api/v1"`.

This means porTraits v0.1.7 ALWAYS queries the live MetaTraits API during execution.
There is no offline mode, no skip mode, and no `query_metatraits=none` option.

### 4. nextflow.config — no query_metatraits default

The `nextflow.config` file does not define a `query_metatraits` parameter in the `params` block.

### 5. docs/usage.md — no query_metatraits mention

The `docs/usage.md` file only mentions `input_genomes` and `outdir` as input/output.
No `query_metatraits` option is documented.

## Impact

This means that **without code changes**, porTraits v0.1.7 will ALWAYS attempt to call
the MetaTraits API during execution. For C8-P targets (MetaTraits-uncovered bacteria/archaea),
the MetaTraits API call may return no data or may return data that contradicts the local
MetaTraits-uncovered classification.

The prompt's caution was correct: "The local v0.1.7 nextflow_schema.json may not expose
query_metatraits. Do not assume query_metatraits=none works in the installed Chenyu version."

## Required Next Steps

If `query_metatraits=none` (or any MetaTraits-skip mode) is needed for C8-P, one of the
following must happen:

1. **Code patch** (requires teacher/user approval): Add a conditional in `main.nf` to skip
   `metatraits_speci_call` when a new `params.query_metatraits` is set to `"none"`, and
   add the parameter to `nextflow_schema.json`.
2. **Code version update**: Check if a newer porTraits version supports this feature and
   obtain teacher approval to use it.
3. **Accept MetaTraits API calls**: If network access to `metatraits.embl.de` is available
   during the smoke test, the unpatched code can run as-is, but the MetaTraits API results
   would be supplementary to (not replacing) the local MetaTraits-uncovered classification.

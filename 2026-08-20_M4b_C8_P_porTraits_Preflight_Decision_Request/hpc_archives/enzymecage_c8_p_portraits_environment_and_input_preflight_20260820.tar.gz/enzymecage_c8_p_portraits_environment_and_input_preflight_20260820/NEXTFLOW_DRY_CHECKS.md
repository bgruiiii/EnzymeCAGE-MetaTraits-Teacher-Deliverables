# Nextflow Dry Checks

## Nextflow Availability

```
nextflow: NOT INSTALLED
```

Nextflow is not available on this machine. All Nextflow-related checks were skipped.

## Command Log

| Command | Status | Reason |
|---------|--------|--------|
| `nextflow -version` | SKIPPED | Nextflow not installed |
| `nextflow help` | SKIPPED | Nextflow not installed |
| `nextflow config <porTraits_dir>` | SKIPPED | Nextflow not installed AND porTraits directory not found |
| `nextflow run <porTraits_dir> --help` | SKIPPED | Nextflow not installed AND porTraits directory not found |

## Forbidden Commands (Not Executed)

The following forbidden commands were NOT executed, as specified by the prompt:

| Forbidden Command | Status |
|--------------------|--------|
| `nextflow run` (launching tasks) | NOT EXECUTED |
| Profile/container pull downloading large images | NOT EXECUTED |
| Executor submission | NOT EXECUTED |
| Process execution | NOT EXECUTED |

## Conclusion

Nextflow is not installed on this machine. No non-invasive Nextflow checks could be performed.
Before any porTraits smoke test, Nextflow must be installed and the porTraits v0.1.7 code must be
transferred to Chenyu.

# Genome FASTA Availability Dry Check

## Summary

For the 412 C8-P bacteria/archaea targets, genome FASTA availability was dry-checked
without any bulk download or sequence-content retrieval.

| Metric | Value |
|--------|-------|
| Total C8-P targets | 412 |
| Targets with assembly_accession present | 412 |
| Targets without assembly_accession | 0 |
| Local FASTA files found (on this machine) | 0 |
| Targets in genome pilot_100 (downloaded_and_validated) | 18 |
| Targets in genome smoke_5 (downloaded_and_validated) | 0 |
| Bulk download performed | NO |
| Genome download probe present | YES (manifests/summaries in payload; FASTA files excluded) |

## Method

1. Assembly accession presence was checked from the `assembly_accession` column in
   `enzyme_to_microbe_source.csv`. ALL 2,478 source_signatures (and thus all 412 C8-P targets)
   have an assembly accession (GCA or GCF format).
2. Local FASTA files were searched using `find / -name '*.fna'` and related suffixes —
   no results anywhere on the filesystem.
3. The genome download pilot evidence was available via the dependency payload, providing
   manifests and summaries for pilot_100 (100 targets, 100% success) and smoke_5 (5 targets, 100% success).
   Actual FASTA files were excluded from the payload by design (EXCLUSION_NOTES.md).

## Assembly Accession Breakdown

| Taxonomy Group | With Assembly | Without Assembly | Total |
|---------------|---------------|------------------|-------|
| target_bacteria | 322 | 0 | 322 |
| target_archaea | 90 | 0 | 90 |
| **Total** | **412** | **0** | **412** |

## Download Route Evidence (from pilot)

The genome download pilot used the NCBI datasets API v2:
`https://api.ncbi.nlm.nih.gov/datasets/v2/genome/accession/<assembly_accession>/download?include_annotation_type=GENOME_FASTA`

Pilot_100: 100 targets attempted, 100 succeeded (0 failures), total 365MB FASTA.
Smoke_5: 5 targets attempted, 5 succeeded (0 failures), total 21MB FASTA.

## Forbidden Actions (Not Performed)

| Forbidden Action | Status |
|------------------|--------|
| Bulk FASTA download | NOT PERFORMED |
| Full 412-target download | NOT PERFORMED |
| Sequence-content download | NOT PERFORMED |
| Prediction execution | NOT PERFORMED |

## Conclusion

All 412 of 412 C8-P targets have assembly accessions.
No local FASTA files exist on this machine.
18 targets have prior pilot_100 download evidence and 0 have smoke_5 evidence.
The NCBI datasets API v2 download route is documented and proven (100% success in pilot).

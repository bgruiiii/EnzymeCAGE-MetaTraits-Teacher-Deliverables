# porTraits Version and Code Audit

## Search Result

porTraits v0.1.7 was found via the C8-P dependency payload at:
`HPC_Inputs/enzymecage_c8_p_portraits_preflight_dependency_payload_20260820.tar.gz`

The extracted reference repository is at:
`inputs/portraits_reference/extracted/porTraits-v0.1.7/grp-bork-porTraits-742d0c6/`

The raw zip is at:
`inputs/portraits_reference/raw_downloads/porTraits-v0.1.7.zip`

## Code Inventory

| Item | Value |
|------|-------|
| repo_or_archive_type | Extracted git repository (also raw zip) |
| version/tag | 0.1.7 (from nextflow.config manifest) |
| git_commit | 742d0c6 (from directory name) |
| README presence | YES |
| nextflow_schema.json presence | YES |
| main.nf presence | YES |
| nextflow.config presence | YES |
| module files count | 9 |
| docs/usage.md | YES |
| docs/output.md | YES |
| CHANGELOG.md | YES |
| LICENSE | YES |

## SHA256 for Key Files

| File | SHA256 |
|------|--------|
| main.nf | 3685ecccbfd84df78ff806f52d3b16f95ceb6a7c442d57760c8fee865948282f |
| nextflow_schema.json | 4caf0dcd217d5a2e7ff696b29da44cb6a21234c96b45b27cc9c3ad77ae7740d8 |
| nextflow.config | 1a731690d3614adcaf05d0b8d33550de9c75e8b46d1c1a2879c48d9de89bfcb7 |
| porTraits-v0.1.7.zip | bb49f737a918bf6ed1249391ca6be5589dffecce9214eac627ab929721d27956 |

## Module Inventory

| Module | File | Present |
|--------|------|---------|
| BacDive-AI | portraits/modules/bacdive.nf | YES |
| GenomeSPOT | portraits/modules/genomespot.nf | YES |
| Traitar | portraits/modules/traitar.nf | YES |
| MICROPHERRET | portraits/modules/micropherret.nf | YES |
| GTDB-Tk | portraits/modules/gtdbtk.nf | YES |
| reCOGnise | portraits/modules/recognise.nf | YES |
| eggNOG mapper | portraits/modules/eggnog_mapper.nf | YES |
| MetaTraits query | portraits/modules/metatraits.nf | YES |
| Prodigal | portraits/modules/prodigal.nf | YES |

## Schema Parameters (from nextflow_schema.json)

| Parameter | Type | Required | Default |
|-----------|------|----------|---------|
| input_dir | string (directory-path) | YES | - |
| output_dir | string (directory-path) | YES | - |
| recognise_marker_genes | string | YES | /vol/data/databases/clowm/CLDB-0190075fa6117f75add6ee173932d013/latest/recognise_marker_genes/ |
| gtdbtk_data | string | YES | /vol/data/databases/clowm/CLDB-018e12ef116275458ea149715133b0ec/latest/release220 |
| metatraits_models | string | YES | /vol/data/databases/clowm/CLDB-019837cec3377dd58298a00a9328680c/latest/ |
| eggnog_db | string | YES | /vol/data/databases/clowm/CLDB-018e846affa774508716ac5b5a20386e/latest/eggnog-mapper/5.0.2/ |

**Note**: `query_metatraits` is NOT a parameter in the schema. See QUERY_METATRAITS_NONE_FEASIBILITY.md.

## Container Images (from nextflow.config)

| Process | Container |
|---------|----------|
| recognise_genome | ghcr.io/grp-bork/recognise:main (or oras://registry.git.embl.de/schudoma/recognise-singularity/recognise-singularity:8b158eab) |
| gtdbtk_classify | quay.io/biocontainers/gtdbtk:2.4.1--pyhdfd78af_1 |
| genomespot | ghcr.io/cschu/genomespot:main |
| eggnog_mapper | quay.io/biocontainers/eggnog-mapper:2.1.12--pyhdfd78af_2 |
| emapper2matrix | registry.git.embl.org/schudoma/portrait_sklearn:v1.2.2_micropherret |
| micropherret | registry.git.embl.org/schudoma/portrait_sklearn:v1.2.2_micropherret |
| bacdive_ai | registry.git.embl.org/schudoma/portrait_sklearn:v.1.4.0_traitar_bacdive |
| traitar | registry.git.embl.org/schudoma/portrait_sklearn:v.1.4.0_traitar_bacdive |
| metatraits_speci_call | (no container; executor = "local") |
| prodigal | quay.io/biocontainers/prodigal:2.6.3--h031d066_7 |

## Conclusion

porTraits v0.1.7 code is fully present and inspectable. The code requires:
1. Nextflow >= 24 (not installed on this machine)
2. Docker enabled (Docker not installed on this machine)
3. Multiple container images (not pulled)
4. Multiple database assets (not present on this machine)
5. The `metatraits_speci_call` process always makes HTTP API calls to `https://metatraits.embl.de/api/v1`

# Blockers and Next Steps

## Critical Blockers (Must Resolve Before Any C8-P Smoke Test)

### B1: Nextflow Not Installed
- **Problem**: Nextflow is not installed on this machine. porTraits v0.1.7 requires Nextflow >= 24.
- **Evidence**: `which nextflow` returned not found. Java (OpenJDK 17.0.19) is available.
- **Next Step**: Install Nextflow (Java prerequisite is met).
- **Approval Needed**: Teacher/user must authorize Nextflow installation.

### B2: No Container Runtime
- **Problem**: Docker, Singularity, and Apptainer are all absent. porTraits v0.1.7 requires Docker
  (nextflow.config: `docker { enabled = true }`).
- **Evidence**: `which docker`, `which singularity`, `which apptainer` all returned not found.
- **Next Step**: Install Docker or Singularity/Apptainer (preferred for HPC).
- **Approval Needed**: Teacher/user must authorize container runtime installation.

### B3: No porTraits Model/Database Assets
- **Problem**: All 10 required porTraits asset categories are missing.
- **Evidence**: Schema default paths under `/vol/data/databases/clowm/CLDB-*` do not exist.
  Missing: metatraits_models, BacDive-AI models, GenomeSPOT models, MICROPHERRET assets,
  Traitar assets, reCOGnise marker genes, GTDB-Tk database, eggNOG database, PFAM assets,
  container images.
- **Next Step**: Transfer or download required model/database assets. This is a large effort.
- **Approval Needed**: Teacher must authorize each asset transfer/download.

### B4: query_metatraits=none NOT Supported
- **Problem**: porTraits v0.1.7 does NOT support `query_metatraits=none`. The `metatraits_speci_call`
  process is always called and makes live HTTP API calls to `https://metatraits.embl.de/api/v1`.
  There is no `query_metatraits` parameter in nextflow_schema.json, no conditional skip logic in
  main.nf, and no offline mode.
- **Evidence**: Direct code inspection of nextflow_schema.json, main.nf, metatraits.nf,
  nextflow.config, and docs/usage.md.
- **Next Step**: Either (a) patch the code with teacher approval, (b) check for a newer porTraits
  version with this feature, or (c) accept that MetaTraits API calls will happen during smoke test
  (if network access is available).
- **Approval Needed**: Teacher must decide which approach to take.

### B5: No Local Genome FASTA Cache
- **Problem**: No genome FASTA files exist on this machine.
- **Evidence**: `find / -name "*.fna"` and related suffixes returned no results.
- **Next Step**: For a later smoke test, a tiny sample (2+ bacteria + 2 archaea) of genome FASTA
  files would need to be downloaded. ALL 412 targets have assembly accessions. The NCBI datasets
  API v2 download route is proven (100% success in pilot_100 with 100 targets).
  18 of 412 targets have prior pilot_100 download evidence.
- **Approval Needed**: Teacher/user must explicitly authorize a tiny smoke input download.

### B6: No conda/mamba Environments
- **Problem**: No conda or mamba is installed.
- **Evidence**: `which conda` and `which mamba` both returned not found.
- **Next Step**: Install conda/mamba if needed for dependency management (may not be needed if
  container approach is used).
- **Approval Needed**: Teacher/user must authorize.

### B7: No SLURM Scheduler
- **Problem**: No SLURM scheduler is available.
- **Evidence**: `which sinfo` and `which sbatch` both returned not found.
- **Next Step**: Local execution may be feasible for a tiny smoke test. SLURM only needed for
  larger runs.
- **Approval Needed**: Teacher/user must determine execution mode.

## What Was Successfully Completed

1. **Environment inventory** — Complete (ENVIRONMENT_REPORT.md/json)
2. **porTraits code audit** — Complete (PORTRAITS_VERSION_AND_CODE_AUDIT.md); v0.1.7 code fully inspected
3. **query_metatraits=none feasibility** — Classified as NOT_SUPPORTED_BY_CURRENT_CHENYU_CODE with direct evidence
4. **porTraits asset inventory** — Complete; all 10 categories confirmed missing
5. **C8-P target universe derivation** — Complete with all counts matching:
   - 322 uncovered bacteria + 90 uncovered archaea = 412 total C8-P targets
   - 428 fungi excluded as identity-only
   - 2,478 denominator preserved
   - ALL 412 targets have assembly_accession
6. **Genome FASTA availability dry check** — Complete; 0 local FASTA; 18 targets with pilot evidence
7. **Nextflow dry checks** — Nextflow not installed; all checks skipped

## Recommended Next Steps (Priority Order)

1. Resolve B1 (install Nextflow)
2. Resolve B2 (install container runtime)
3. Resolve B4 (decide on query_metatraits approach)
4. Resolve B3 (transfer model/database assets)
5. Resolve B5 (authorize tiny smoke genome download)
6. Submit C8-P smoke test plan for teacher review

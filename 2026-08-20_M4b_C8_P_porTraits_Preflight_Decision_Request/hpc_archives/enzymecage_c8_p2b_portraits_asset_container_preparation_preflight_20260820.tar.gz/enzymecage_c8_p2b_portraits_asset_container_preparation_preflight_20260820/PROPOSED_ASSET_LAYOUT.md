# Proposed Asset Layout

## Proposed Directory Tree (text only, not yet created)

```
/usrdata/EnzymeCAGE_data/databases/portraits/v0.2.1/
  metatraits_models/          ← from porTraits-DB.tar.gz (Zenodo 16818976)
    BacDive-AI/models/        ← BacDive-AI capitalization per main.nf
    GenomeSPOT/models/
    MICROPHERRET/
    Traitar/
  recognise_markers/          ← from recognise_markers.tar.gz (Zenodo 17916463)
  gtdb/release220/            ← from gtdbtk_r220_data.tar.gz (GTDB)
  eggnog/emapperdb-5.0.2/
    eggnog.db                 ← from eggnog.db.gz (decompressed)
    eggnog_proteins.dmnd      ← from eggnog_proteins.dmnd.gz (decompressed)
    eggnog.taxa/              ← from eggnog.taxa.tar.gz (extracted)
    pfam/Pfam-A.clans.tsv.gz  ← from pfam.tar.gz
  containers/sif/             ← Singularity/Apptainer SIF images
```

## porTraits v0.2.1 Parameter Mapping

| porTraits Parameter | Proposed Path |
|---------------------|---------------|
| metatraits_models | /usrdata/EnzymeCAGE_data/databases/portraits/v0.2.1/metatraits_models/ |
| recognise_marker_genes | /usrdata/EnzymeCAGE_data/databases/portraits/v0.2.1/recognise_markers/ |
| gtdbtk_data | /usrdata/EnzymeCAGE_data/databases/portraits/v0.2.1/gtdb/release220/ |
| eggnog_db | /usrdata/EnzymeCAGE_data/databases/portraits/v0.2.1/eggnog/emapperdb-5.0.2/ |
| pfam_clade_map | ${eggnog_db}/pfam/Pfam-A.clans.tsv.gz |

## Source URLs

| Asset | Source URL | Confirmed |
|-------|-----------|-----------|
| porTraits-DB.tar.gz | https://zenodo.org/records/16818976/files/porTraits-DB.tar.gz | YES (HTTP 200, 1.32 GB) |
| recognise_markers.tar.gz | https://zenodo.org/records/17916463/files/recognise_markers.tar.gz | YES (HTTP 200, 974 MB) |
| gtdbtk_r220_data.tar.gz | https://data.gtdb.ecogenomic.org/.../gtdbtk_r220_data.tar.gz | YES (HTTP 200, 101 GB) |
| eggnog.db.gz | http://eggnog6.embl.de/download/emapperdb-5.0.2/eggnog.db.gz | FAILED (server empty reply) |
| eggnog_proteins.dmnd.gz | http://eggnog6.embl.de/download/emapperdb-5.0.2/eggnog_proteins.dmnd.gz | FAILED (server empty reply) |
| eggnog.taxa.tar.gz | http://eggnog6.embl.de/download/emapperdb-5.0.2/eggnog.taxa.tar.gz | FAILED (server empty reply) |
| pfam.tar.gz | http://eggnog6.embl.de/download/emapperdb-5.0.2/pfam.tar.gz | FAILED (server empty reply) |

## Note on BacDive-AI Capitalization

The porTraits v0.2.1 `main.nf` uses `"${params.metatraits_models}/BacDive-AI/models"` (capital D and AI).
The directory in the proposed layout follows this exact capitalization.

# Blockers and Next Steps

## Package Status: READY_FOR_LOCAL_AUDIT

The asset/container preparation preflight package is complete with a full
metadata-only plan. Actual downloads remain blocked pending teacher approval.

## Remaining Blockers (all require teacher/admin action)

1. **Container runtime** — Singularity/Apptainer must be installed (admin action)
2. **Asset downloads** — 7 assets need teacher-authorized download (~152 GB compressed)
   - eggNOG server currently unresponsive — alternative source needed
3. **Container SIF build** — 10 images need pull+convert (after container runtime available)
4. **porTraits v0.2.1 approval** — Teacher must approve version switch from v0.1.7
5. **FASTA smoke inputs** — Teacher must authorize tiny genome download (separate prompt)

## Next Steps (Priority Order)

1. Teacher reviews this package and TEACHER_DECISION_CHECKLIST_FOR_C8_P.md
2. Teacher approves D1-D7 decisions
3. Admin installs Singularity/Apptainer
4. Download porTraits-DB + reCOGnise markers + GTDB-Tk (smaller, confirmed URLs first)
5. Investigate eggNOG server status / find alternative eggNOG source
6. Pull and convert 10 container images to SIF
7. Authorize tiny FASTA smoke input download
8. Execute controlled C8-P smoke test (separate prompt)

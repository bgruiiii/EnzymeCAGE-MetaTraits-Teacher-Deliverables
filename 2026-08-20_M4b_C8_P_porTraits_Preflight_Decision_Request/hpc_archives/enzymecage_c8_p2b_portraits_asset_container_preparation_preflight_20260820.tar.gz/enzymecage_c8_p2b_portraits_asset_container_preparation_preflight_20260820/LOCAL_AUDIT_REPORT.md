# Local Audit Report

## Boundary Compliance

| Question | Answer |
|----------|--------|
| Did this task avoid porTraits execution? | YES |
| Did this task avoid nextflow run/config? | YES |
| Did this task avoid genome download? | YES |
| Did this task avoid model/database download? | YES (metadata-only HEAD/API checks only) |
| Did this task avoid container pull/SIF build? | YES |
| Did this task avoid install/sudo/root changes? | YES |
| Which asset URLs have confirmed metadata? | porTraits-DB (Zenodo), reCOGnise markers (Zenodo), GTDB-Tk r220 (HEAD) — 3 of 7 |
| Which sizes are official/inferred/third-party/unknown? | 3 official confirmed; 4 eggNOG third-party estimate (server unresponsive) |
| Is /usrdata quota enough? | YES — 159 TB available vs ~294 GB needed |
| Is Apptainer/Singularity available? | NO |
| What admin questions remain? | See CONTAINER_RUNTIME_ADMIN_QUESTIONS.md (7 questions) |
| What teacher decisions are needed? | See TEACHER_DECISION_CHECKLIST_FOR_C8_P.md (D1-D7) |

## No scope violations.

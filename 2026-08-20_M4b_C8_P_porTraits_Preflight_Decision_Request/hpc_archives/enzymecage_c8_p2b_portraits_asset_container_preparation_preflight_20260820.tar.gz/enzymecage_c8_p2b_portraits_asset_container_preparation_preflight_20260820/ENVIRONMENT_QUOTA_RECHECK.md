# Environment and Quota Recheck

## System
| Item | Value |
|------|-------|
| hostname | 674db4f51184 |
| date | 2026-08-20 09:19:59 UTC |
| user | root |
| pwd | /usrdata/EnzymeCAGE_data/EnzymeCAGE-master |
| OS/kernel | Linux 5.15.0-118-generic x86_64 |

## TOOL_ROOT State
| Item | Value |
|------|-------|
| Nextflow | EXISTS at TOOL_ROOT/nextflow/nextflow; version 24.10.5 build 5935 |
| porTraits v0.2.1 | EXISTS at TOOL_ROOT/source_probe/porTraits; commit 945795b |
| TOOL_ROOT total size | 486K |

## Container Runtime
| Software | Found |
|----------|-------|
| singularity | NO |
| apptainer | NO |
| docker | NO |
| module | NO |

## Disk Free
| Mount | Size | Used | Available | Use% |
|-------|------|------|-----------|------|
| /usrdata (NFS) | 423T | 265T | 159T | 63% |
| / (overlay) | 100G | 5.4G | 95G | 6% |

## Quota
No quota/lfs tools available. NFS mount shows 159T available on /usrdata.

# Official Asset URL Metadata Summary

## Results

| Asset | URL Status | Content-Length | Checksum | Source |
|-------|------------|----------------|----------|--------|
| porTraits-DB | HTTP 200 | 1,421,564,553 (~1.32 GB) | md5:a259bae... | Zenodo API + HEAD |
| reCOGnise markers | HTTP 200 | 1,021,341,841 (~974 MB) | md5:c9294d4a... | Zenodo API + HEAD |
| GTDB-Tk r220 | HTTP 200 | 108,491,169,765 (~101 GB) | etag:6621af58... | HEAD |
| eggNOG eggnog.db.gz | FAILED (empty reply) | - | - | HEAD failed (curl error 52) |
| eggNOG eggnog_proteins.dmnd.gz | FAILED (empty reply) | - | - | HEAD failed (curl error 52) |
| eggNOG eggnog.taxa.tar.gz | FAILED (empty reply) | - | - | HEAD failed (curl error 52) |
| eggNOG pfam.tar.gz | FAILED (empty reply) | - | - | HEAD failed (curl error 52) |

## eggNOG Server Status

The eggNOG download server at `eggnog6.embl.de` returned empty replies (curl error 52)
for all four files. This could mean:
1. The server is temporarily down
2. The server does not support HEAD requests
3. The URLs have changed

For size estimation, third-party estimates will be used (see ASSET_SIZE_BUDGET.csv).

## Zenodo Records

### porTraits-DB (Zenodo 16818976)
- Title: "porTraits database: models"
- DOI: 10.5281/zenodo.16818976
- Publication date: 2025-08-13
- File: porTraits-DB.tar.gz (1,421,564,553 bytes, MD5: a259bae25f833080ca25aaa092d666e0)

### reCOGnise markers (Zenodo 17916463)
- Title: "reCOGnise specI identification marker gene database"
- DOI: 10.5281/zenodo.17916463
- File: recognise_markers.tar.gz (1,021,341,841 bytes, MD5: c9294d4a69816e7e40d2911d817992a9)

## GTDB-Tk r220
- URL: https://data.gtdb.ecogenomic.org/releases/release220/220.0/...
- Content-Length: 108,491,169,765 bytes (~101 GB)
- ETag: "6621af58-194293dfe5"
- Last-Modified: 2024-04-18

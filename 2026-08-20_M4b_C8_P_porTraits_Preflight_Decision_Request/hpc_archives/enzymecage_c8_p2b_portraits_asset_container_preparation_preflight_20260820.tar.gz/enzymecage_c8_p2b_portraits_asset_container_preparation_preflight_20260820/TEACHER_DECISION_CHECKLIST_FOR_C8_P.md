# Teacher Decision Checklist for C8-P

## Decisions Required Before Any Smoke Test

### D1: Approve porTraits v0.2.1
- **Question**: May C8-P use porTraits main commit 945795b / manifest 0.2.1?
- **Context**: v0.1.7 (current local) does not support query_metatraits=none.
  v0.2.1 supports it natively with default="none".
- **Evidence**: PORTRAITS_VERSION_RESOLVER.md in C8-P2A return package
- **Decision needed from**: Teacher

### D2: Approve Singularity/Apptainer availability
- **Question**: How will Singularity or Apptainer be made available?
  - (a) Admin installs on this machine
  - (b) Use real HPC cluster with module system
  - (c) Other approach
- **Context**: No container runtime currently exists. porTraits requires containers for all processes.
- **Evidence**: CONTAINER_RUNTIME_RESOLVER.md in C8-P2A return package
- **Decision needed from**: Teacher/Admin

### D3: Approve asset downloads/transfers
- **Question**: May the following assets be downloaded?
  - porTraits-DB.tar.gz (1.32 GB, Zenodo)
  - recognise_markers.tar.gz (974 MB, Zenodo)
  - gtdbtk_r220_data.tar.gz (101 GB, GTDB)
  - eggNOG 5.0.2 (~33 GB compressed, eggNOG server — server currently unresponsive)
- **Context**: All assets confirmed missing. Storage is sufficient (159 TB available).
- **Evidence**: OFFICIAL_ASSET_URL_METADATA.csv, ASSET_SIZE_BUDGET.csv
- **Decision needed from**: Teacher

### D4: Approve container OCI-to-SIF preparation
- **Question**: May 10 container images be pulled and converted to SIF format?
- **Context**: 10 unique container images identified from v0.2.1 code.
  quay.io images are public; ghcr.io and registry.git.embl.org may need auth.
- **Evidence**: CONTAINER_IMAGE_REFERENCE_PLAN.csv, APPTAINER_SIF_PULL_PLAN.md
- **Decision needed from**: Teacher

### D5: Approve tiny bacteria/archaea FASTA smoke inputs
- **Question**: May a tiny sample (2+ bacteria + 2 archaea) of genome FASTA be downloaded for smoke test?
- **Context**: All 412 C8-P targets have assembly accessions. NCBI datasets API v2 proven (100% success in pilot).
- **Decision needed from**: Teacher/User (separate prompt)

### D6: Confirm asset storage path/quota owner
- **Question**: Is the proposed path acceptable?
  `/usrdata/EnzymeCAGE_data/databases/portraits/v0.2.1/`
- **Context**: 159 TB available; estimated 294 GB needed for all decompressed assets.
- **Decision needed from**: Teacher/Admin

### D7: Confirm no fungi and no production integration
- **Question**: Confirm that:
  - Fungi remain identity-only (428 excluded from porTraits targets)
  - No production D4, pool, or formal asset mutation
  - No trait_score, hard rejection, or uncalibrated confidence
  - No F5 prediction
  - Predicted evidence labeled as source_type=porTraits_genome_prediction
- **Decision needed from**: Teacher

## Summary

| Decision | Needed From | Status |
|----------|-------------|--------|
| D1: porTraits v0.2.1 | Teacher | PENDING |
| D2: Container runtime | Teacher/Admin | PENDING |
| D3: Asset downloads | Teacher | PENDING |
| D4: Container SIF | Teacher | PENDING |
| D5: FASTA smoke inputs | Teacher/User | PENDING |
| D6: Storage path | Teacher/Admin | PENDING |
| D7: Fungi/production guard | Teacher | PENDING |

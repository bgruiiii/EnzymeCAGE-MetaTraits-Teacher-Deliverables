# Container Runtime Admin Questions

## Current Status
No container runtime (Singularity/Apptainer/Docker) is available on this machine.
No `module` command is available for loading environment modules.

## Questions for Admin/HPC Team

1. **Can Singularity or Apptainer be installed on this machine or the HPC cluster?**
   - Singularity/Apptainer is the preferred container runtime for HPC environments
   - It does not require root daemon (unlike Docker)
   - Can run as unprivileged user

2. **Is there a `module` system on the real HPC cluster?**
   - If so, what module names provide Singularity/Apptainer?
   - `module avail singularity` / `module avail apptainer`

3. **Are there pre-built SIF images available on a shared filesystem?**
   - Common biocontainers SIFs may already be cached
   - Check `/usrdata`, `/share`, `/public` for existing SIF caches

4. **Is network access to the following registries available?**
   - `ghcr.io` (GitHub Container Registry)
   - `quay.io` (Quay.io / Red Hat)
   - `registry.git.embl.org` (EMBL GitLab Container Registry)

5. **Are EMBL GitLab container registry credentials needed?**
   - `registry.git.embl.org/schudoma/*` images may require authentication
   - Who has access? Can a deploy token be created?

6. **What is the recommended SIF cache directory location?**
   - Proposal: `/usrdata/EnzymeCAGE_data/databases/portraits/v0.2.1/containers/sif/`
   - Is this acceptable or is there a shared cache location?

7. **Is Docker available as a fallback for building SIF images remotely?**
   - `singularity build sif.img docker://...` can convert OCI to SIF
   - Requires Singularity but not Docker daemon

# Apptainer/SIF Pull Plan

## Status: BLOCKED — No Apptainer/Singularity installed

## Planned SIF Images

Once Apptainer/Singularity is available, the following `apptainer pull` commands would
build SIF images from the OCI container references:

```bash
# Set SIF cache directory
export APPTAINER_CACHEDIR=/usrdata/EnzymeCAGE_data/databases/portraits/v0.2.1/containers/sif

# 1. reCOGnise
apptainer pull docker://ghcr.io/grp-bork/recognise:v0.8.0

# 2. GTDB-Tk
apptainer pull docker://quay.io/biocontainers/gtdbtk:2.4.1--pyhdfd78af_1

# 3. GenomeSPOT (ghcr.io)
apptainer pull docker://ghcr.io/cschu/genomespot:main

# 4. GenomeSPOT (embl registry)
apptainer pull docker://registry.git.embl.org/schudoma/genomespot-docker:v1.0.1plus

# 5. eggNOG-mapper
apptainer pull docker://quay.io/biocontainers/eggnog-mapper:2.1.12--pyhdfd78af_2

# 6. emapper2matrix + micropherret
apptainer pull docker://registry.git.embl.org/schudoma/portrait_sklearn:v1.2.2_micropherret

# 7. bacdive_ai + traitar
apptainer pull docker://registry.git.embl.org/schudoma/portrait_sklearn:v.1.4.0_traitar_bacdive

# 8. portraits_metatraits (latest) — only needed if query_metatraits != none
apptainer pull docker://registry.git.embl.org/schudoma/portraits_metatraits:latest

# 9. portraits_metatraits (with_pandas) — for collate_results
apptainer pull docker://registry.git.embl.org/schudoma/portraits_metatraits:with_pandas

# 10. Prodigal
apptainer pull docker://quay.io/biocontainers/prodigal:2.6.3--h031d066_7
```

## Image Count: 10 unique images

## Differences from Prompt's List

The prompt listed 9 container references. The actual v0.2.1 code-derived list has 10:
- **Extra**: `ghcr.io/cschu/genomespot:main` — appears in nextflow.config alongside
  `registry.git.embl.org/schudoma/genomespot-docker:v1.0.1plus`. Both are genomespot
  containers; one may be for a different process variant or a fallback.
- All other images match the prompt's list.

## Registry Auth Notes

- `quay.io` images are public — no auth needed
- `ghcr.io` images may need GitHub token for registry API (but pull should work without)
- `registry.git.embl.org` images may need EMBL GitLab credentials — verify with registry admin

## Prerequisites

1. Apptainer or Singularity must be installed (currently BLOCKED)
2. SIF cache directory must be created
3. Network access to all three registries must be verified
4. EMBL GitLab registry credentials may be needed

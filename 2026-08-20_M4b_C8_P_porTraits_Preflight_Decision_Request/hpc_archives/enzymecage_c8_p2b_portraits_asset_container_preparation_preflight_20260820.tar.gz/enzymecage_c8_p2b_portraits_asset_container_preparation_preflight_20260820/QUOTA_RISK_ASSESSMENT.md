# Quota Risk Assessment

## Disk Space Analysis

| Mount | Available | Required (compressed) | Required (decompressed) | Risk |
|-------|-----------|------------------------|--------------------------|------|
| /usrdata (NFS) | 159 TB | ~152 GB | ~294 GB | LOW (159TB >> 294GB) |
| / (overlay) | 95 GB | N/A (assets go to /usrdata) | N/A | N/A |

## Assessment

**Quota risk: LOW.** The /usrdata NFS mount has 159 TB available, which is more than
sufficient for the estimated 294 GB of decompressed assets. Even the largest single
download (GTDB-Tk r220 at 101 GB compressed, ~151 GB decompressed) represents only
0.1% of available storage.

## Per-Asset Risk

| Asset | Compressed | Decompressed | Download Time (est. 100Mbps) | Risk |
|-------|-----------|---------------|-------------------------------|------|
| porTraits-DB | 1.32 GB | ~2.6 GB | ~2 min | LOW |
| reCOGnise markers | 974 MB | ~1.9 GB | ~1.5 min | LOW |
| GTDB-Tk r220 | 101 GB | ~151 GB | ~2.3 hours | MEDIUM (large, long download) |
| eggNOG 5.0.2 | ~32.7 GB | ~123 GB | ~45 min | MEDIUM (server availability unknown) |
| Container SIFs | ~15 GB | ~15 GB | ~20 min | LOW-MEDIUM (registry auth may be needed) |

## eggNOG Server Risk

The eggNOG download server at `eggnog6.embl.de` returned empty replies for all HEAD
requests. This is a significant risk — if the server is down or has moved, the
eggNOG 5.0.2 database cannot be downloaded from this URL. Alternative sources or
mirrors should be investigated before attempting actual download.

## Container Registry Risk

Container images from `registry.git.embl.org` and `ghcr.io` may require authentication
tokens for registry API access. The `quay.io` images should be publicly accessible.
Without a container runtime (Singularity/Apptainer), SIF images cannot be built locally.

## Network Risk

Network access to Zenodo and GTDB was confirmed. Network access to eggNOG server failed.
Network access to container registries was not fully tested (registry API requires auth).

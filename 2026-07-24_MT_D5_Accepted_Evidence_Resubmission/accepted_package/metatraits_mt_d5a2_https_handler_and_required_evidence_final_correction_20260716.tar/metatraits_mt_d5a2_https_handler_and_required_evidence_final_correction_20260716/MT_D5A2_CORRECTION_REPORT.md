# MT-D5A2 Correction Report

## Scope

This is the teacher-assigned bounded MetaTraits pre-research correction. It is not training, checkpoint inference, production implementation, bulk database work, scoring, filtering or an Agent component. MT-D1--MT-D4 and MT-D6--MT-D8 remain unresolved.

## Inherited verified evidence

The verified D5 and D5A1 packages have manifest SHA256 `9f646442d7ccd8ac24de4feb446825309059a92be8ca9d5d60b3d002edcb9503` and `60e39ba5565f0ad411d2588eb86f561799d513a45e5c5e68b72653fd6188a478`. The accepted V1/P0, ten raw UniProt mappings, KEGG mappings, official contracts, API probes, D5A1 crash-safe ledger and corrected `tax_id` evidence were copied by hash. Old D5 attempts 66--180 lost required metadata and were not reconstructed. D5A1 recorded 24 local-client programming exceptions and zero HTTP responses; these are not classified as an endpoint outage. No UniProt, KEGG, official-page or `/api/v1` request was repeated.

UniProt primary accessions round-trip exactly for 10/10 fixed UIDs, independently of name comparison and KEGG conversion. KEGG conversion is single 7, missing 1 and multiple 2. `Sinorhizobium sp` versus `Sinorhizobium sp.` is a terminal-punctuation normalization match, not a biological conflict. All 16 inherited documented API logical probes have complete saved HTTP 404 evidence; this is a route-not-live finding, not missing evidence.

## Current D5A2 summary evidence

- `Q8EFP8`: HTTP 200; `raw/metatraits/samples/01_Q8EFP8/summary.json`
- `Q12WS1`: HTTP 200; `raw/metatraits/samples/02_Q12WS1/summary.json`
- `A0A0H3C8X0`: HTTP 200; `raw/metatraits/samples/03_A0A0H3C8X0/summary.json`
- `Q6BQK1`: HTTP 200; `raw/metatraits/samples/05_Q6BQK1/summary.json`
- `P71875`: HTTP 200; `raw/metatraits/samples/06_P71875/summary.json`

The five-sample bounded probe cannot establish production-wide coverage across all ten planned samples or all MetaTraits taxa. Raw changes relative to inherited bodies are freshness/stability findings, not automatic corruption.

## Current derived trait results

Current `majority_label` exactly equal to `No robust majority`: 43/597; percentage 7.202680%. Per-sample denominators are recorded conditionally. Wastewater groups were recomputed only from valid current bodies. Trait-record presence is not suitability, and missing coverage means unknown, not unsuitable.

## Source provenance and identifiers

- `Environmental_preferences`: 200; strict valid `true`
- `Metabolites`: 200; strict valid `true`

Actual observation fields are claimed only when the two valid bodies support them. Up to three matching current conflict examples were rebuilt; 3 were available. Inherited and current `tax_id` values show species-query collapse, so strain preservation is not claimed. No Mycobacterium observation page was requested; old partial bulk data remains historical and outside D5A2 collection.

## Stability and bounded rate observation

- repeat 1: HTTP 200, SHA256 `0d0eeecd9b5cd6314d71e680119b5fd155fac2980f59581436501ed2f42d0604`, semantic equality to repeat 1 `true`
- repeat 2: HTTP 200, SHA256 `0d0eeecd9b5cd6314d71e680119b5fd155fac2980f59581436501ed2f42d0604`, semantic equality to repeat 1 `true`
- repeat 3: HTTP 200, SHA256 `0d0eeecd9b5cd6314d71e680119b5fd155fac2980f59581436501ed2f42d0604`, semantic equality to repeat 1 `true`

D5A2 made 16 serial attempts. Evidence-class counts are {"HTTP_RESPONSE": 15, "TRANSIENT_NETWORK_EXCEPTION": 1} and HTTP status counts are {"200": 15}. D5A2 HTTP 429 evidence is `0`. D5 proves zero 429 only among 65 complete attempts with total UNKNOWN; D5A1 has `NOT_OBSERVABLE_NO_HTTP_RESPONSE`. No observed 429 establishes neither an unlimited API nor a threshold; threshold remains UNKNOWN.

## Corrected pagination boundary

Exhaustive Mycobacterium pagination exceeded the corrected bounded teacher scope. D5A2 collected only the two specified Shewanella page-zero bodies and did not continue bulk pagination.

## Unresolved proposals

Production readiness, biological host suitability, production-wide interface coverage, and MT-D1--MT-D4/MT-D6--MT-D8 decisions remain unresolved. No teacher-facing conclusion is made here.

#!/usr/bin/env python3
"""Portable, standard-library, read-only validator for MT-D5A2."""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import re
import stat
import sys
import tarfile
from pathlib import Path

D5_SHA = "9f646442d7ccd8ac24de4feb446825309059a92be8ca9d5d60b3d002edcb9503"
A1_SHA = "60e39ba5565f0ad411d2588eb86f561799d513a45e5c5e68b72653fd6188a478"
A1_COMPLETION_SHA = "abc305660bde2f7fdbeaafe8437c3433975ffca070df9db8b571b3ede1f27c08"
A1_VALIDATOR_SHA = "5995b4074b1fa35853a8a3c332f37cfe27f55d1bfef8f8f1247a647993f8a3ba"
READY = "MT_D5A2_READY_FOR_LOCAL_AUDIT_DOCUMENTED_API_UNAVAILABLE"
UIDS = ["Q8EFP8", "Q12WS1", "A0A0H3C8X0", "P29931", "Q6BQK1", "P71875", "S5SC42", "P76113", "C8WLM1", "Q02198"]
PLAN = [
    ("1", "Q8EFP8", "Shewanella oneidensis", "species", "0d0eeecd9b5cd6314d71e680119b5fd155fac2980f59581436501ed2f42d0604"),
    ("2", "Q12WS1", "Methanococcoides burtonii", "species", "c3da972bb5214ef65f9631b48882dbd8eec96e2ebe0edb38901856ae96ec9e6b"),
    ("3", "A0A0H3C8X0", "Caulobacter vibrioides", "species", "99ca0fb51622ba9d30eba9befabe6e90f96750eac96f1af31f8638807479a0e5"),
    ("5", "Q6BQK1", "Debaryomyces hansenii", "species", "28b4e749f70dafba8ad5ccf5c1948ce9ce8623709959687c4ebfd718ca1f8735"),
    ("6", "P71875", "Mycobacterium tuberculosis", "species", "414606627724f0ada3dcbc5be618291d94378fa60b0756e9dd62741fd4faa202"),
]
MEANINGS = [
    ("MTD5-R01", "accepted V1 input identity"), ("MTD5-R02", "deterministic P0 enzyme selection"),
    ("MTD5-R03", "P0-derived organism and raw UniProt evidence"), ("MTD5-R04", "UniProt/KEGG mapping coverage and boundaries"),
    ("MTD5-R05", "official MetaTraits surface inventory"), ("MTD5-R06", "documented API bounded probe"),
    ("MTD5-R07", "bounded website summary and source-provenance behavior"), ("MTD5-R08", "at least five HTTP-200 strict JSON summaries"),
    ("MTD5-R09", "three-repeat stability and bounded rate observation"), ("MTD5-R10", "identifier and taxonomic resolution"),
    ("MTD5-R11", "wastewater trait coverage"), ("MTD5-R12", "No robust majority and source conflicts"),
    ("MTD5-R13", "evidence-semantics audit"), ("MTD5-R14", "documentation/license/version/pagination/rate-policy contract"),
    ("MTD5-R15", "research-only scope compliance"), ("MTD5-R16", "independently auditable directory/tar/identity package"),
]
ALLOWED_STATUS = {"PASS_EVIDENCE_COMPLETE", "MISSING_REQUIRED_EVIDENCE", "NOT_COLLECTED_BLOCKED", "EXPLICITLY_OUTSIDE_CORRECTED_TEACHER_SCOPE"}


def digest(path: Path) -> tuple[int, str]:
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            size += len(block)
            h.update(block)
    return size, h.hexdigest()


def load(path: Path):
    def bad(value):
        raise ValueError(f"non-finite JSON constant {value}")
    with path.open(encoding="utf-8") as fh:
        return json.load(fh, parse_constant=bad)


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def fail(errors: list[str], code: str, detail: str = "") -> None:
    errors.append(code + (": " + detail if detail else ""))


def list_summary(path: Path) -> list[dict]:
    obj = load(path)
    if not isinstance(obj, list) or not all(isinstance(x, dict) for x in obj):
        raise ValueError("not a list of objects")
    return obj


def validate_transport(root: Path, return_tar: Path, identity: Path, errors: list[str]) -> None:
    try:
        pairs = {}
        for line in identity.read_text(encoding="utf-8").splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                pairs[key] = value
        tbytes, tsha = digest(return_tar)
        mbytes, msha = digest(root / "MANIFEST.sha256")
        if pairs.get("final_token") != (root / "FINAL_STATUS.txt").read_text().strip() or pairs.get("tar_bytes") != str(tbytes) or pairs.get("tar_sha256") != tsha or pairs.get("manifest_bytes") != str(mbytes) or pairs.get("manifest_sha256") != msha:
            fail(errors, "TAR_IDENTITY_MISMATCH")
        top = root.name
        expected_files = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()}
        with tarfile.open(return_tar, "r:") as tf:
            seen = set()
            regular = set()
            for member in tf.getmembers():
                if member.name in seen or member.name.startswith("/") or ".." in Path(member.name).parts or member.issym() or member.islnk() or not (member.isfile() or member.isdir()):
                    fail(errors, "TAR_MEMBER_UNSAFE", member.name)
                seen.add(member.name)
                if member.uid != 0 or member.gid != 0 or member.mtime != 0:
                    fail(errors, "TAR_METADATA_INVALID", member.name)
                mode = 0o755 if member.isdir() or (member.name.endswith(".py") and "/scripts/" in member.name) else 0o644
                if member.mode != mode:
                    fail(errors, "TAR_MODE_INVALID", member.name)
                if member.isfile():
                    rel = member.name.removeprefix(top + "/")
                    regular.add(rel)
                    body = tf.extractfile(member)
                    if body is None or hashlib.sha256(body.read()).hexdigest() != digest(root / rel)[1]:
                        fail(errors, "TAR_BODY_MISMATCH", rel)
            if regular != expected_files:
                fail(errors, "TAR_FILE_SET_MISMATCH")
    except Exception as exc:
        fail(errors, "TAR_VALIDATION_ERROR", str(exc))


def validate(root: Path, d5: Path | None, a1: Path | None, return_tar: Path | None, identity: Path | None) -> list[str]:
    errors: list[str] = []
    required = [
        "MT_D5A2_CORRECTION_REPORT.md", "inputs/inherited_d5_identity.json", "inputs/inherited_d5a1_identity.json",
        "inputs/inherited_file_identity.csv", "inputs/five_sample_completion_plan.csv", "outputs/https_handler_preflight.json",
        "outputs/query_manifest.csv", "outputs/summary_http_provenance.csv", "outputs/sample_interface_coverage.csv",
        "outputs/stability_repeat.csv", "outputs/rate_limit_observation.json", "outputs/identifier_resolution.csv",
        "outputs/mapping_reconciliation.json", "outputs/no_robust_majority_summary.csv", "outputs/wastewater_trait_coverage.csv",
        "outputs/wastewater_trait_matches.json", "outputs/source_conflict_examples.json", "outputs/evidence_semantics_audit.json",
        "outputs/scope_compliance.json", "outputs/execution_repair_log.json", "requirements/requirement_to_evidence_matrix.json",
        "scripts/mt_d5a2_completion.py", "scripts/validate_mt_d5a2.py", "evidence/environment.txt",
        "evidence/network_dns_tls_preflight.txt", "evidence/work_root_after_cleanup.txt",
    ]
    for rel in required:
        if not (root / rel).is_file():
            fail(errors, "REQUIRED_FILE_MISSING", rel)
    for p in root.rglob("*") if root.is_dir() else []:
        try:
            st = p.lstat()
            if stat.S_ISLNK(st.st_mode) or (not stat.S_ISREG(st.st_mode) and not stat.S_ISDIR(st.st_mode)):
                fail(errors, "UNSUPPORTED_FILE_TYPE", str(p.relative_to(root)))
            if stat.S_ISREG(st.st_mode) and st.st_size > 50 * 1024 * 1024:
                fail(errors, "FILE_TOO_LARGE", str(p.relative_to(root)))
            if stat.S_ISREG(st.st_mode) and any(x in p.name.casefold() for x in ["cookie", "credential", "__pycache__", ".pyc"]):
                fail(errors, "PROHIBITED_ARTIFACT", str(p.relative_to(root)))
        except OSError as exc:
            fail(errors, "FILE_STAT_FAILED", str(exc))
    if any(x.startswith("REQUIRED_FILE_MISSING") for x in errors):
        return errors

    try:
        di = load(root / "inputs/inherited_d5_identity.json")
        ai = load(root / "inputs/inherited_d5a1_identity.json")
        if di.get("manifest_sha256") != D5_SHA or di.get("regular_file_count") != 401 or di.get("manifest_check_result") != "PASS_ALL_LISTED_MEMBERS":
            fail(errors, "D5_INHERITED_IDENTITY_MISMATCH")
        if ai.get("manifest_sha256") != A1_SHA or ai.get("regular_file_count") != 101 or ai.get("completion_script_sha256") != A1_COMPLETION_SHA or ai.get("validator_script_sha256") != A1_VALIDATOR_SHA:
            fail(errors, "D5A1_INHERITED_IDENTITY_MISMATCH")
        if d5 is None or digest(d5 / "MANIFEST.sha256")[1] != D5_SHA:
            fail(errors, "D5_ROOT_IDENTITY_MISMATCH")
        if a1 is None or digest(a1 / "MANIFEST.sha256")[1] != A1_SHA:
            fail(errors, "D5A1_ROOT_IDENTITY_MISMATCH")
    except Exception as exc:
        fail(errors, "INHERITED_IDENTITY_INVALID", str(exc))
    try:
        copied = rows(root / "inputs/inherited_file_identity.csv")
        if len(copied) != 25:
            fail(errors, "COPIED_FILE_IDENTITY_COUNT", str(len(copied)))
        for row in copied:
            p = root / row["copied_path"]
            if row.get("equality") != "true" or not p.is_file() or digest(p)[1] != row.get("copied_sha256") or row.get("copied_sha256") != row.get("source_sha256"):
                fail(errors, "COPIED_FILE_IDENTITY_MISMATCH", row.get("copied_path", ""))
    except Exception as exc:
        fail(errors, "COPIED_FILE_IDENTITY_INVALID", str(exc))
    try:
        plan = rows(root / "inputs/five_sample_completion_plan.csv")
        if [(x["order"], x["UID"], x["query"], x["rank"], x["old_summary_sha256"]) for x in plan] != PLAN:
            fail(errors, "FIXED_SAMPLE_PLAN_MISMATCH")
    except Exception as exc:
        fail(errors, "FIXED_SAMPLE_PLAN_INVALID", str(exc))

    try:
        pf = load(root / "outputs/https_handler_preflight.json")
        if pf.get("result") != "PASS" or pf.get("context_check_hostname") is not True or pf.get("context_verify_mode") != pf.get("context_verify_mode_expected") or pf.get("context_verify_mode") != 2 or pf.get("handler_has_usable_context") is not True or pf.get("handler_ast_accesses_forbidden_private_hostname_attribute") is not False or pf.get("connect_timeout_intent_seconds") != 10 or pf.get("read_timeout_intent_seconds") != 30:
            fail(errors, "HTTPS_HANDLER_PREFLIGHT_INVALID")
        tree = ast.parse((root / "scripts/mt_d5a2_completion.py").read_text(encoding="utf-8"))
        handler = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "TimedHTTPSHandler"), None)
        if handler is None or any(isinstance(n, ast.Attribute) and n.attr == "_check_hostname" for n in ast.walk(handler)):
            fail(errors, "HANDLER_FORBIDDEN_CHECK_HOSTNAME_ACCESS")
    except Exception as exc:
        fail(errors, "HTTPS_HANDLER_PREFLIGHT_PARSE_INVALID", str(exc))

    ledger: list[dict[str, str]] = []
    by_body: dict[str, dict[str, str]] = {}
    try:
        ledger = rows(root / "outputs/query_manifest.csv")
        expected = [f"D5A2_REQ{i:03d}" for i in range(1, len(ledger) + 1)]
        if [x.get("request_id") for x in ledger] != expected or len(ledger) > 40:
            fail(errors, "REQUEST_ID_OR_CAP_INVALID")
        required_fields = ["utc_start", "utc_end", "method", "url", "user_agent", "attempt", "evidence_class", "elapsed_seconds", "response_headers_path", "response_headers_bytes", "response_headers_sha256", "response_body_path", "response_body_bytes", "response_body_sha256"]
        for index, row in enumerate(ledger):
            rid = row.get("request_id", "")
            if any(not row.get(key, "") for key in required_fields):
                fail(errors, "REQUEST_ELAPSED_MISSING" if not row.get("elapsed_seconds") else "REQUEST_METADATA_INCOMPLETE", rid)
            cls = row.get("evidence_class")
            if cls not in {"HTTP_RESPONSE", "TRANSIENT_NETWORK_EXCEPTION", "LOCAL_CLIENT_PROGRAMMING_EXCEPTION"}:
                fail(errors, "REQUEST_EVIDENCE_CLASS_INVALID", rid)
            if cls == "HTTP_RESPONSE" and (not row.get("http_status") or row.get("network_exception")):
                fail(errors, "HTTP_RESPONSE_CLASS_INVALID", rid)
            if cls != "HTTP_RESPONSE" and (row.get("http_status") or not row.get("network_exception")):
                fail(errors, "EXCEPTION_CLASS_INVALID", rid)
            if cls == "LOCAL_CLIENT_PROGRAMMING_EXCEPTION" and index + 1 < len(ledger) and ledger[index + 1].get("url") == row.get("url") and ledger[index + 1].get("attempt") == "2":
                fail(errors, "PROGRAMMING_EXCEPTION_RETRIED", rid)
            if cls == "TRANSIENT_NETWORK_EXCEPTION" and row.get("attempt") not in {"1", "2"}:
                fail(errors, "TRANSIENT_RETRY_COUNT_INVALID", rid)
            if cls == "TRANSIENT_NETWORK_EXCEPTION":
                following = ledger[index + 1] if index + 1 < len(ledger) else None
                if row.get("attempt") != "1" or following is None or following.get("url") != row.get("url") or following.get("method") != row.get("method") or following.get("attempt") != "2":
                    fail(errors, "TRANSIENT_RETRY_BINDING_INVALID", rid)
            if cls != "HTTP_RESPONSE" and int(row.get("response_body_bytes", "-1")) == 0 and not row.get("response_body_path", "").endswith(".body"):
                fail(errors, "EXCEPTION_EMPTY_BODY_NAME_INVALID", rid)
            try:
                float(row["elapsed_seconds"])
            except ValueError:
                fail(errors, "REQUEST_NUMERIC_METADATA_INVALID", rid)
            for key, sha_key, size_key in [("response_body_path", "response_body_sha256", "response_body_bytes"), ("response_headers_path", "response_headers_sha256", "response_headers_bytes")]:
                p = root / row.get(key, "")
                if not p.is_file():
                    fail(errors, "REQUEST_EVIDENCE_FILE_MISSING", f"{rid} {key}")
                elif digest(p) != (int(row[size_key]), row[sha_key]):
                    fail(errors, "REQUEST_EVIDENCE_IDENTITY_MISMATCH", f"{rid} {key}")
            by_body[row.get("response_body_path", "")] = row
    except Exception as exc:
        fail(errors, "REQUEST_LEDGER_INVALID", str(exc))

    summaries: list[tuple[dict[str, str], list[dict]]] = []
    try:
        prov = rows(root / "outputs/summary_http_provenance.csv")
        if len(prov) != 5:
            fail(errors, "SUMMARY_PROVENANCE_COUNT", str(len(prov)))
        for row in prov:
            if row.get("http_status") != "200":
                fail(errors, "SUMMARY_STATUS_NOT_200", row.get("UID", ""))
            if row.get("strict_json") != "true" or row.get("top_level_list_of_objects") != "true":
                fail(errors, "SUMMARY_STRICT_JSON_INVALID", row.get("UID", ""))
            if "json" not in row.get("content_type", "").casefold():
                fail(errors, "SUMMARY_CONTENT_TYPE_INVALID", row.get("UID", ""))
            p = root / row["raw_body_path"]
            obj = list_summary(p)
            size, sha = digest(p)
            if str(size) != row.get("body_bytes") or sha != row.get("body_sha256") or str(len(obj)) != row.get("summary_record_count"):
                fail(errors, "SUMMARY_BODY_IDENTITY_OR_COUNT_MISMATCH", row.get("UID", ""))
            led = by_body.get(row["raw_body_path"])
            if led is None or led.get("evidence_class") != "HTTP_RESPONSE" or led.get("http_status") != "200" or led.get("response_body_sha256") != sha:
                fail(errors, "SUMMARY_LEDGER_BINDING_INVALID", row.get("UID", ""))
            summaries.append((row, obj))
    except Exception as exc:
        fail(errors, "SUMMARY_PROVENANCE_INVALID", str(exc))
    try:
        coverage = rows(root / "outputs/sample_interface_coverage.csv")
        if len(coverage) != 10 or [x.get("UID") for x in coverage] != UIDS or sum(x.get("collection_class") == "D5A2_NEW" and x.get("summary_HTTP_status") == "200" for x in coverage) != 5:
            fail(errors, "SAMPLE_INTERFACE_SUCCESS_COUNT_INVALID")
    except Exception as exc:
        fail(errors, "SAMPLE_INTERFACE_INVALID", str(exc))

    observation_rows = []
    for tab in ["Environmental_preferences", "Metabolites"]:
        try:
            matches = [x for x in ledger if f"tab={tab}" in x.get("url", "") and "start=0" in x.get("url", "") and "length=500" in x.get("url", "")]
            if len(matches) != 1 or matches[0].get("http_status") != "200" or matches[0].get("evidence_class") != "HTTP_RESPONSE":
                fail(errors, "OBSERVATION_PAGE_STATUS_INVALID", tab)
                continue
            obj = load(root / matches[0]["response_body_path"])
            if not isinstance(obj, dict) or not isinstance(obj.get("data"), list) or "json" not in matches[0].get("content_type", "").casefold():
                fail(errors, "OBSERVATION_PAGE_JSON_INVALID", tab)
                continue
            observation_rows.extend(x for x in obj["data"] if isinstance(x, dict))
        except Exception as exc:
            fail(errors, "OBSERVATION_PAGE_INVALID", f"{tab}: {exc}")
    if observation_rows and not {"database_record", "record_url", "tax_id", "trait", "value"}.issubset({k for x in observation_rows for k in x}):
        fail(errors, "OBSERVATION_FIELDS_MISSING")

    try:
        repeats = rows(root / "outputs/stability_repeat.csv")
        if len(repeats) != 3 or [x.get("repeat") for x in repeats] != ["1", "2", "3"]:
            fail(errors, "STABILITY_ROW_COUNT_INVALID")
        first = None
        for index, row in enumerate(repeats):
            if row.get("status") != "200" or row.get("strict_json") != "true" or "json" not in row.get("content_type", "").casefold():
                fail(errors, "STABILITY_STATUS_OR_JSON_INVALID", row.get("repeat", ""))
            obj = list_summary(root / row["raw_body_path"])
            if digest(root / row["raw_body_path"])[1] != row.get("body_sha256"):
                fail(errors, "STABILITY_HASH_MISMATCH", row.get("repeat", ""))
            if index == 0:
                first = obj
            if row.get("semantic_equal_to_repeat_1") != str(obj == first).lower():
                fail(errors, "STABILITY_SEMANTIC_MISMATCH", row.get("repeat", ""))
    except Exception as exc:
        fail(errors, "STABILITY_INVALID", str(exc))

    try:
        rate = load(root / "outputs/rate_limit_observation.json")
        if rate.get("rate_limit_threshold") != "UNKNOWN":
            fail(errors, "RATE_THRESHOLD_UNSUPPORTED")
        if rate.get("old_d5", {}).get("total_old_http_429") != "UNKNOWN" or rate.get("d5a1", {}).get("http_429_count") != "NOT_OBSERVABLE_NO_HTTP_RESPONSE":
            fail(errors, "RATE_INHERITED_CLASSES_INVALID")
        d2 = rate.get("d5a2", {})
        response_count = sum(x.get("evidence_class") == "HTTP_RESPONSE" for x in ledger)
        expected_429 = sum(x.get("http_status") == "429" for x in ledger) if response_count else "NOT_OBSERVABLE_NO_HTTP_RESPONSE"
        if d2.get("total_attempts") != len(ledger) or d2.get("completed_http_responses") != response_count or d2.get("http_429_count") != expected_429:
            fail(errors, "RATE_EVIDENCE_CLASS_INVALID")
    except Exception as exc:
        fail(errors, "RATE_JSON_INVALID", str(exc))

    try:
        idrows = rows(root / "outputs/identifier_resolution.csv")
        if len(idrows) != 10 or [x.get("UID") for x in idrows] != UIDS:
            fail(errors, "IDENTIFIER_TEN_ROW_INVALID")
        minimum = {"Q8EFP8": {"70863", "211586"}, "Q12WS1": {"259564"}, "Q6BQK1": {"284592", "1118155"}}
        for uid, need in minimum.items():
            got = {x for x in next(r for r in idrows if r["UID"] == uid)["distinct_observation_taxon_IDs"].split(";") if x}
            if not need.issubset(got):
                fail(errors, "IDENTIFIER_TAX_ID_MISSING", uid)
        mapping = load(root / "outputs/mapping_reconciliation.json")
        if mapping.get("uniprot_accession_resolution") != {"exact": 10, "missing": 0} or mapping.get("kegg_conversion") != {"single": 7, "missing": 1, "multiple": 2} or mapping.get("confidence_calculated") is not False or "confidence" in mapping.get("dimensions_merged", "").casefold():
            fail(errors, "MAPPING_DIMENSION_INVALID")
    except Exception as exc:
        fail(errors, "IDENTIFIER_MAPPING_INVALID", str(exc))

    try:
        nrows = rows(root / "outputs/no_robust_majority_summary.csv")
        if len(nrows) != 6:
            fail(errors, "NO_ROBUST_MAJORITY_ROW_COUNT_INVALID")
        total = nrm = 0
        for (prov, records), row in zip(summaries, nrows[:5]):
            calc = sum(x.get("majority_label") == "No robust majority" for x in records)
            if row.get("UID") != prov.get("UID") or int(row["total_summary_records"]) != len(records) or int(row["no_robust_majority_count"]) != calc:
                fail(errors, "NO_ROBUST_MAJORITY_UNREPRODUCIBLE", prov.get("UID", ""))
            total += len(records); nrm += calc
        agg = nrows[-1]
        if agg.get("UID") != "AGGREGATE" or int(agg["total_summary_records"]) != total or int(agg["no_robust_majority_count"]) != nrm:
            fail(errors, "NO_ROBUST_MAJORITY_AGGREGATE_INVALID")
        if total == 0 and agg.get("no_robust_majority_percentage") != "UNAVAILABLE_NO_VALID_SUMMARY":
            fail(errors, "ZERO_DENOMINATOR_REPRESENTED_AS_PERCENT")
    except Exception as exc:
        fail(errors, "NO_ROBUST_MAJORITY_INVALID", str(exc))
    try:
        ww = load(root / "outputs/wastewater_trait_matches.json")
        groups = ww.get("disclosed_matching_groups", {})
        cov = rows(root / "outputs/wastewater_trait_coverage.csv")
        if len(cov) != 5 * len(groups):
            fail(errors, "WASTEWATER_ROW_COUNT_INVALID")
        lookup = {(x["UID"], x["category"]): x for x in cov}
        for prov, records in summaries:
            for category, patterns in groups.items():
                matched = [x for x in records if str(x.get("name", "")) and any(re.search(p, str(x.get("name", "")), re.I) for p in patterns)]
                names = sorted({str(x.get("name")) for x in matched})
                row = lookup.get((prov["UID"], category), {})
                if int(row.get("matched_record_count", -1)) != len(matched) or sorted(x for x in row.get("exact_matched_trait_names", "").split(";") if x) != names:
                    fail(errors, "WASTEWATER_COUNTS_UNREPRODUCIBLE", f"{prov['UID']} {category}")
        sem = load(root / "outputs/evidence_semantics_audit.json")
        if sem.get("invented_three_state_field") is not False or not {"database_record", "record_url", "tax_id", "trait", "value"}.issubset(set(sem.get("actual_observation_fields", []))):
            fail(errors, "EVIDENCE_SEMANTICS_UNSUPPORTED")
    except Exception as exc:
        fail(errors, "WASTEWATER_SEMANTICS_INVALID", str(exc))

    try:
        matrix = load(root / "requirements/requirement_to_evidence_matrix.json")
        if not isinstance(matrix, list) or len(matrix) != 16:
            fail(errors, "REQUIREMENT_MATRIX_COUNT_INVALID")
        else:
            final_exists = (root / "FINAL_STATUS.txt").exists()
            for row, (rid, meaning) in zip(matrix, MEANINGS):
                if row.get("requirement_id") != rid or row.get("meaning") != meaning:
                    fail(errors, "REQUIREMENT_MEANING_MISMATCH", rid)
                if row.get("evidence_status") not in ALLOWED_STATUS:
                    fail(errors, "REQUIREMENT_STATUS_INVALID", rid)
                if final_exists and (root / "FINAL_STATUS.txt").read_text().strip() == READY and row.get("evidence_status") != "PASS_EVIDENCE_COMPLETE":
                    fail(errors, "READY_REQUIREMENT_NOT_PASS", rid)
                if not final_exists and rid == "MTD5-R16" and row.get("evidence_status") != "NOT_COLLECTED_BLOCKED":
                    fail(errors, "BASELINE_R16_STATUS_INVALID")
    except Exception as exc:
        fail(errors, "REQUIREMENT_MATRIX_INVALID", str(exc))
    try:
        scope = load(root / "outputs/scope_compliance.json")
        keys = ["gpu_requested_or_used", "checkpoint_inference_training_evaluation", "portraits_or_bulk_database_workflow", "production_implementation", "credentials_packaged", "cookie_files_remaining", "bulk_observation_pagination_continued"]
        if any(scope.get(key) is not False for key in keys) or scope.get("mycobacterium_observation_request_count") != 0:
            fail(errors, "SCOPE_COMPLIANCE_INVALID")
    except Exception as exc:
        fail(errors, "SCOPE_JSON_INVALID", str(exc))

    report = (root / "MT_D5A2_CORRECTION_REPORT.md").read_text(encoding="utf-8")
    if re.search(r"0/0\s*\([^)]*0(?:\.0+)?%", report) or "local client programming failure is an endpoint network outage" in report.casefold():
        fail(errors, "REPORT_STATIC_FALSE_CLAIM")
    neg = root / "logs/negative_tests.csv"
    if neg.exists():
        try:
            nr = rows(neg)
            if len(nr) != 5 or sum(x.get("baseline_exit") == "0" and x.get("exit_code") == "1" and x.get("rejected") == "true" and x.get("observed_expected_diagnostic") == "true" for x in nr) != 5:
                fail(errors, "NEGATIVE_TESTS_NOT_ALL_REJECTED")
        except Exception as exc:
            fail(errors, "NEGATIVE_TEST_LOG_INVALID", str(exc))
    final = root / "FINAL_STATUS.txt"
    if final.exists() and final.read_text().strip() == READY:
        if not neg.exists():
            fail(errors, "READY_NEGATIVE_TESTS_MISSING")
        if any(x.get("evidence_class") == "LOCAL_CLIENT_PROGRAMMING_EXCEPTION" for x in ledger):
            fail(errors, "READY_LOCAL_CLIENT_PROGRAMMING_EXCEPTION_PRESENT")

    manifest = root / "MANIFEST.sha256"
    if manifest.exists():
        expected = {}
        for line in manifest.read_text(encoding="utf-8").splitlines():
            try:
                sha, rel = line.split("  ", 1)
            except ValueError:
                fail(errors, "MANIFEST_LINE_INVALID", line); continue
            if rel in expected:
                fail(errors, "MANIFEST_DUPLICATE_PATH", rel)
            expected[rel] = sha
        actual = sorted(str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and p != manifest)
        if sorted(expected) != actual:
            fail(errors, "MANIFEST_FILE_SET_MISMATCH")
        for rel, sha in expected.items():
            if (root / rel).is_file() and digest(root / rel)[1] != sha:
                fail(errors, "MANIFEST_HASH_MISMATCH", rel)
    if (return_tar is None) != (identity is None):
        fail(errors, "TRANSPORT_ARGUMENTS_INCOMPLETE")
    elif return_tar is not None and identity is not None:
        validate_transport(root, return_tar, identity, errors)
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--inherited-d5", type=Path)
    parser.add_argument("--inherited-d5a1", type=Path)
    parser.add_argument("--return-tar", type=Path)
    parser.add_argument("--tar-identity", type=Path)
    args = parser.parse_args()
    errors = validate(args.package_root.resolve(), args.inherited_d5.resolve() if args.inherited_d5 else None, args.inherited_d5a1.resolve() if args.inherited_d5a1 else None, args.return_tar.resolve() if args.return_tar else None, args.tar_identity.resolve() if args.tar_identity else None)
    if errors:
        for item in errors:
            print(item, file=sys.stderr)
        return 1
    print("MT_D5A2_VALIDATION_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

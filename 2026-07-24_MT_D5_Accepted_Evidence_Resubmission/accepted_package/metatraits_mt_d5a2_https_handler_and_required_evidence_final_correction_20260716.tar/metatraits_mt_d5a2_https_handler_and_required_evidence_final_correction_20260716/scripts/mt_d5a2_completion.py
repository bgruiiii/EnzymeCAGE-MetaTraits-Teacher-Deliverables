#!/usr/bin/env python3
"""Execute the bounded MT-D5A2 HTTPS correction and build its transport."""

from __future__ import annotations

import csv
import ast
import hashlib
import http.client
import http.cookiejar
import json
import os
import platform
import re
import shutil
import socket
import ssl
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

PY = Path("/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python")
RETURN_PARENT = Path("/root/projects/EnzymeCAGE-master/HPC_Returned_Result_Summaries")
OLD_D5 = RETURN_PARENT / "metatraits_mt_d5_interface_coverage_probe_20260716"
OLD_D5_TAR = RETURN_PARENT / "metatraits_mt_d5_interface_coverage_probe_20260716.tar"
OLD_D5_IDENTITY = RETURN_PARENT / "metatraits_mt_d5_interface_coverage_probe_20260716.tar.identity.txt"
OLD_D5A1 = RETURN_PARENT / "metatraits_mt_d5a1_required_raw_evidence_completion_20260716"
OLD_D5A1_TAR = RETURN_PARENT / "metatraits_mt_d5a1_required_raw_evidence_completion_20260716.tar"
OLD_D5A1_IDENTITY = RETURN_PARENT / "metatraits_mt_d5a1_required_raw_evidence_completion_20260716.tar.identity.txt"
ROOT = RETURN_PARENT / "metatraits_mt_d5a2_https_handler_and_required_evidence_final_correction_20260716"
RETURN_TAR = RETURN_PARENT / "metatraits_mt_d5a2_https_handler_and_required_evidence_final_correction_20260716.tar"
TAR_IDENTITY = RETURN_PARENT / "metatraits_mt_d5a2_https_handler_and_required_evidence_final_correction_20260716.tar.identity.txt"
WORK = Path("/tmp/metatraits_mt_d5a2_https_handler_and_required_evidence_final_correction_20260716")
UA = "EnzymeCAGE-MT-D5A2-https-final-correction/20260716"
D5_MANIFEST_SHA = "9f646442d7ccd8ac24de4feb446825309059a92be8ca9d5d60b3d002edcb9503"
D5A1_MANIFEST_SHA = "60e39ba5565f0ad411d2588eb86f561799d513a45e5c5e68b72653fd6188a478"
D5A1_COMPLETION_SHA = "abc305660bde2f7fdbeaafe8437c3433975ffca070df9db8b571b3ede1f27c08"
D5A1_VALIDATOR_SHA = "5995b4074b1fa35853a8a3c332f37cfe27f55d1bfef8f8f1247a647993f8a3ba"
READY = "MT_D5A2_READY_FOR_LOCAL_AUDIT_DOCUMENTED_API_UNAVAILABLE"
BLOCKED_CLIENT = "MT_D5A2_BLOCKED_CLIENT_IMPLEMENTATION"
BLOCKED_NETWORK = "MT_D5A2_BLOCKED_NETWORK_OR_REQUIRED_RAW_EVIDENCE"
BLOCKED_SCOPE = "MT_D5A2_BLOCKED_SCOPE_OR_VALIDATOR"

UIDS = ["Q8EFP8", "Q12WS1", "A0A0H3C8X0", "P29931", "Q6BQK1", "P71875", "S5SC42", "P76113", "C8WLM1", "Q02198"]
QUERY_PLAN = [
    (1, "Q8EFP8", "Shewanella oneidensis"),
    (2, "Q12WS1", "Methanococcoides burtonii"),
    (3, "A0A0H3C8X0", "Caulobacter vibrioides"),
    (4, "P29931", "Sinorhizobium sp."),
    (5, "Q6BQK1", "Debaryomyces hansenii"),
    (6, "P71875", "Mycobacterium tuberculosis"),
    (7, "S5SC42", "Sphingobium sp."),
    (8, "P76113", "Escherichia coli"),
    (9, "C8WLM1", "Eggerthella lenta"),
    (10, "Q02198", "Pseudomonas putida"),
]
FIVE = [
    (1, "Q8EFP8", "Shewanella oneidensis", "species", "0d0eeecd9b5cd6314d71e680119b5fd155fac2980f59581436501ed2f42d0604"),
    (2, "Q12WS1", "Methanococcoides burtonii", "species", "c3da972bb5214ef65f9631b48882dbd8eec96e2ebe0edb38901856ae96ec9e6b"),
    (3, "A0A0H3C8X0", "Caulobacter vibrioides", "species", "99ca0fb51622ba9d30eba9befabe6e90f96750eac96f1af31f8638807479a0e5"),
    (5, "Q6BQK1", "Debaryomyces hansenii", "species", "28b4e749f70dafba8ad5ccf5c1948ce9ce8623709959687c4ebfd718ca1f8735"),
    (6, "P71875", "Mycobacterium tuberculosis", "species", "414606627724f0ada3dcbc5be618291d94378fa60b0756e9dd62741fd4faa202"),
]
INHERITED_D5_FILES = [
    "FINAL_STATUS.txt", "MANIFEST.sha256", "inputs/v1_test_table_identity.csv",
    "inputs/top_mrr_enzyme_candidates.csv", "inputs/selected_seed_rows.csv",
    "inputs/organism_query_plan.csv", "outputs/enzyme_organism_mapping.csv",
    "outputs/mapping_source_summary.json", "outputs/documented_api_probe.csv",
    "outputs/no_robust_majority_summary.csv", "outputs/source_conflict_examples.json",
    "outputs/evidence_semantics_audit.json", "outputs/documentation_contract.json",
    "outputs/wastewater_trait_coverage.csv", "outputs/wastewater_trait_matches.json",
]
INHERITED_D5A1_FILES = [
    "FINAL_STATUS.txt", "MANIFEST.sha256", "inputs/inherited_package_identity.json",
    "outputs/query_manifest.csv", "outputs/identifier_resolution.csv",
    "outputs/mapping_reconciliation.json", "outputs/scope_compliance.json",
    "evidence/network_dns_tls_preflight.txt", "scripts/mt_d5a1_completion.py",
    "scripts/validate_mt_d5a1.py",
]
MEANINGS = [
    ("MTD5-R01", "accepted V1 input identity"), ("MTD5-R02", "deterministic P0 enzyme selection"),
    ("MTD5-R03", "P0-derived organism and raw UniProt evidence"), ("MTD5-R04", "UniProt/KEGG mapping coverage and boundaries"),
    ("MTD5-R05", "official MetaTraits surface inventory"), ("MTD5-R06", "documented API bounded probe"),
    ("MTD5-R07", "bounded website summary and source-provenance behavior"), ("MTD5-R08", "at least five HTTP-200 strict JSON summaries"),
    ("MTD5-R09", "three-repeat stability and bounded rate observation"), ("MTD5-R10", "identifier and taxonomic resolution"),
    ("MTD5-R11", "wastewater trait coverage"), ("MTD5-R12", "No robust majority and source conflicts"),
    ("MTD5-R13", "evidence-semantics audit"), ("MTD5-R14", "documentation/license/version/pagination/rate-policy contract"),
    ("MTD5-R15", "research-only scope compliance"), ("MTD5-R16", "independently auditable directory/tar/identity package"),
]
WW_GROUPS = {
    "oxygen/atmosphere": [r"oxygen preference", r"obligate aerobic", r"obligate anaerobic", r"facultative anaerobe", r"aerotolerant", r"\baerobic\b", r"\banaerobic\b"],
    "temperature": [r"temperature", r"psychrophil", r"thermophil", r"mesophil"],
    "pH": [r"^ph$", r"^ph[ _-]", r"[ _-]ph$", r"\bph (?:preference|range|optimum|minimum|maximum)\b"],
    "salinity": [r"salinity", r"nacl", r"halophil", r"halotolerant"],
    "biofilm": [r"biofilm"],
    "safety/pathogenicity": [r"biosafety", r"pathogen", r"pathogenic", r"hemolysis"],
    "wastewater metabolism": [r"degradation", r"denitrification", r"nitrification", r"oxidation", r"reduction", r"respiration", r"electron acceptor", r"electron donor", r"fermentation"],
}


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest(path: Path) -> tuple[int, str]:
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            size += len(block)
            h.update(block)
    return size, h.hexdigest()


def strict_load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"), parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"non-finite {x}")))


def strict_bytes(data: bytes):
    return json.loads(data.decode("utf-8"), parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"non-finite {x}")))


def strict_dump(obj, path: Path) -> None:
    atomic_write(path, (json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n").encode())


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("wb") as fh:
        fh.write(data)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)
    dfd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(dfd)
    finally:
        os.close(dfd)


def write_csv(path: Path, fields: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)
    dfd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(dfd)
    finally:
        os.close(dfd)


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT))


def parse_manifest(root: Path) -> dict[str, str]:
    result = {}
    for line in (root / "MANIFEST.sha256").read_text(encoding="utf-8").splitlines():
        sha, name = line.split("  ", 1)
        result[name] = sha
    return result


def verify_transport(tar_path: Path, identity_path: Path, manifest_sha: str, absent_label: str) -> dict:
    if not tar_path.exists() and not identity_path.exists():
        return {"availability": absent_label}
    if not tar_path.is_file() or not identity_path.is_file():
        raise RuntimeError("INHERITED_TRANSPORT_PARTIAL")
    pairs = {}
    for line in identity_path.read_text(encoding="utf-8").splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            pairs[key] = value
    size, sha = digest(tar_path)
    if str(size) != pairs.get("tar_bytes") or sha != pairs.get("tar_sha256") or pairs.get("manifest_sha256") != manifest_sha:
        raise RuntimeError("INHERITED_TRANSPORT_IDENTITY_INVALID")
    return {"availability": "VERIFIED", "tar_bytes": size, "tar_sha256": sha, "identity_sha256": digest(identity_path)[1]}


def verify_package(root: Path, token: str, manifest_sha: str, regular_count: int, member_count: int) -> dict[str, str]:
    if not root.is_dir() or (root / "FINAL_STATUS.txt").read_text().strip() != token:
        raise RuntimeError(f"INHERITED_FINAL_STATUS_INVALID {root.name}")
    if digest(root / "MANIFEST.sha256")[1] != manifest_sha:
        raise RuntimeError(f"INHERITED_MANIFEST_SHA_INVALID {root.name}")
    manifest_map = parse_manifest(root)
    failures = [name for name, expected in manifest_map.items() if not (root / name).is_file() or digest(root / name)[1] != expected]
    count = sum(1 for p in root.rglob("*") if p.is_file())
    if failures or count != regular_count or len(manifest_map) != member_count:
        raise RuntimeError(f"INHERITED_MANIFEST_CHECK_FAILED {root.name} failures={failures} count={count} entries={len(manifest_map)}")
    return manifest_map


def verify_old_gate() -> tuple[dict[str, str], dict[str, str], dict, dict]:
    if not PY.is_file() or not os.access(PY, os.X_OK):
        raise RuntimeError("PY_NOT_EXECUTABLE")
    d5_map = verify_package(OLD_D5, "MT_D5_BLOCKED_NETWORK_OR_REQUIRED_RAW_EVIDENCE", D5_MANIFEST_SHA, 401, 400)
    a1_map = verify_package(OLD_D5A1, "MT_D5A1_BLOCKED_NETWORK_OR_REQUIRED_RAW_EVIDENCE", D5A1_MANIFEST_SHA, 101, 100)
    if digest(OLD_D5A1 / "scripts/mt_d5a1_completion.py")[1] != D5A1_COMPLETION_SHA or digest(OLD_D5A1 / "scripts/validate_mt_d5a1.py")[1] != D5A1_VALIDATOR_SHA:
        raise RuntimeError("D5A1_SCRIPT_IDENTITY_INVALID")
    d5_tar = verify_transport(OLD_D5_TAR, OLD_D5_IDENTITY, D5_MANIFEST_SHA, "OLD_D5_TRANSPORT_NOT_AVAILABLE")
    a1_tar = verify_transport(OLD_D5A1_TAR, OLD_D5A1_IDENTITY, D5A1_MANIFEST_SHA, "OLD_D5A1_TRANSPORT_NOT_AVAILABLE")
    return d5_map, a1_map, d5_tar, a1_tar


class RedirectTracker(urllib.request.HTTPRedirectHandler):
    def __init__(self):
        super().__init__()
        self.chain: list[dict] = []

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        self.chain.append({"status": code, "from": req.full_url, "to": newurl})
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class TimedHTTPSConnection(http.client.HTTPSConnection):
    def connect(self):
        self.timeout = 10
        super().connect()
        if self.sock is not None:
            self.sock.settimeout(30)


class TimedHTTPSHandler(urllib.request.HTTPSHandler):
    def __init__(self, context: ssl.SSLContext):
        super().__init__(context=context)
        self._context = context

    def https_open(self, req):
        return self.do_open(TimedHTTPSConnection, req, context=self._context)


class ClientImplementationFailure(RuntimeError):
    pass


class CanaryNetworkFailure(RuntimeError):
    pass


class Recorder:
    fields = [
        "request_id", "utc_start", "utc_end", "method", "url", "request_body_sha256", "request_body_bytes",
        "user_agent", "attempt", "evidence_class", "http_status", "network_exception", "elapsed_seconds", "content_type", "etag",
        "last_modified", "cache_control", "retry_after", "rate_limit_headers", "response_headers_path",
        "response_headers_bytes", "response_headers_sha256", "response_body_path", "response_body_bytes",
        "response_body_sha256", "redirect_chain",
    ]

    def __init__(self):
        self.rows: list[dict[str, str]] = []
        self.count = 0
        self.last_host: dict[str, float] = {}
        self.sessions: dict[str, tuple[http.cookiejar.MozillaCookieJar, Path]] = {}
        self.ssl_context = ssl.create_default_context()

    def session(self, name: str):
        if name not in self.sessions:
            path = WORK / f"anonymous_session_{name}.cookies"
            jar = http.cookiejar.MozillaCookieJar(str(path))
            self.sessions[name] = (jar, path)
        return self.sessions[name]

    def close_session(self, name: str) -> None:
        item = self.sessions.pop(name, None)
        if item:
            jar, path = item
            jar.clear()
            if path.exists():
                path.unlink()

    def close_all(self) -> None:
        for name in list(self.sessions):
            self.close_session(name)
        for p in WORK.rglob("*") if WORK.exists() else []:
            if p.is_file() and "cookies" in p.name:
                p.unlink()

    def spacing(self, host: str, minimum: float) -> None:
        if host in self.last_host:
            delay = minimum - (time.monotonic() - self.last_host[host])
            if delay > 0:
                time.sleep(delay)

    @staticmethod
    def attempt_path(base: Path, attempt: int) -> Path:
        return base if attempt == 1 else Path(str(base) + f".attempt{attempt}")

    def flush(self) -> None:
        write_csv(ROOT / "outputs/query_manifest.csv", self.fields, self.rows)

    def one(self, method: str, url: str, body_path: Path, headers_path: Path, session_name: str, attempt: int, minimum: float, request_body: bytes | None = None):
        if self.count >= 40:
            raise ClientImplementationFailure("D5A2_ATTEMPT_CAP_REACHED")
        parsed = urllib.parse.urlsplit(url)
        self.spacing(parsed.netloc, minimum)
        self.count += 1
        rid = f"D5A2_REQ{self.count:03d}"
        body_path = self.attempt_path(body_path, attempt)
        headers_path = self.attempt_path(headers_path, attempt)
        start_wall = utcnow()
        start_mono = time.monotonic()
        status = ""
        exception = ""
        response_body = b""
        response_headers = None
        evidence_class = ""
        tracker = RedirectTracker()
        row = None
        try:
            jar, jar_path = self.session(session_name)
            opener = urllib.request.build_opener(TimedHTTPSHandler(context=self.ssl_context), urllib.request.HTTPCookieProcessor(jar), tracker)
            req_headers = {"User-Agent": UA, "Accept": "*/*"}
            req = urllib.request.Request(url, data=request_body, headers=req_headers, method=method)
            try:
                with opener.open(req, timeout=30) as response:
                    status = str(response.status)
                    evidence_class = "HTTP_RESPONSE"
                    response_headers = response.headers
                    response_body = response.read()
            except urllib.error.HTTPError as exc:
                status = str(exc.code)
                evidence_class = "HTTP_RESPONSE"
                response_headers = exc.headers
                response_body = exc.read()
            try:
                jar.save(ignore_discard=True, ignore_expires=True)
            except OSError:
                if jar_path.exists():
                    jar_path.unlink()
        except (AttributeError, TypeError, NameError, AssertionError) as exc:
            evidence_class = "LOCAL_CLIENT_PROGRAMMING_EXCEPTION"
            exception = f"{type(exc).__name__}: {exc}"
        except (socket.timeout, TimeoutError, ConnectionError, urllib.error.URLError, http.client.HTTPException, ssl.SSLError) as exc:
            evidence_class = "TRANSIENT_NETWORK_EXCEPTION"
            exception = f"{type(exc).__name__}: {exc}"
        except Exception as exc:
            evidence_class = "LOCAL_CLIENT_PROGRAMMING_EXCEPTION"
            exception = f"{type(exc).__name__}: {exc}"
        finally:
            end_wall = utcnow()
            elapsed = time.monotonic() - start_mono
            selected = {}
            rate_headers = {}
            lines = []
            if response_headers is not None:
                for key, value in response_headers.items():
                    clean = "<REDACTED_ANONYMOUS_SESSION_COOKIE>" if key.casefold() == "set-cookie" else str(value).replace("\r", " ").replace("\n", " ")
                    lines.append(f"{key}: {clean}")
                    kl = key.casefold()
                    if kl in {"content-type", "etag", "last-modified", "cache-control", "retry-after"}:
                        selected[kl] = clean
                    if "ratelimit" in kl or "rate-limit" in kl or kl.startswith("x-rate"):
                        rate_headers[key] = clean
            header_data = (("\n".join(lines) + "\n") if lines else "").encode()
            if exception and not status:
                body_path = Path(str(body_path) + ".body")
            atomic_write(body_path, response_body)
            atomic_write(headers_path, header_data)
            row = {
                "request_id": rid, "utc_start": start_wall, "utc_end": end_wall, "method": method, "url": url,
                "request_body_sha256": sha_bytes(request_body) if request_body is not None else "",
                "request_body_bytes": str(len(request_body)) if request_body is not None else "", "user_agent": UA,
                "attempt": str(attempt), "evidence_class": evidence_class, "http_status": status, "network_exception": exception,
                "elapsed_seconds": f"{elapsed:.6f}", "content_type": selected.get("content-type", ""),
                "etag": selected.get("etag", ""), "last_modified": selected.get("last-modified", ""),
                "cache_control": selected.get("cache-control", ""), "retry_after": selected.get("retry-after", ""),
                "rate_limit_headers": json.dumps(rate_headers, sort_keys=True), "response_headers_path": rel(headers_path),
                "response_headers_bytes": str(len(header_data)), "response_headers_sha256": sha_bytes(header_data),
                "response_body_path": rel(body_path), "response_body_bytes": str(len(response_body)),
                "response_body_sha256": sha_bytes(response_body), "redirect_chain": json.dumps(tracker.chain, sort_keys=True),
            }
            self.rows.append(row)
            self.flush()
            self.last_host[parsed.netloc] = time.monotonic()
        return {"row": row, "status": int(status) if status else None, "exception": exception, "evidence_class": evidence_class, "body": response_body, "body_path": body_path, "headers_path": headers_path}

    def request(self, method: str, url: str, body_path: Path, headers_path: Path, session_name: str, minimum: float = 0.5, request_body: bytes | None = None):
        for attempt in (1, 2):
            result = self.one(method, url, body_path, headers_path, session_name, attempt, minimum, request_body)
            if result["evidence_class"] == "LOCAL_CLIENT_PROGRAMMING_EXCEPTION":
                raise ClientImplementationFailure(result["exception"])
            retry = bool(result["evidence_class"] == "TRANSIENT_NETWORK_EXCEPTION" or (result["evidence_class"] == "HTTP_RESPONSE" and (result["status"] == 429 or (result["status"] is not None and result["status"] >= 500))))
            if not retry or attempt == 2:
                return result
            value = result["row"].get("retry_after", "")
            try:
                delay = min(30.0, max(0.0, float(value))) if value else 0.0
            except ValueError:
                delay = 0.0
            if delay:
                time.sleep(delay)
        raise ClientImplementationFailure("unreachable recorder state")


def initialize(d5_map: dict[str, str], a1_map: dict[str, str], d5_tar: dict, a1_tar: dict) -> None:
    allowed_existing = {"scripts/mt_d5a2_completion.py", "scripts/validate_mt_d5a2.py"}
    current = {str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file()}
    if current != allowed_existing or RETURN_TAR.exists() or TAR_IDENTITY.exists() or WORK.exists():
        raise RuntimeError(f"MT_D5A2_BLOCKED_OUTPUT_PATH_EXISTS current={sorted(current)} tar={RETURN_TAR.exists()} identity={TAR_IDENTITY.exists()} work={WORK.exists()}")
    WORK.mkdir(mode=0o700)
    for name in ["inputs", "outputs", "requirements", "raw/metatraits/samples", "evidence/inherited_d5", "evidence/inherited_d5a1", "logs"]:
        (ROOT / name).mkdir(parents=True, exist_ok=True)
    copied_rows = []
    for label, source_root, names, manifest_map, manifest_sha in [
        ("D5", OLD_D5, INHERITED_D5_FILES, d5_map, D5_MANIFEST_SHA),
        ("D5A1", OLD_D5A1, INHERITED_D5A1_FILES, a1_map, D5A1_MANIFEST_SHA),
    ]:
        for name in names:
            source = source_root / name
            target = ROOT / ("evidence/inherited_d5" if label == "D5" else "evidence/inherited_d5a1") / name
            data = source.read_bytes()
            atomic_write(target, data)
            source_sha = digest(source)[1]
            copied_sha = digest(target)[1]
            expected_source_sha = manifest_sha if name == "MANIFEST.sha256" else manifest_map.get(name)
            if expected_source_sha != source_sha or source_sha != copied_sha:
                raise RuntimeError(f"INHERITED_COPY_IDENTITY_FAILED {label} {name}")
            copied_rows.append({"source_package": label, "source_path": name, "copied_path": rel(target), "bytes": len(data), "source_sha256": source_sha, "copied_sha256": copied_sha, "equality": "true"})
    write_csv(ROOT / "inputs/inherited_file_identity.csv", ["source_package", "source_path", "copied_path", "bytes", "source_sha256", "copied_sha256", "equality"], copied_rows)
    d5_manifest_bytes = (OLD_D5 / "MANIFEST.sha256").read_bytes()
    strict_dump({
        "old_root_label": OLD_D5.name, "old_final_token": (OLD_D5 / "FINAL_STATUS.txt").read_text().strip(),
        "manifest_bytes": len(d5_manifest_bytes), "manifest_sha256": sha_bytes(d5_manifest_bytes), "regular_file_count": 401,
        "manifest_listed_member_count": 400, "manifest_check_result": "PASS_ALL_LISTED_MEMBERS",
        "old_transport": d5_tar,
    }, ROOT / "inputs/inherited_d5_identity.json")
    a1_manifest_bytes = (OLD_D5A1 / "MANIFEST.sha256").read_bytes()
    strict_dump({
        "old_root_label": OLD_D5A1.name, "old_final_token": (OLD_D5A1 / "FINAL_STATUS.txt").read_text().strip(),
        "manifest_bytes": len(a1_manifest_bytes), "manifest_sha256": sha_bytes(a1_manifest_bytes), "regular_file_count": 101,
        "manifest_listed_member_count": 100, "manifest_check_result": "PASS_ALL_LISTED_MEMBERS",
        "completion_script_sha256": digest(OLD_D5A1 / "scripts/mt_d5a1_completion.py")[1],
        "validator_script_sha256": digest(OLD_D5A1 / "scripts/validate_mt_d5a1.py")[1], "old_transport": a1_tar,
    }, ROOT / "inputs/inherited_d5a1_identity.json")
    write_csv(ROOT / "inputs/five_sample_completion_plan.csv", ["order", "UID", "query", "rank", "old_summary_sha256"], [
        {"order": o, "UID": u, "query": q, "rank": r, "old_summary_sha256": h} for o, u, q, r, h in FIVE
    ])
    strict_dump([], ROOT / "outputs/execution_repair_log.json")
    atomic_write(ROOT / "evidence/environment.txt", (f"utc_start={utcnow()}\npython={sys.version.replace(chr(10), ' ')}\npython_executable={sys.executable}\nplatform={platform.platform()}\nPYTHONDONTWRITEBYTECODE=1\ngpu_requested=false\ndependencies=python_standard_library_only\n").encode())


def handler_preflight() -> dict:
    context = ssl.create_default_context()
    handler = TimedHTTPSHandler(context)
    module_source = Path(__file__).read_text(encoding="utf-8")
    tree = ast.parse(module_source)
    handler_node = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "TimedHTTPSHandler")
    connection_node = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "TimedHTTPSConnection")
    connection_source = ast.get_source_segment(module_source, connection_node) or ""
    forbidden_access = any(isinstance(node, ast.Attribute) and node.attr == "_check_hostname" for node in ast.walk(handler_node))
    result = {
        "ssl_context_factory": "ssl.create_default_context",
        "context_check_hostname": context.check_hostname,
        "context_verify_mode": int(context.verify_mode),
        "context_verify_mode_expected": int(ssl.CERT_REQUIRED),
        "handler_instantiated": isinstance(handler, TimedHTTPSHandler),
        "handler_has_usable_context": getattr(handler, "_context", None) is context,
        "handler_ast_accesses_forbidden_private_hostname_attribute": forbidden_access,
        "connect_timeout_intent_seconds": 10,
        "read_timeout_intent_seconds": 30,
        "timed_connection_source_contains_timeout_intent": "self.timeout = 10" in connection_source and "settimeout(30)" in connection_source,
    }
    result["result"] = "PASS" if all([
        result["context_check_hostname"], result["context_verify_mode"] == result["context_verify_mode_expected"],
        result["handler_instantiated"], result["handler_has_usable_context"], not forbidden_access,
        result["timed_connection_source_contains_timeout_intent"],
    ]) else "FAIL"
    strict_dump(result, ROOT / "outputs/https_handler_preflight.json")
    if result["result"] != "PASS":
        raise ClientImplementationFailure("HTTPS_HANDLER_PREFLIGHT_FAILED")
    return result


def preflight() -> bool:
    lines = [f"utc_start={utcnow()}", "host=metatraits.embl.de", "tls_verification=enabled", "connect_timeout_seconds=10", "read_total_timeout_seconds=30"]
    try:
        addrs = sorted({x[4][0] for x in socket.getaddrinfo("metatraits.embl.de", 443, type=socket.SOCK_STREAM)})
        lines.append("dns_addresses=" + ";".join(addrs))
        context = ssl.create_default_context()
        with socket.create_connection(("metatraits.embl.de", 443), timeout=10) as sock:
            with context.wrap_socket(sock, server_hostname="metatraits.embl.de") as tls:
                lines.extend(["tls_result=PASS", "tls_version=" + str(tls.version()), "tls_cipher=" + str(tls.cipher()[0])])
    except (socket.timeout, TimeoutError, ConnectionError, OSError, ssl.SSLError) as exc:
        lines.extend(["tls_result=FAIL", f"exception={type(exc).__name__}: {exc}"])
    lines.append(f"utc_end={utcnow()}")
    atomic_write(ROOT / "evidence/network_dns_tls_preflight.txt", ("\n".join(lines) + "\n").encode())
    return "tls_result=PASS" in lines


def verified_inherited_science() -> tuple[list[dict], list[dict], dict[str, dict]]:
    mapping = read_rows(OLD_D5 / "outputs/enzyme_organism_mapping.csv")
    if [r["UID"] for r in mapping] != UIDS:
        raise RuntimeError("OLD_UID_ORDER_INVALID")
    for row in mapping:
        obj = strict_load(OLD_D5 / f"raw/uniprot/{row['UID']}/response.json")
        if obj.get("primaryAccession") != row["UID"]:
            raise RuntimeError(f"UNIPROT_ROUNDTRIP_FAILED {row['UID']}")
    api = read_rows(OLD_D5 / "outputs/documented_api_probe.csv")
    if len(api) != 16 or any(r["http_status"] != "404" for r in api):
        raise RuntimeError("OLD_DOCUMENTED_API_PROBE_INVALID")
    old_cov = {r["UID"]: r for r in read_rows(OLD_D5 / "outputs/sample_interface_coverage.csv")}
    for order, uid, _, _, expected_sha in FIVE:
        if digest(OLD_D5 / f"raw/metatraits/samples/{order:02d}_{uid}/summary.json")[1] != expected_sha:
            raise RuntimeError(f"OLD_SUMMARY_HASH_MISMATCH {uid}")
    mapping_summary = strict_load(OLD_D5 / "outputs/mapping_source_summary.json")
    if mapping_summary.get("UniProt", {}).get("exact") != 10 or mapping_summary.get("KEGG", {}) != {"exact": 7, "missing": 1, "multiple": 2}:
        raise RuntimeError("INHERITED_MAPPING_COUNTS_INVALID")
    a1_ledger = read_rows(OLD_D5A1 / "outputs/query_manifest.csv")
    if len(a1_ledger) != 24 or any(r.get("http_status") or "AttributeError: 'TimedHTTPSHandler' object has no attribute '_check_hostname'" not in r.get("network_exception", "") for r in a1_ledger):
        raise RuntimeError("D5A1_LEDGER_FACT_INVALID")
    a1_ids = {r["UID"]: r for r in read_rows(OLD_D5A1 / "outputs/identifier_resolution.csv")}
    for order, uid, _ in QUERY_PLAN:
        observed = set()
        obs_path = OLD_D5 / f"raw/metatraits/samples/{order:02d}_{uid}/observations.jsonl"
        if obs_path.is_file():
            with obs_path.open(encoding="utf-8") as fh:
                for line in fh:
                    row = json.loads(line)
                    value = row.get("tax_id", row.get("taxon_id", row.get("taxid", row.get("ncbi_taxon_id"))))
                    if value is not None and str(value):
                        observed.add(str(value))
        recorded = {x for x in a1_ids[uid].get("distinct_observation_taxon_IDs", "").split(";") if x}
        if observed != recorded:
            raise RuntimeError(f"D5A1_TAX_ID_NOT_REPRODUCIBLE {uid}")
    return mapping, api, old_cov


def parse_summary(result) -> tuple[object | None, bool]:
    try:
        obj = strict_bytes(result["body"])
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
        return None, False
    valid = isinstance(obj, list) and all(isinstance(x, dict) for x in obj)
    return obj, valid


def collect(rec: Recorder, old_cov: dict[str, dict]):
    samples = []
    provenance = []
    observation_results = {}
    for order, uid, query, rank, old_sha in FIVE:
        sdir = ROOT / f"raw/metatraits/samples/{order:02d}_{uid}"
        sdir.mkdir(parents=True, exist_ok=True)
        session = f"ordinary_{order:02d}_{uid}"
        try:
            page_url = "https://metatraits.embl.de/taxon?" + urllib.parse.urlencode({"query": query, "rank": rank})
            page = rec.request("GET", page_url, sdir / "taxon_page.html", sdir / "taxon_page.headers.txt", session)
            if order == 1 and (page["evidence_class"] != "HTTP_RESPONSE" or not page["body"] or int(page["row"]["response_headers_bytes"]) == 0):
                raise CanaryNetworkFailure("CANARY_NO_REAL_HTTP_RESPONSE_WITH_NONEMPTY_IDENTITIES")
            summary_url = "https://metatraits.embl.de/taxon/download?" + urllib.parse.urlencode({"query": query, "rank": rank})
            result = rec.request("GET", summary_url, sdir / "summary.json", sdir / "summary.headers.txt", session)
            obj, valid = parse_summary(result)
            content_json = "json" in result["row"]["content_type"].casefold()
            success = result["status"] == 200 and valid and content_json
            old_path = OLD_D5 / f"raw/metatraits/samples/{order:02d}_{uid}/summary.json"
            actual_old_sha = digest(old_path)[1]
            if actual_old_sha != old_sha:
                raise RuntimeError(f"OLD_SUMMARY_HASH_MISMATCH {uid}")
            semantic_equal = bool(valid and strict_load(old_path) == obj)
            provenance.append({
                "order": order, "UID": uid, "query": query, "rank": rank, "request_id": result["row"]["request_id"],
                "http_status": result["row"]["http_status"] or "NETWORK_EXCEPTION", "utc_start": result["row"]["utc_start"],
                "utc_end": result["row"]["utc_end"], "elapsed_seconds": result["row"]["elapsed_seconds"],
                "content_type": result["row"]["content_type"], "strict_json": str(valid).lower(),
                "top_level_list_of_objects": str(valid).lower(), "body_bytes": result["row"]["response_body_bytes"],
                "body_sha256": result["row"]["response_body_sha256"], "summary_record_count": len(obj) if valid else 0,
                "old_body_sha256": old_sha, "raw_sha256_equal_to_inherited": str(result["row"]["response_body_sha256"] == old_sha).lower(),
                "semantic_json_equal_to_inherited": str(semantic_equal).lower(), "raw_body_path": result["row"]["response_body_path"],
                "raw_headers_path": result["row"]["response_headers_path"],
            })
            sample = {"order": order, "uid": uid, "query": query, "rank": rank, "page": page, "result": result, "records": obj if valid else [], "success": success, "dir": sdir}
            samples.append(sample)
            if order == 1:
                for tab in ["Environmental_preferences", "Metabolites"]:
                    obs_url = "https://metatraits.embl.de/observations?" + urllib.parse.urlencode({"query": query, "rank": rank, "tab": tab, "draw": 1, "start": 0, "length": 500})
                    obs = rec.request("GET", obs_url, sdir / f"observations_{tab}.json", sdir / f"observations_{tab}.headers.txt", session)
                    try:
                        oo = strict_bytes(obs["body"])
                    except Exception:
                        oo = None
                    valid_obs = obs["status"] == 200 and "json" in obs["row"]["content_type"].casefold() and isinstance(oo, dict) and isinstance(oo.get("data"), list)
                    state = "HTTP_200_STRICT_JSON" if valid_obs else "NON_200_OR_INVALID_JSON"
                    if valid_obs and oo.get("data") == [] and oo.get("recordsFiltered") is None:
                        state = "SERVER_NULL_TOTAL_EMPTY_DATA"
                    observation_results[tab] = {"result": obs, "object": oo, "valid": valid_obs, "state": state}
        finally:
            rec.close_session(session)
    write_csv(ROOT / "outputs/summary_http_provenance.csv", ["order", "UID", "query", "rank", "request_id", "http_status", "utc_start", "utc_end", "elapsed_seconds", "content_type", "strict_json", "top_level_list_of_objects", "body_bytes", "body_sha256", "summary_record_count", "old_body_sha256", "raw_sha256_equal_to_inherited", "semantic_json_equal_to_inherited", "raw_body_path", "raw_headers_path"], provenance)

    cov_rows = []
    new_by_uid = {s["uid"]: s for s in samples}
    for order, uid, query in QUERY_PLAN:
        inherited = old_cov[uid]
        if uid in new_by_uid:
            s = new_by_uid[uid]
            obs_state = ""
            obs_rows = 0
            if uid == "Q8EFP8":
                state_parts = []
                for tab in ["Environmental_preferences", "Metabolites"]:
                    item = observation_results.get(tab, {})
                    obj = item.get("object") or {}
                    rows = len(obj.get("data", [])) if isinstance(obj, dict) else 0
                    obs_rows += rows
                    state_parts.append(f"{tab}:{item.get('state', 'MISSING')}:{rows}:{obj.get('recordsFiltered') if isinstance(obj, dict) else ''}")
                obs_state = ";".join(state_parts)
            else:
                obs_state = "BOUNDED_SOURCE_PROVENANCE_NOT_REQUESTED_FOR_THIS_SAMPLE"
            cov_rows.append({
                "order": order, "UID": uid, "fixed_query": query, "collection_class": "D5A2_NEW",
                "inherited_autocomplete_state": "unique_exact" if inherited.get("unique_exact_match") == "true" else "ambiguous",
                "candidate_count": inherited.get("candidate_count", ""), "taxon_page_HTTP_status": s["page"]["row"]["http_status"] or "NETWORK_EXCEPTION",
                "summary_HTTP_status": s["result"]["row"]["http_status"] or "NETWORK_EXCEPTION", "summary_strict_JSON": str(s["success"]).lower(),
                "summary_record_count": len(s["records"]), "observation_row_total": obs_rows, "observation_collection_state": obs_state,
                "raw_sample_path": rel(s["dir"]),
            })
        else:
            ambiguous = uid in {"P29931", "S5SC42"}
            cov_rows.append({
                "order": order, "UID": uid, "fixed_query": query, "collection_class": "INHERITED_AUTOCOMPLETE_ONLY" if ambiguous else "INHERITED_BOUNDED_NOT_REQUERIED",
                "inherited_autocomplete_state": "ambiguous" if ambiguous else "unique_exact_bounded_not_requeried",
                "candidate_count": inherited.get("candidate_count", ""), "taxon_page_HTTP_status": "NOT_REQUESTED_D5A2",
                "summary_HTTP_status": "NOT_REQUESTED_D5A2", "summary_strict_JSON": "false", "summary_record_count": 0,
                "observation_row_total": 0, "observation_collection_state": "NOT_REQUESTED_D5A2",
                "raw_sample_path": "",
            })
    write_csv(ROOT / "outputs/sample_interface_coverage.csv", ["order", "UID", "fixed_query", "collection_class", "inherited_autocomplete_state", "candidate_count", "taxon_page_HTTP_status", "summary_HTTP_status", "summary_strict_JSON", "summary_record_count", "observation_row_total", "observation_collection_state", "raw_sample_path"], cov_rows)
    return samples, observation_results


def stability(rec: Recorder, samples: list[dict]):
    chosen = next((s for s in samples if s["uid"] == "Q8EFP8" and s["success"]), None) or next((s for s in samples if s["success"]), None)
    rows = []
    if chosen:
        session = "stability_repeat"
        first = None
        try:
            url = "https://metatraits.embl.de/taxon/download?" + urllib.parse.urlencode({"query": chosen["query"], "rank": chosen["rank"]})
            for i in range(1, 4):
                result = rec.request("GET", url, chosen["dir"] / f"stability_repeat_{i}.json", chosen["dir"] / f"stability_repeat_{i}.headers.txt", session, minimum=2.0)
                try:
                    obj = strict_bytes(result["body"])
                    valid = isinstance(obj, list) and all(isinstance(x, dict) for x in obj)
                except Exception:
                    obj, valid = None, False
                if i == 1:
                    first = obj
                r = result["row"]
                rows.append({
                    "repeat": i, "UID": chosen["uid"], "query": chosen["query"], "rank": chosen["rank"], "status": r["http_status"] or "NETWORK_EXCEPTION",
                    "utc_start": r["utc_start"], "utc_end": r["utc_end"], "elapsed_seconds": r["elapsed_seconds"], "body_bytes": r["response_body_bytes"],
                    "body_sha256": r["response_body_sha256"], "content_type": r["content_type"], "etag": r["etag"], "last_modified": r["last_modified"],
                    "cache_control": r["cache_control"], "retry_after": r["retry_after"], "rate_limit_headers": r["rate_limit_headers"],
                    "strict_json": str(valid).lower(), "semantic_equal_to_repeat_1": str(valid and obj == first).lower(),
                    "raw_body_path": r["response_body_path"], "raw_headers_path": r["response_headers_path"],
                })
        finally:
            rec.close_session(session)
    write_csv(ROOT / "outputs/stability_repeat.csv", ["repeat", "UID", "query", "rank", "status", "utc_start", "utc_end", "elapsed_seconds", "body_bytes", "body_sha256", "content_type", "etag", "last_modified", "cache_control", "retry_after", "rate_limit_headers", "strict_json", "semantic_equal_to_repeat_1", "raw_body_path", "raw_headers_path"], rows)
    return rows


def observation_rows(observation_results: dict) -> list[dict]:
    rows = []
    for tab in ["Environmental_preferences", "Metabolites"]:
        item = observation_results.get(tab, {})
        obj = item.get("object")
        if isinstance(obj, dict):
            for idx, source in enumerate(obj.get("data", [])):
                if isinstance(source, dict):
                    row = dict(source)
                    row["_provenance"] = {"raw_page_path": item["result"]["row"]["response_body_path"], "raw_page_index": idx, "tab": tab}
                    rows.append(row)
    return rows


def analyze(samples: list[dict], observation_results: dict, mapping: list[dict]):
    obs = observation_rows(observation_results)
    summary_fields = sorted({k for s in samples for r in s["records"] for k in r})
    obs_fields = sorted({k for r in obs for k in r if k != "_provenance"})
    nrm_rows = []
    coverage_rows = []
    match_rows = []
    aggregate_total = aggregate_nrm = 0
    conflicts = []
    for sample in samples:
        records = sample["records"] if sample["success"] else []
        nrm = sum(r.get("majority_label") == "No robust majority" for r in records)
        total = len(records)
        aggregate_total += total
        aggregate_nrm += nrm
        sample_obs = obs if sample["uid"] == "Q8EFP8" else []
        nrm_rows.append({
            "order": sample["order"], "UID": sample["uid"], "query": sample["query"], "total_summary_records": total,
            "no_robust_majority_count": nrm if total else "UNAVAILABLE_NO_VALID_SUMMARY", "no_robust_majority_percentage": f"{(100*nrm/total):.6f}" if total else "UNAVAILABLE_NO_VALID_SUMMARY",
            "explicit_denominator": total, "is_ai_true": sum(r.get("is_ai") is True for r in records),
            "is_ai_false": sum(r.get("is_ai") is False for r in records), "is_ai_missing": sum(r.get("is_ai") is None for r in records),
            "observation_row_total": len(sample_obs), "raw_summary_path": rel(sample["result"]["body_path"]),
        })
        for record in records:
            if record.get("majority_label") == "No robust majority" and len(conflicts) < 3:
                name = str(record.get("name", ""))
                matching = [x for x in sample_obs if str(x.get("trait", "")).casefold() == name.casefold()]
                if matching:
                    conflicts.append({"UID": sample["uid"], "trait_name": name, "summary_record": record, "matching_observations": matching, "summary_source_path": rel(sample["result"]["body_path"]), "observation_source_paths": sorted({x["_provenance"]["raw_page_path"] for x in matching})})
        for category, patterns in WW_GROUPS.items():
            matched = [r for r in records if str(r.get("name", "")) and any(re.search(p, str(r.get("name", "")), re.I) for p in patterns)]
            names = sorted({str(r.get("name")) for r in matched})
            coverage_rows.append({
                "order": sample["order"], "UID": sample["uid"], "query": sample["query"], "category": category,
                "trait_record_present": str(bool(matched)).lower(), "matched_record_count": len(matched), "exact_matched_trait_names": ";".join(names),
                "summary_denominator": total, "interpretation": "presence_of_trait_record_not_suitability" if matched else "unknown_not_unsuitable",
                "raw_summary_path": rel(sample["result"]["body_path"]),
            })
            match_rows.append({"order": sample["order"], "UID": sample["uid"], "query": sample["query"], "category": category, "exact_matched_trait_names": names, "matched_records": matched})
    nrm_rows.append({"order": "", "UID": "AGGREGATE", "query": "five_current_D5A2_summaries", "total_summary_records": aggregate_total if aggregate_total else "UNAVAILABLE_NO_VALID_SUMMARY", "no_robust_majority_count": aggregate_nrm if aggregate_total else "UNAVAILABLE_NO_VALID_SUMMARY", "no_robust_majority_percentage": f"{(100*aggregate_nrm/aggregate_total):.6f}" if aggregate_total else "UNAVAILABLE_NO_VALID_SUMMARY", "explicit_denominator": aggregate_total if aggregate_total else "UNAVAILABLE_NO_VALID_SUMMARY", "is_ai_true": "", "is_ai_false": "", "is_ai_missing": "", "observation_row_total": len(obs), "raw_summary_path": "outputs/summary_http_provenance.csv"})
    write_csv(ROOT / "outputs/no_robust_majority_summary.csv", ["order", "UID", "query", "total_summary_records", "no_robust_majority_count", "no_robust_majority_percentage", "explicit_denominator", "is_ai_true", "is_ai_false", "is_ai_missing", "observation_row_total", "raw_summary_path"], nrm_rows)
    write_csv(ROOT / "outputs/wastewater_trait_coverage.csv", ["order", "UID", "query", "category", "trait_record_present", "matched_record_count", "exact_matched_trait_names", "summary_denominator", "interpretation", "raw_summary_path"], coverage_rows)
    strict_dump({"disclosed_matching_groups": WW_GROUPS, "sample_category_matches": match_rows, "boundary": "Coverage is presence of a saved current summary trait record, not proof of suitability; missing coverage is unknown, not unsuitable."}, ROOT / "outputs/wastewater_trait_matches.json")
    strict_dump({"available_count": len(conflicts), "examples": conflicts, "selection_rule": "Up to the first three current No robust majority summary records with exact trait-name-matching observations from the two bounded Shewanella page-zero bodies."}, ROOT / "outputs/source_conflict_examples.json")
    strict_dump({
        "actual_summary_fields": summary_fields, "actual_observation_fields": obs_fields,
        "required_observation_fields_present": {x: x in obs_fields for x in ["database_record", "record_url", "tax_id", "trait", "value"]},
        "invented_three_state_field": False,
        "concept_separation": {"summary_is_ai": "independent boolean", "summary_majority_label": "independent label", "observation_sources": "database_record and record_url preserved", "culture_and_prediction_classification": "inherited official source terminology retained without renaming culture_based experimental", "uniprot_reviewed_annotation": "separate inherited raw fields; neither is confidence"},
        "unsupported_inference_prohibited": "No experimental/predicted/no_robust_majority field was invented; missing coverage is unknown.",
    }, ROOT / "outputs/evidence_semantics_audit.json")
    return aggregate_nrm, aggregate_total, conflicts


def identifiers_and_mapping(mapping: list[dict], old_cov: dict[str, dict], observation_results: dict) -> None:
    idrows = []
    for order, uid, fixed in QUERY_PLAN:
        m = next(x for x in mapping if x["UID"] == uid)
        obs_path = OLD_D5 / f"raw/metatraits/samples/{order:02d}_{uid}/observations.jsonl"
        taxids = set()
        evidence = [f"INHERITED_D5_ROOT/raw/uniprot/{uid}/response.json"]
        if obs_path.is_file():
            evidence.append(f"INHERITED_D5_ROOT/raw/metatraits/samples/{order:02d}_{uid}/observations.jsonl")
            with obs_path.open(encoding="utf-8") as fh:
                for line in fh:
                    row = json.loads(line)
                    value = row.get("tax_id", row.get("taxon_id", row.get("taxid", row.get("ncbi_taxon_id"))))
                    if value is not None and str(value):
                        taxids.add(str(value))
        if uid == "Q8EFP8":
            for item in observation_results.values():
                obj = item.get("object")
                if item.get("valid") and isinstance(obj, dict):
                    evidence.append(item["result"]["row"]["response_body_path"])
                    for row in obj.get("data", []):
                        if isinstance(row, dict) and row.get("tax_id") is not None:
                            taxids.add(str(row["tax_id"]))
        selected = old_cov[uid].get("selected_name", "")
        uni_name = m["scientific_organism_name"]
        state = "ambiguous" if fixed.endswith("sp.") else ("exact" if uni_name == fixed else "species_query_collapses_strain_or_multiple_taxa")
        idrows.append({
            "UID": uid, "UniProt_organism_name": uni_name, "UniProt_taxon_ID": m["UniProt_NCBI_taxon_ID"],
            "fixed_query_name": fixed, "inherited_autocomplete_returned_name": selected, "summary_query_rank": "species" if uid in {x[1] for x in FIVE} else "",
            "distinct_observation_taxon_IDs": ";".join(sorted(taxids, key=lambda x: (len(x), x))), "resolution_state": state,
            "strain_preservation_claimed": "false", "raw_evidence_paths": ";".join(evidence),
        })
    write_csv(ROOT / "outputs/identifier_resolution.csv", ["UID", "UniProt_organism_name", "UniProt_taxon_ID", "fixed_query_name", "inherited_autocomplete_returned_name", "summary_query_rank", "distinct_observation_taxon_IDs", "resolution_state", "strain_preservation_claimed", "raw_evidence_paths"], idrows)

    comparisons = []
    for _, uid, fixed in QUERY_PLAN:
        raw = next(x for x in mapping if x["UID"] == uid)["scientific_organism_name"]
        normalize = lambda x: re.sub(r"[.]+$", "", " ".join(x.split())).casefold()
        comparisons.append({"UID": uid, "fixed_query_raw": fixed, "uniprot_organism_raw": raw, "fixed_query_normalized": normalize(fixed), "uniprot_organism_normalized": normalize(raw), "normalized_exact_match": normalize(fixed) == normalize(raw), "interpretation": "punctuation_normalization_match" if uid == "P29931" else ("exact" if normalize(fixed) == normalize(raw) else "species_query_vs_more_specific_or_different_raw_name")})
    strict_dump({
        "uniprot_accession_resolution": {"exact": 10, "missing": 0}, "fixed_query_organism_name_comparison": comparisons,
        "kegg_conversion": {"single": 7, "missing": 1, "multiple": 2}, "confidence_calculated": False,
        "dimensions_merged": "false; UniProt accession, organism-name comparison, and KEGG conversion remain separate dimensions",
        "boundary": "Counts describe only the ten fixed UIDs; no production-wide coverage claim.",
    }, ROOT / "outputs/mapping_reconciliation.json")


def rate_output(rec: Recorder) -> dict:
    statuses = Counter(r["http_status"] for r in rec.rows if r["evidence_class"] == "HTTP_RESPONSE")
    response_count = sum(r["evidence_class"] == "HTTP_RESPONSE" for r in rec.rows)
    obj = {
        "old_d5": {"fully_recorded_attempts": 65, "http_429_among_fully_recorded_attempts": 0, "total_old_http_429": "UNKNOWN", "reason": "Attempts 66--180 lack complete status metadata and were not reconstructed."},
        "d5a1": {"total_attempts": 24, "completed_http_responses": 0, "http_429_count": "NOT_OBSERVABLE_NO_HTTP_RESPONSE", "finding": "All attempts were local-client programming exceptions."},
        "d5a2": {"total_attempts": len(rec.rows), "evidence_class_counts": dict(sorted(Counter(r["evidence_class"] for r in rec.rows).items())), "completed_http_responses": response_count, "http_status_counts": dict(sorted(statuses.items())), "http_429_count": sum(r["http_status"] == "429" for r in rec.rows) if response_count else "NOT_OBSERVABLE_NO_HTTP_RESPONSE"},
        "rate_limit_threshold": "UNKNOWN", "minimum_spacing_seconds": {"ordinary_same_host": 0.5, "stability_repeats": 2.0},
        "conclusion_boundary": "A bounded serial probe cannot establish an unlimited API; no observed HTTP 429 does not prove no rate limit.",
    }
    strict_dump(obj, ROOT / "outputs/rate_limit_observation.json")
    return obj


def cleanup_and_scope(rec: Recorder) -> None:
    rec.close_all()
    listing = [str(p.relative_to(WORK)) + ("/" if p.is_dir() else "") for p in sorted(WORK.rglob("*"))]
    atomic_write(ROOT / "evidence/work_root_after_cleanup.txt", (f"WORK_ROOT={WORK}\nlisting_after_cookie_cleanup:\n" + "\n".join(listing) + ("\n" if listing else "<EMPTY>\n")).encode())
    cookie_remaining = any(p.is_file() and "cookie" in p.name.casefold() for p in WORK.rglob("*"))
    strict_dump({
        "gpu_requested_or_used": False, "checkpoint_inference_training_evaluation": False, "portraits_or_bulk_database_workflow": False,
        "production_implementation": False, "credentials_packaged": False, "cookie_files_remaining": cookie_remaining,
        "model_or_checkpoint_assets": False, "feature_extraction": False, "bulk_observation_pagination_continued": False,
        "mycobacterium_observation_request_count": 0, "d5a2_attempt_cap": 40, "anonymous_sessions_only": True,
        "work_root_listing_evidence": "evidence/work_root_after_cleanup.txt",
    }, ROOT / "outputs/scope_compliance.json")


def write_matrix_report(samples, observation_results, stability_rows, rate, nrm, total, conflicts, api_rows, transport_final: bool = False) -> None:
    successful = sum(s["success"] for s in samples)
    stable_ok = len(stability_rows) == 3 and all(r["status"] == "200" and r["strict_json"] == "true" for r in stability_rows)
    observations_ok = len(observation_results) == 2 and all(x.get("valid") for x in observation_results.values())
    pages_ok = len(samples) == 5 and all(s["page"]["status"] == 200 for s in samples)
    path_map = {
        "MTD5-R01": ["evidence/inherited_d5/inputs/v1_test_table_identity.csv"],
        "MTD5-R02": ["evidence/inherited_d5/inputs/selected_seed_rows.csv"],
        "MTD5-R03": ["evidence/inherited_d5/outputs/enzyme_organism_mapping.csv"],
        "MTD5-R04": ["outputs/mapping_reconciliation.json"],
        "MTD5-R05": ["evidence/inherited_d5/outputs/documentation_contract.json"],
        "MTD5-R06": ["evidence/inherited_d5/outputs/documented_api_probe.csv"],
        "MTD5-R07": ["outputs/summary_http_provenance.csv", "raw/metatraits/samples/01_Q8EFP8/observations_Environmental_preferences.json", "raw/metatraits/samples/01_Q8EFP8/observations_Metabolites.json"],
        "MTD5-R08": ["outputs/summary_http_provenance.csv"], "MTD5-R09": ["outputs/stability_repeat.csv", "outputs/rate_limit_observation.json"],
        "MTD5-R10": ["outputs/identifier_resolution.csv"], "MTD5-R11": ["outputs/wastewater_trait_coverage.csv", "outputs/wastewater_trait_matches.json"],
        "MTD5-R12": ["outputs/no_robust_majority_summary.csv", "outputs/source_conflict_examples.json"], "MTD5-R13": ["outputs/evidence_semantics_audit.json"],
        "MTD5-R14": ["evidence/inherited_d5/outputs/documentation_contract.json", "outputs/rate_limit_observation.json"], "MTD5-R15": ["outputs/scope_compliance.json"],
        "MTD5-R16": ["MANIFEST.sha256", "logs/validator.stdout.txt", "logs/negative_tests.csv", "EXTERNAL_RETURN_TAR", "EXTERNAL_TAR_IDENTITY"],
    }
    findings = {
        "MTD5-R01": "Accepted V1 identity reused byte-for-byte from verified old package.", "MTD5-R02": "Deterministic P0 selection reused byte-for-byte.",
        "MTD5-R03": "Ten fixed UIDs and inherited raw UniProt mapping verified.", "MTD5-R04": "UniProt 10 exact; KEGG single/missing/multiple 7/1/2; dimensions remain separate.",
        "MTD5-R05": "Official surface inventory is inherited verified evidence; no repeat request.", "MTD5-R06": f"Exactly {len(api_rows)} inherited logical probes all saved HTTP 404; evidence complete, route unavailable finding.",
        "MTD5-R07": f"Current pages complete={pages_ok}; bounded observation pages valid={sum(bool(x.get('valid')) for x in observation_results.values())}/2.", "MTD5-R08": f"{successful}/5 current summaries satisfy HTTP-200 strict-JSON requirements.",
        "MTD5-R09": f"{len(stability_rows)}/3 bounded stability repeats recorded; rate threshold remains UNKNOWN.", "MTD5-R10": "Actual tax_id parsed reproducibly from inherited JSONL and merged with current bounded observations; species collapse disclosed.",
        "MTD5-R11": "Wastewater groups recomputed from five current bodies; missing means unknown.", "MTD5-R12": f"Current No robust majority {nrm}/{total}; {len(conflicts)} bounded matching conflict examples.",
        "MTD5-R13": "Summary, source, is_ai, majority_label and UniProt semantics remain separate.", "MTD5-R14": "Inherited documentation contract retained; rate/pagination boundaries explicit.",
        "MTD5-R15": "Research-only bounded scope; no GPU/model/bulk workflow/credentials/implementation.", "MTD5-R16": "Portable validator, negative tests, manifest and deterministic external transport are finalization gates.",
    }
    independent_pass = {
        "MTD5-R01": True, "MTD5-R02": True, "MTD5-R03": True, "MTD5-R04": True,
        "MTD5-R05": True, "MTD5-R06": True, "MTD5-R07": pages_ok and successful == 5 and observations_ok,
        "MTD5-R08": successful == 5, "MTD5-R09": stable_ok, "MTD5-R10": True,
        "MTD5-R11": successful == 5, "MTD5-R12": successful == 5 and observations_ok,
        "MTD5-R13": successful == 5 and observations_ok, "MTD5-R14": True, "MTD5-R15": True,
        "MTD5-R16": transport_final,
    }
    matrix = []
    for rid, meaning in MEANINGS:
        current = rid in {"MTD5-R07", "MTD5-R08", "MTD5-R09", "MTD5-R10", "MTD5-R11", "MTD5-R12", "MTD5-R13", "MTD5-R15", "MTD5-R16"}
        passed = independent_pass[rid]
        status = "PASS_EVIDENCE_COMPLETE" if passed else ("NOT_COLLECTED_BLOCKED" if rid == "MTD5-R16" and not transport_final else "MISSING_REQUIRED_EVIDENCE")
        matrix.append({"requirement_id": rid, "meaning": meaning, "evidence_class": "D5A2_NEW" if current else "INHERITED_VERIFIED", "evidence_paths": path_map[rid], "evidence_status": status, "scientific_finding": findings[rid], "blocker": "" if passed else ("Transport finalization pending baseline and negative-test gates." if rid == "MTD5-R16" and not transport_final else "Specific required current evidence is incomplete."), "verified_now": passed})
    strict_dump(matrix, ROOT / "requirements/requirement_to_evidence_matrix.json")
    pct_text = f"{100*nrm/total:.6f}%" if total else "UNAVAILABLE_NO_VALID_SUMMARY"
    summary_lines = [f"- `{s['uid']}`: HTTP {s['result']['row']['http_status'] or 'NETWORK_EXCEPTION'}; `{rel(s['result']['body_path'])}`" for s in samples]
    repeat_lines = [f"- repeat {r['repeat']}: HTTP {r['status']}, SHA256 `{r['body_sha256']}`, semantic equality to repeat 1 `{r['semantic_equal_to_repeat_1']}`" for r in stability_rows]
    obs_lines = [f"- `{tab}`: {item.get('result', {}).get('row', {}).get('http_status') or 'NO_HTTP_RESPONSE'}; strict valid `{str(bool(item.get('valid'))).lower()}`" for tab, item in observation_results.items()]
    report = f"""# MT-D5A2 Correction Report

## Scope

This is the teacher-assigned bounded MetaTraits pre-research correction. It is not training, checkpoint inference, production implementation, bulk database work, scoring, filtering or an Agent component. MT-D1--MT-D4 and MT-D6--MT-D8 remain unresolved.

## Inherited verified evidence

The verified D5 and D5A1 packages have manifest SHA256 `{D5_MANIFEST_SHA}` and `{D5A1_MANIFEST_SHA}`. The accepted V1/P0, ten raw UniProt mappings, KEGG mappings, official contracts, API probes, D5A1 crash-safe ledger and corrected `tax_id` evidence were copied by hash. Old D5 attempts 66--180 lost required metadata and were not reconstructed. D5A1 recorded 24 local-client programming exceptions and zero HTTP responses; these are not classified as an endpoint outage. No UniProt, KEGG, official-page or `/api/v1` request was repeated.

UniProt primary accessions round-trip exactly for 10/10 fixed UIDs, independently of name comparison and KEGG conversion. KEGG conversion is single 7, missing 1 and multiple 2. `Sinorhizobium sp` versus `Sinorhizobium sp.` is a terminal-punctuation normalization match, not a biological conflict. All 16 inherited documented API logical probes have complete saved HTTP 404 evidence; this is a route-not-live finding, not missing evidence.

## Current D5A2 summary evidence

{chr(10).join(summary_lines)}

The five-sample bounded probe cannot establish production-wide coverage across all ten planned samples or all MetaTraits taxa. Raw changes relative to inherited bodies are freshness/stability findings, not automatic corruption.

## Current derived trait results

Current `majority_label` exactly equal to `No robust majority`: {f'{nrm}/{total}' if total else 'UNAVAILABLE_NO_VALID_SUMMARY'}; percentage {pct_text}. Per-sample denominators are recorded conditionally. Wastewater groups were recomputed only from valid current bodies. Trait-record presence is not suitability, and missing coverage means unknown, not unsuitable.

## Source provenance and identifiers

{chr(10).join(obs_lines) if obs_lines else '- No bounded observation HTTP response was available.'}

Actual observation fields are claimed only when the two valid bodies support them. Up to three matching current conflict examples were rebuilt; {len(conflicts)} were available. Inherited and current `tax_id` values show species-query collapse, so strain preservation is not claimed. No Mycobacterium observation page was requested; old partial bulk data remains historical and outside D5A2 collection.

## Stability and bounded rate observation

{chr(10).join(repeat_lines) if repeat_lines else '- Required repeats unavailable.'}

D5A2 made {rate['d5a2']['total_attempts']} serial attempts. Evidence-class counts are {json.dumps(rate['d5a2']['evidence_class_counts'], sort_keys=True)} and HTTP status counts are {json.dumps(rate['d5a2']['http_status_counts'], sort_keys=True)}. D5A2 HTTP 429 evidence is `{rate['d5a2']['http_429_count']}`. D5 proves zero 429 only among 65 complete attempts with total UNKNOWN; D5A1 has `NOT_OBSERVABLE_NO_HTTP_RESPONSE`. No observed 429 establishes neither an unlimited API nor a threshold; threshold remains UNKNOWN.

## Corrected pagination boundary

Exhaustive Mycobacterium pagination exceeded the corrected bounded teacher scope. D5A2 collected only the two specified Shewanella page-zero bodies and did not continue bulk pagination.

## Unresolved proposals

Production readiness, biological host suitability, production-wide interface coverage, and MT-D1--MT-D4/MT-D6--MT-D8 decisions remain unresolved. No teacher-facing conclusion is made here.
"""
    atomic_write(ROOT / "MT_D5A2_CORRECTION_REPORT.md", report.encode())


def negative_tests(baseline_exit: int) -> tuple[int, str, str]:
    if baseline_exit != 0:
        raise ClientImplementationFailure("NEGATIVE_TESTS_FORBIDDEN_BASELINE_INVALID")
    validator = ROOT / "scripts/validate_mt_d5a2.py"
    cases = [
        ("summary_status_200_to_404", "SUMMARY_STATUS_NOT_200"), ("blank_request_elapsed", "REQUEST_ELAPSED_MISSING"),
        ("remove_tax_id_values", "IDENTIFIER_TAX_ID_MISSING"), ("swap_R09_R13_meanings", "REQUIREMENT_MEANING_MISMATCH"),
        ("rate_UNKNOWN_to_UNLIMITED", "RATE_THRESHOLD_UNSUPPORTED"),
    ]
    matrix = []
    out_parts, err_parts = [], []
    base = WORK / "negative_tests"
    base.mkdir()
    for index, (name, diagnostic) in enumerate(cases, 1):
        copy = base / f"case_{index}"
        shutil.copytree(ROOT, copy)
        if index == 1:
            p = copy / "outputs/summary_http_provenance.csv"; rows = read_rows(p); rows[0]["http_status"] = "404"; write_csv(p, list(rows[0]), rows)
        elif index == 2:
            p = copy / "outputs/query_manifest.csv"; rows = read_rows(p); rows[0]["elapsed_seconds"] = ""; write_csv(p, list(rows[0]), rows)
        elif index == 3:
            p = copy / "outputs/identifier_resolution.csv"; rows = read_rows(p); next(x for x in rows if x["UID"] == "Q8EFP8")["distinct_observation_taxon_IDs"] = ""; write_csv(p, list(rows[0]), rows)
        elif index == 4:
            p = copy / "requirements/requirement_to_evidence_matrix.json"; obj = strict_load(p); obj[8]["meaning"], obj[12]["meaning"] = obj[12]["meaning"], obj[8]["meaning"]; strict_dump(obj, p)
        else:
            p = copy / "outputs/rate_limit_observation.json"; obj = strict_load(p); obj["rate_limit_threshold"] = "UNLIMITED"; strict_dump(obj, p)
        proc = subprocess.run([sys.executable, str(validator), "--package-root", str(copy), "--inherited-d5", str(OLD_D5), "--inherited-d5a1", str(OLD_D5A1)], text=True, capture_output=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        seen = diagnostic in proc.stderr
        rejected = proc.returncode == 1 and seen
        matrix.append({"baseline_exit": baseline_exit, "test": name, "mutation": name, "exit_code": proc.returncode, "expected_diagnostic": diagnostic, "observed_expected_diagnostic": str(seen).lower(), "rejected": str(rejected).lower()})
        out_parts.append(f"## {name}\n{proc.stdout}")
        err_parts.append(f"## {name}\n{proc.stderr}")
    shutil.rmtree(base)
    write_csv(ROOT / "logs/negative_tests.csv", ["baseline_exit", "test", "mutation", "exit_code", "expected_diagnostic", "observed_expected_diagnostic", "rejected"], matrix)
    atomic_write(ROOT / "logs/negative_tests.stdout.txt", "\n".join(out_parts).encode())
    atomic_write(ROOT / "logs/negative_tests.stderr.txt", "\n".join(err_parts).encode())
    return sum(r["rejected"] == "true" for r in matrix), "\n".join(out_parts), "\n".join(err_parts)


def write_negative_not_run(baseline_exit: int, baseline_stderr: str) -> None:
    rows = [{"baseline_exit": baseline_exit, "test": name, "mutation": "NOT_RUN_BASELINE_INVALID", "exit_code": "NOT_RUN", "expected_diagnostic": diagnostic, "observed_expected_diagnostic": "false", "rejected": "false"} for name, diagnostic in [
        ("summary_status_200_to_404", "SUMMARY_STATUS_NOT_200"), ("blank_request_elapsed", "REQUEST_ELAPSED_MISSING"),
        ("remove_tax_id_values", "IDENTIFIER_TAX_ID_MISSING"), ("swap_R09_R13_meanings", "REQUIREMENT_MEANING_MISMATCH"),
        ("rate_UNKNOWN_to_UNLIMITED", "RATE_THRESHOLD_UNSUPPORTED")]]
    write_csv(ROOT / "logs/negative_tests.csv", ["baseline_exit", "test", "mutation", "exit_code", "expected_diagnostic", "observed_expected_diagnostic", "rejected"], rows)
    atomic_write(ROOT / "logs/negative_tests.stdout.txt", b"NOT_RUN_BASELINE_INVALID\n")
    atomic_write(ROOT / "logs/negative_tests.stderr.txt", (baseline_stderr + "\n").encode())


def run_validator(return_tar: Path | None = None, tar_identity: Path | None = None) -> tuple[int, str, str]:
    command = [sys.executable, str(ROOT / "scripts/validate_mt_d5a2.py"), "--package-root", str(ROOT), "--inherited-d5", str(OLD_D5), "--inherited-d5a1", str(OLD_D5A1)]
    if return_tar is not None and tar_identity is not None:
        command.extend(["--return-tar", str(return_tar), "--tar-identity", str(tar_identity)])
    proc = subprocess.run(command, text=True, capture_output=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    return proc.returncode, proc.stdout, proc.stderr


def modes() -> None:
    for p in ROOT.rglob("*"):
        if p.is_dir():
            p.chmod(0o755)
        elif p.is_file():
            p.chmod(0o755 if p.parent.name == "scripts" and p.suffix == ".py" else 0o644)


def manifest() -> tuple[int, str, int]:
    p = ROOT / "MANIFEST.sha256"
    files = sorted(x for x in ROOT.rglob("*") if x.is_file() and x != p)
    data = "".join(f"{digest(x)[1]}  {rel(x)}\n" for x in files).encode()
    atomic_write(p, data)
    p.chmod(0o644)
    return len(data), sha_bytes(data), len(files) + 1


def build_tar(final_token: str, manifest_bytes: int, manifest_sha: str, regular_count: int) -> tuple[int, str]:
    top = ROOT.name
    with tarfile.open(RETURN_TAR, "w", format=tarfile.PAX_FORMAT) as tf:
        root_info = tarfile.TarInfo(top); root_info.type = tarfile.DIRTYPE; root_info.mode = 0o755; root_info.mtime = 0; root_info.uid = root_info.gid = 0; root_info.uname = root_info.gname = ""; tf.addfile(root_info)
        for p in sorted(ROOT.rglob("*"), key=lambda x: str(x.relative_to(ROOT))):
            arc = f"{top}/{p.relative_to(ROOT)}"
            info = tarfile.TarInfo(arc); info.mtime = 0; info.uid = info.gid = 0; info.uname = info.gname = ""
            if p.is_dir():
                info.type = tarfile.DIRTYPE; info.mode = 0o755; tf.addfile(info)
            elif p.is_file():
                info.size = p.stat().st_size; info.mode = 0o755 if p.parent.name == "scripts" and p.suffix == ".py" else 0o644
                with p.open("rb") as fh: tf.addfile(info, fh)
            else:
                raise RuntimeError(f"UNSUPPORTED_TAR_MEMBER {p}")
    tar_bytes, tar_sha = digest(RETURN_TAR)
    atomic_write(TAR_IDENTITY, (f"final_token={final_token}\nreturn_path={ROOT}\ntar_path={RETURN_TAR}\ntar_bytes={tar_bytes}\ntar_sha256={tar_sha}\nmanifest_bytes={manifest_bytes}\nmanifest_sha256={manifest_sha}\nregular_file_count={regular_count}\ntop_level_member={top}\n").encode())
    with tarfile.open(RETURN_TAR, "r:") as tf:
        seen = set()
        members = tf.getmembers()
        for m in members:
            if m.name in seen or m.name.startswith("/") or ".." in Path(m.name).parts or m.issym() or m.islnk() or not (m.isfile() or m.isdir()):
                raise RuntimeError(f"TAR_SAFETY_FAILURE {m.name}")
            seen.add(m.name)
            if m.uid != 0 or m.gid != 0 or m.mtime != 0:
                raise RuntimeError(f"TAR_METADATA_FAILURE {m.name}")
            expected_mode = 0o755 if m.isdir() or (m.name.endswith(".py") and "/scripts/" in m.name) else 0o644
            if m.mode != expected_mode:
                raise RuntimeError(f"TAR_MODE_FAILURE {m.name} {oct(m.mode)}")
        manifest_member = tf.extractfile(f"{top}/MANIFEST.sha256")
        if manifest_member is None or sha_bytes(manifest_member.read()) != manifest_sha:
            raise RuntimeError("TAR_MANIFEST_IDENTITY_FAILURE")
        manifest_text = (ROOT / "MANIFEST.sha256").read_text().splitlines()
        for line in manifest_text:
            sha, name = line.split("  ", 1)
            extracted = tf.extractfile(f"{top}/{name}")
            if extracted is None or sha_bytes(extracted.read()) != sha:
                raise RuntimeError(f"TAR_BODY_MANIFEST_MISMATCH {name}")
    return tar_bytes, tar_sha


def ensure_collection_tables(rec: Recorder, old_cov: dict[str, dict]) -> None:
    if not (ROOT / "outputs/query_manifest.csv").is_file():
        rec.flush()
    if not (ROOT / "outputs/summary_http_provenance.csv").is_file():
        write_csv(ROOT / "outputs/summary_http_provenance.csv", ["order", "UID", "query", "rank", "request_id", "http_status", "utc_start", "utc_end", "elapsed_seconds", "content_type", "strict_json", "top_level_list_of_objects", "body_bytes", "body_sha256", "summary_record_count", "old_body_sha256", "raw_sha256_equal_to_inherited", "semantic_json_equal_to_inherited", "raw_body_path", "raw_headers_path"], [])
    if not (ROOT / "outputs/sample_interface_coverage.csv").is_file():
        write_csv(ROOT / "outputs/sample_interface_coverage.csv", ["order", "UID", "fixed_query", "collection_class", "inherited_autocomplete_state", "candidate_count", "taxon_page_HTTP_status", "summary_HTTP_status", "summary_strict_JSON", "summary_record_count", "observation_row_total", "observation_collection_state", "raw_sample_path"], [{"order": order, "UID": uid, "fixed_query": query, "collection_class": "NOT_COLLECTED_BLOCKED", "inherited_autocomplete_state": old_cov[uid].get("unique_exact_match", ""), "candidate_count": old_cov[uid].get("candidate_count", ""), "taxon_page_HTTP_status": "NOT_COLLECTED_BLOCKED", "summary_HTTP_status": "NOT_COLLECTED_BLOCKED", "summary_strict_JSON": "false", "summary_record_count": 0, "observation_row_total": 0, "observation_collection_state": "NOT_COLLECTED_BLOCKED", "raw_sample_path": ""} for order, uid, query in QUERY_PLAN])
    if not (ROOT / "outputs/stability_repeat.csv").is_file():
        write_csv(ROOT / "outputs/stability_repeat.csv", ["repeat", "UID", "query", "rank", "status", "utc_start", "utc_end", "elapsed_seconds", "body_bytes", "body_sha256", "content_type", "etag", "last_modified", "cache_control", "retry_after", "rate_limit_headers", "strict_json", "semantic_equal_to_repeat_1", "raw_body_path", "raw_headers_path"], [])


def finalize_existing() -> int:
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    verify_old_gate()
    if (ROOT / "MANIFEST.sha256").exists() or RETURN_TAR.exists() or TAR_IDENTITY.exists():
        raise ClientImplementationFailure("FINALIZE_EXISTING_REQUIRES_ABSENT_MANIFEST_AND_TRANSPORT")
    if (ROOT / "FINAL_STATUS.txt").read_text(encoding="utf-8").strip() != READY:
        raise ClientImplementationFailure("FINALIZE_EXISTING_READY_TOKEN_MISSING")
    rc, stdout, stderr = run_validator()
    if rc != 0:
        raise ClientImplementationFailure(f"FINALIZE_EXISTING_VALIDATOR_INVALID {stderr}")
    atomic_write(ROOT / "logs/validator.stdout.txt", stdout.encode())
    atomic_write(ROOT / "logs/validator.stderr.txt", stderr.encode())
    atomic_write(ROOT / "logs/validator.exit_code.txt", b"0\n")
    atomic_write(ROOT / "logs/final_executor_exit_code.txt", b"0\n")
    modes()
    manifest_bytes, manifest_sha, regular_count = manifest()
    rc2, stdout2, stderr2 = run_validator()
    if rc2 != 0 or stdout2 != stdout or stderr2 != stderr:
        raise ClientImplementationFailure(f"FINALIZE_EXISTING_POST_MANIFEST_INVALID {stderr2}")
    tar_bytes, tar_sha = build_tar(READY, manifest_bytes, manifest_sha, regular_count)
    rc3, stdout3, stderr3 = run_validator(RETURN_TAR, TAR_IDENTITY)
    if rc3 != 0 or stdout3 != stdout or stderr3 != stderr:
        raise ClientImplementationFailure(f"FINALIZE_EXISTING_TRANSPORT_INVALID {stderr3}")
    atomic_write(WORK / "completion_summary.json", (json.dumps({"final_token": READY, "blocker": "", "finalize_existing_no_network": True, "baseline_validator_exit": 0, "final_validator_exit": 0, "negative_tests_rejected": 5, "manifest_sha256": manifest_sha, "regular_file_count": regular_count, "tar_bytes": tar_bytes, "tar_sha256": tar_sha}, allow_nan=False, sort_keys=True) + "\n").encode())
    return 0


def main() -> int:
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    d5_map, a1_map, d5_tar, a1_tar = verify_old_gate()
    initialize(d5_map, a1_map, d5_tar, a1_tar)
    mapping, api_rows, old_cov = verified_inherited_science()
    rec = Recorder()
    final_token = BLOCKED_NETWORK
    blocker = ""
    samples = []
    observations = {}
    stability_rows = []
    nrm = total = 0
    conflicts = []
    collection_exit = 1
    collection_stderr = ""
    try:
        try:
            handler_preflight()
            if not preflight():
                raise CanaryNetworkFailure("DIRECT_VERIFIED_TLS_PREFLIGHT_FAILED")
            samples, observations = collect(rec, old_cov)
            stability_rows = stability(rec, samples)
            collection_exit = 0
        except ClientImplementationFailure as exc:
            final_token = BLOCKED_CLIENT
            blocker = f"{type(exc).__name__}: {exc}"
            collection_stderr = blocker
        except CanaryNetworkFailure as exc:
            final_token = BLOCKED_NETWORK
            blocker = f"{type(exc).__name__}: {exc}"
            collection_stderr = blocker
        except Exception as exc:
            final_token = BLOCKED_CLIENT
            blocker = f"UNEXPECTED_LOCAL_CLIENT_EXCEPTION {type(exc).__name__}: {exc}"
            collection_stderr = blocker
        finally:
            rec.close_all()
        ensure_collection_tables(rec, old_cov)
        if not (ROOT / "evidence/network_dns_tls_preflight.txt").is_file():
            atomic_write(ROOT / "evidence/network_dns_tls_preflight.txt", b"tls_result=NOT_RUN_CLIENT_PREFLIGHT_FAILED\n")
        nrm, total, conflicts = analyze(samples, observations, mapping)
        identifiers_and_mapping(mapping, old_cov, observations)
        rate = rate_output(rec)
        cleanup_and_scope(rec)
        write_matrix_report(samples, observations, stability_rows, rate, nrm, total, conflicts, api_rows, transport_final=False)
        atomic_write(ROOT / "logs/probe.stdout.txt", ("MT_D5A2 collection stage completed.\n" if collection_exit == 0 else "MT_D5A2 collection stage blocked.\n").encode())
        atomic_write(ROOT / "logs/probe.stderr.txt", (collection_stderr + ("\n" if collection_stderr else "")).encode())
        atomic_write(ROOT / "logs/probe.exit_code.txt", f"{collection_exit}\n".encode())

        baseline_rc, baseline_stdout, baseline_stderr = run_validator()
        if baseline_rc == 0:
            rejected, _, _ = negative_tests(baseline_rc)
        else:
            rejected = 0
            write_negative_not_run(baseline_rc, baseline_stderr)
            if collection_exit == 0:
                final_token = BLOCKED_SCOPE
                blocker = f"BASELINE_VALIDATOR_INVALID: {baseline_stderr.strip()}"
        success = sum(s["success"] for s in samples) == 5
        obs_ok = len(observations) == 2 and all(x.get("valid") for x in observations.values())
        stable = len(stability_rows) == 3 and all(r["status"] == "200" and r["strict_json"] == "true" for r in stability_rows)
        if baseline_rc == 0 and rejected == 5 and success and obs_ok and stable:
            final_token = READY
            blocker = ""
        elif collection_exit == 0 and final_token != BLOCKED_SCOPE:
            final_token = BLOCKED_NETWORK
            blocker = f"required_current_evidence summaries={sum(s['success'] for s in samples)}/5 observations={sum(bool(x.get('valid')) for x in observations.values())}/2 stability={len(stability_rows)}/3"

        write_matrix_report(samples, observations, stability_rows, rate, nrm, total, conflicts, api_rows, transport_final=True)
        atomic_write(ROOT / "FINAL_STATUS.txt", (final_token + "\n").encode())
        expected_executor_exit = 0 if final_token == READY else 1
        atomic_write(ROOT / "logs/final_executor_exit_code.txt", f"{expected_executor_exit}\n".encode())
        final_rc, final_stdout, final_stderr = run_validator()
        atomic_write(ROOT / "logs/validator.stdout.txt", final_stdout.encode())
        atomic_write(ROOT / "logs/validator.stderr.txt", final_stderr.encode())
        atomic_write(ROOT / "logs/validator.exit_code.txt", f"{final_rc}\n".encode())
        if final_token == READY and final_rc != 0:
            raise ClientImplementationFailure(f"FINAL_VALIDATOR_INVALID {final_stderr}")

        modes()
        manifest_bytes, manifest_sha, regular_count = manifest()
        rc2, stdout2, stderr2 = run_validator()
        if rc2 != final_rc or stdout2 != final_stdout or stderr2 != final_stderr:
            raise ClientImplementationFailure(f"POST_MANIFEST_VALIDATOR_CHANGED rc={rc2} stderr={stderr2}")
        tar_bytes, tar_sha = build_tar(final_token, manifest_bytes, manifest_sha, regular_count)
        rc3, stdout3, stderr3 = run_validator(RETURN_TAR, TAR_IDENTITY)
        if rc3 != final_rc or stdout3 != final_stdout or stderr3 != final_stderr:
            raise ClientImplementationFailure(f"TRANSPORT_VALIDATOR_CHANGED rc={rc3} stderr={stderr3}")
        atomic_write(WORK / "completion_summary.json", (json.dumps({"final_token": final_token, "blocker": blocker, "handler_preflight": strict_load(ROOT / "outputs/https_handler_preflight.json").get("result"), "baseline_validator_exit": baseline_rc, "final_validator_exit": final_rc, "negative_tests_rejected": rejected, "manifest_sha256": manifest_sha, "regular_file_count": regular_count, "tar_bytes": tar_bytes, "tar_sha256": tar_sha}, allow_nan=False, sort_keys=True) + "\n").encode())
        return expected_executor_exit
    finally:
        rec.close_all()


if __name__ == "__main__":
    raise SystemExit(finalize_existing() if "--finalize-existing" in sys.argv[1:] else main())

#!/usr/bin/env python3
"""Portable, read-only validator for the MT-D5A1 correction package."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import stat
import sys
from pathlib import Path

OLD_MANIFEST_SHA256 = "9f646442d7ccd8ac24de4feb446825309059a92be8ca9d5d60b3d002edcb9503"
UIDS = ["Q8EFP8", "Q12WS1", "A0A0H3C8X0", "P29931", "Q6BQK1", "P71875", "S5SC42", "P76113", "C8WLM1", "Q02198"]
PLAN = [
    ("1", "Q8EFP8", "Shewanella oneidensis", "species", "0d0eeecd9b5cd6314d71e680119b5fd155fac2980f59581436501ed2f42d0604"),
    ("2", "Q12WS1", "Methanococcoides burtonii", "species", "c3da972bb5214ef65f9631b48882dbd8eec96e2ebe0edb38901856ae96ec9e6b"),
    ("3", "A0A0H3C8X0", "Caulobacter vibrioides", "species", "99ca0fb51622ba9d30eba9befabe6e90f96750eac96f1af31f8638807479a0e5"),
    ("5", "Q6BQK1", "Debaryomyces hansenii", "species", "28b4e749f70dafba8ad5ccf5c1948ce9ce8623709959687c4ebfd718ca1f8735"),
    ("6", "P71875", "Mycobacterium tuberculosis", "species", "414606627724f0ada3dcbc5be618291d94378fa60b0756e9dd62741fd4faa202"),
]
MEANINGS = [
    ("MTD5-R01", "accepted V1 input identity"),
    ("MTD5-R02", "deterministic P0 enzyme selection"),
    ("MTD5-R03", "P0-derived organism and raw UniProt evidence"),
    ("MTD5-R04", "UniProt/KEGG mapping coverage and boundaries"),
    ("MTD5-R05", "official MetaTraits surface inventory"),
    ("MTD5-R06", "documented API bounded probe"),
    ("MTD5-R07", "bounded website summary and source-provenance behavior"),
    ("MTD5-R08", "at least five HTTP-200 strict JSON summaries"),
    ("MTD5-R09", "three-repeat stability and bounded rate observation"),
    ("MTD5-R10", "identifier and taxonomic resolution"),
    ("MTD5-R11", "wastewater trait coverage"),
    ("MTD5-R12", "No robust majority and source conflicts"),
    ("MTD5-R13", "evidence-semantics audit"),
    ("MTD5-R14", "documentation/license/version/pagination/rate-policy contract"),
    ("MTD5-R15", "research-only scope compliance"),
    ("MTD5-R16", "independently auditable directory/tar/identity package"),
]
ALLOWED_STATUS = {"PASS_EVIDENCE_COMPLETE", "MISSING_REQUIRED_EVIDENCE", "NOT_COLLECTED_BLOCKED", "EXPLICITLY_OUTSIDE_CORRECTED_TEACHER_SCOPE"}


def digest(path: Path) -> tuple[int, str]:
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            size += len(block)
            h.update(block)
    return size, h.hexdigest()


def strict_load(path: Path):
    def bad(value):
        raise ValueError(f"non-finite JSON constant {value}")
    with path.open(encoding="utf-8") as fh:
        return json.load(fh, parse_constant=bad)


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def summary_records(obj):
    if isinstance(obj, list) and all(isinstance(x, dict) for x in obj):
        return obj
    raise ValueError("summary is not a list of objects")


def fail(errors: list[str], code: str, detail: str = "") -> None:
    errors.append(code + (": " + detail if detail else ""))


def discover_inherited(root: Path) -> Path | None:
    for p in root.parent.iterdir() if root.parent.is_dir() else []:
        if p.is_dir() and p != root and (p / "MANIFEST.sha256").is_file():
            try:
                if digest(p / "MANIFEST.sha256")[1] == OLD_MANIFEST_SHA256:
                    return p
            except OSError:
                pass
    return None


def validate(root: Path, inherited: Path | None) -> list[str]:
    errors: list[str] = []
    required = [
        "MT_D5A1_CORRECTION_REPORT.md", "inputs/inherited_package_identity.json",
        "inputs/inherited_file_identity.csv", "inputs/five_sample_completion_plan.csv",
        "outputs/query_manifest.csv", "outputs/summary_http_provenance.csv",
        "outputs/sample_interface_coverage.csv", "outputs/stability_repeat.csv",
        "outputs/rate_limit_observation.json", "outputs/identifier_resolution.csv",
        "outputs/mapping_reconciliation.json", "outputs/no_robust_majority_summary.csv",
        "outputs/wastewater_trait_coverage.csv", "outputs/wastewater_trait_matches.json",
        "outputs/source_conflict_examples.json", "outputs/evidence_semantics_audit.json",
        "outputs/scope_compliance.json", "outputs/execution_repair_log.json",
        "requirements/requirement_to_evidence_matrix.json", "scripts/mt_d5a1_completion.py",
        "scripts/validate_mt_d5a1.py", "evidence/environment.txt",
        "evidence/network_dns_tls_preflight.txt", "evidence/work_root_after_cleanup.txt",
    ]
    for rel in required:
        if not (root / rel).is_file():
            fail(errors, "REQUIRED_FILE_MISSING", rel)

    for p in root.rglob("*") if root.is_dir() else []:
        try:
            st = p.lstat()
        except OSError as exc:
            fail(errors, "FILE_STAT_FAILED", f"{p}: {exc}")
            continue
        if stat.S_ISLNK(st.st_mode) or (not stat.S_ISREG(st.st_mode) and not stat.S_ISDIR(st.st_mode)):
            fail(errors, "UNSUPPORTED_FILE_TYPE", str(p.relative_to(root)))
        if stat.S_ISREG(st.st_mode) and st.st_size > 50 * 1024 * 1024:
            fail(errors, "FILE_TOO_LARGE", str(p.relative_to(root)))
        if stat.S_ISREG(st.st_mode) and any(x in p.name.casefold() for x in ["cookie", "credential", "__pycache__", ".pyc"]):
            fail(errors, "PROHIBITED_ARTIFACT", str(p.relative_to(root)))
    if errors and any(x.startswith("REQUIRED_FILE_MISSING") for x in errors):
        return errors

    try:
        ident = strict_load(root / "inputs/inherited_package_identity.json")
        if ident.get("manifest_sha256") != OLD_MANIFEST_SHA256 or ident.get("regular_file_count") != 401 or ident.get("manifest_check_result") != "PASS_ALL_LISTED_MEMBERS":
            fail(errors, "INHERITED_MANIFEST_IDENTITY_MISMATCH")
        if inherited is None or not (inherited / "MANIFEST.sha256").is_file() or digest(inherited / "MANIFEST.sha256")[1] != OLD_MANIFEST_SHA256:
            fail(errors, "INHERITED_ROOT_IDENTITY_MISMATCH")
    except Exception as exc:
        fail(errors, "INHERITED_IDENTITY_INVALID", str(exc))

    try:
        copied = read_rows(root / "inputs/inherited_file_identity.csv")
        if len(copied) != 18:
            fail(errors, "COPIED_FILE_IDENTITY_COUNT", str(len(copied)))
        for row in copied:
            cp = root / row["copied_path"]
            if row.get("equality") != "true" or not cp.is_file() or digest(cp)[1] != row.get("copied_sha256") or row.get("source_sha256") != row.get("copied_sha256"):
                fail(errors, "COPIED_FILE_IDENTITY_MISMATCH", row.get("copied_path", ""))
    except Exception as exc:
        fail(errors, "COPIED_FILE_IDENTITY_INVALID", str(exc))

    try:
        plan = read_rows(root / "inputs/five_sample_completion_plan.csv")
        observed = [(r["order"], r["UID"], r["query"], r["rank"], r["old_summary_sha256"]) for r in plan]
        if observed != PLAN:
            fail(errors, "FIXED_SAMPLE_PLAN_MISMATCH")
    except Exception as exc:
        fail(errors, "FIXED_SAMPLE_PLAN_INVALID", str(exc))

    ledger: list[dict[str, str]] = []
    by_body: dict[str, dict[str, str]] = {}
    try:
        ledger = read_rows(root / "outputs/query_manifest.csv")
        ids = [r.get("request_id", "") for r in ledger]
        expected = [f"D5A1_REQ{i:03d}" for i in range(1, len(ledger) + 1)]
        if ids != expected or len(ids) != len(set(ids)) or len(ids) > 40:
            fail(errors, "REQUEST_ID_OR_CAP_INVALID")
        required_fields = ["utc_start", "utc_end", "method", "url", "user_agent", "attempt", "elapsed_seconds", "response_headers_path", "response_body_path", "response_body_bytes", "response_body_sha256"]
        for row in ledger:
            rid = row.get("request_id", "")
            if any(not row.get(k, "") for k in required_fields):
                if not row.get("elapsed_seconds", ""):
                    fail(errors, "REQUEST_ELAPSED_MISSING", rid)
                else:
                    fail(errors, "REQUEST_METADATA_INCOMPLETE", rid)
            if bool(row.get("http_status")) == bool(row.get("network_exception")):
                fail(errors, "REQUEST_STATUS_EXCEPTION_INVALID", rid)
            try:
                float(row.get("elapsed_seconds", ""))
                int(row.get("response_body_bytes", ""))
            except ValueError:
                fail(errors, "REQUEST_NUMERIC_METADATA_INVALID", rid)
            for key, hash_key, size_key in [("response_body_path", "response_body_sha256", "response_body_bytes"), ("response_headers_path", "response_headers_sha256", "response_headers_bytes")]:
                p = root / row.get(key, "")
                if not p.is_file():
                    fail(errors, "REQUEST_EVIDENCE_FILE_MISSING", f"{rid} {key}")
                else:
                    size, sha = digest(p)
                    if sha != row.get(hash_key) or str(size) != row.get(size_key):
                        fail(errors, "REQUEST_EVIDENCE_IDENTITY_MISMATCH", f"{rid} {key}")
            by_body[row.get("response_body_path", "")] = row
    except Exception as exc:
        fail(errors, "REQUEST_LEDGER_INVALID", str(exc))

    summaries: list[tuple[dict[str, str], list[dict]]] = []
    try:
        prov = read_rows(root / "outputs/summary_http_provenance.csv")
        if len(prov) != 5:
            fail(errors, "SUMMARY_PROVENANCE_COUNT", str(len(prov)))
        for row in prov:
            if row.get("http_status") != "200":
                fail(errors, "SUMMARY_STATUS_NOT_200", row.get("UID", ""))
            if row.get("strict_json") != "true" or row.get("top_level_list_of_objects") != "true":
                fail(errors, "SUMMARY_STRICT_JSON_INVALID", row.get("UID", ""))
            if "json" not in row.get("content_type", "").casefold():
                fail(errors, "SUMMARY_CONTENT_TYPE_INVALID", row.get("UID", ""))
            p = root / row["raw_body_path"]
            obj = summary_records(strict_load(p))
            size, sha = digest(p)
            if str(size) != row.get("body_bytes") or sha != row.get("body_sha256"):
                fail(errors, "SUMMARY_BODY_IDENTITY_MISMATCH", row.get("UID", ""))
            led = by_body.get(row["raw_body_path"])
            if led is None or led.get("http_status") != "200" or led.get("response_body_sha256") != sha:
                fail(errors, "SUMMARY_LEDGER_BINDING_INVALID", row.get("UID", ""))
            if str(len(obj)) != row.get("summary_record_count"):
                fail(errors, "SUMMARY_COUNT_MISMATCH", row.get("UID", ""))
            summaries.append((row, obj))
    except Exception as exc:
        fail(errors, "SUMMARY_PROVENANCE_INVALID", str(exc))

    try:
        coverage = read_rows(root / "outputs/sample_interface_coverage.csv")
        if len(coverage) != 10 or [r.get("UID") for r in coverage] != UIDS:
            fail(errors, "SAMPLE_INTERFACE_TEN_ROW_INVALID")
        if sum(r.get("collection_class") == "D5A1_NEW" and r.get("summary_HTTP_status") == "200" for r in coverage) != 5:
            fail(errors, "SAMPLE_INTERFACE_SUCCESS_COUNT_INVALID")
    except Exception as exc:
        fail(errors, "SAMPLE_INTERFACE_INVALID", str(exc))

    try:
        repeats = read_rows(root / "outputs/stability_repeat.csv")
        if len(repeats) != 3 or [r.get("repeat") for r in repeats] != ["1", "2", "3"]:
            fail(errors, "STABILITY_ROW_COUNT_INVALID")
        first_obj = None
        for idx, row in enumerate(repeats):
            if row.get("status") != "200" or row.get("strict_json") != "true":
                fail(errors, "STABILITY_STATUS_OR_JSON_INVALID", row.get("repeat", ""))
            for k in ["utc_start", "utc_end", "elapsed_seconds", "body_bytes", "body_sha256", "content_type", "raw_body_path", "raw_headers_path"]:
                if not row.get(k, ""):
                    fail(errors, "STABILITY_METADATA_INCOMPLETE", f"{row.get('repeat')} {k}")
            p = root / row["raw_body_path"]
            obj = strict_load(p)
            if digest(p)[1] != row.get("body_sha256"):
                fail(errors, "STABILITY_HASH_MISMATCH", row.get("repeat", ""))
            if idx == 0:
                first_obj = obj
            expected_equal = "true" if obj == first_obj else "false"
            if row.get("semantic_equal_to_repeat_1") != expected_equal:
                fail(errors, "STABILITY_SEMANTIC_MISMATCH", row.get("repeat", ""))
    except Exception as exc:
        fail(errors, "STABILITY_INVALID", str(exc))

    try:
        rate = strict_load(root / "outputs/rate_limit_observation.json")
        if rate.get("rate_limit_threshold") != "UNKNOWN":
            fail(errors, "RATE_THRESHOLD_UNSUPPORTED")
        d5 = rate.get("d5a1", {})
        if d5.get("total_attempts") != len(ledger):
            fail(errors, "RATE_ATTEMPT_COUNT_MISMATCH")
        observed_429 = sum(r.get("http_status") == "429" for r in ledger)
        if d5.get("http_429_count") != observed_429 or rate.get("old_package", {}).get("total_old_http_429") != "UNKNOWN":
            fail(errors, "RATE_EVIDENCE_CLASS_INVALID")
    except Exception as exc:
        fail(errors, "RATE_JSON_INVALID", str(exc))

    try:
        idrows = read_rows(root / "outputs/identifier_resolution.csv")
        if len(idrows) != 10 or [r.get("UID") for r in idrows] != UIDS:
            fail(errors, "IDENTIFIER_TEN_ROW_INVALID")
        minimum = {"Q8EFP8": {"70863", "211586"}, "Q12WS1": {"259564"}, "Q6BQK1": {"284592", "1118155"}}
        for uid, need in minimum.items():
            row = next((x for x in idrows if x.get("UID") == uid), {})
            got = {x for x in row.get("distinct_observation_taxon_IDs", "").split(";") if x}
            if not need.issubset(got):
                fail(errors, "IDENTIFIER_TAX_ID_MISSING", uid)
    except Exception as exc:
        fail(errors, "IDENTIFIER_INVALID", str(exc))

    try:
        mapping = strict_load(root / "outputs/mapping_reconciliation.json")
        uni = mapping.get("uniprot_accession_resolution", {})
        kegg = mapping.get("kegg_conversion", {})
        if (uni.get("exact"), uni.get("missing")) != (10, 0) or (kegg.get("single"), kegg.get("missing"), kegg.get("multiple")) != (7, 1, 2):
            fail(errors, "MAPPING_DIMENSION_COUNTS_INVALID")
        if mapping.get("confidence_calculated") is not False or "confidence" in mapping.get("dimensions_merged", "").casefold():
            fail(errors, "MAPPING_DIMENSION_CONFLATION")
    except Exception as exc:
        fail(errors, "MAPPING_RECONCILIATION_INVALID", str(exc))

    try:
        nrows = read_rows(root / "outputs/no_robust_majority_summary.csv")
        if len(nrows) != 6:
            fail(errors, "NO_ROBUST_MAJORITY_ROW_COUNT_INVALID")
        total = nrm = 0
        for (provrow, records), row in zip(summaries, nrows[:5]):
            calc = sum(x.get("majority_label") == "No robust majority" for x in records)
            if row.get("UID") != provrow.get("UID") or int(row.get("total_summary_records", -1)) != len(records) or int(row.get("no_robust_majority_count", -1)) != calc:
                fail(errors, "NO_ROBUST_MAJORITY_UNREPRODUCIBLE", provrow.get("UID", ""))
            total += len(records)
            nrm += calc
        agg = nrows[-1]
        if agg.get("UID") != "AGGREGATE" or int(agg.get("total_summary_records", -1)) != total or int(agg.get("no_robust_majority_count", -1)) != nrm:
            fail(errors, "NO_ROBUST_MAJORITY_AGGREGATE_INVALID")
    except Exception as exc:
        fail(errors, "NO_ROBUST_MAJORITY_INVALID", str(exc))

    try:
        ww = strict_load(root / "outputs/wastewater_trait_matches.json")
        groups = ww.get("disclosed_matching_groups", {})
        cov = read_rows(root / "outputs/wastewater_trait_coverage.csv")
        if len(cov) != 5 * len(groups):
            fail(errors, "WASTEWATER_COVERAGE_ROW_COUNT_INVALID")
        lookup = {(r["UID"], r["category"]): r for r in cov}
        for provrow, records in summaries:
            for category, patterns in groups.items():
                names = sorted({str(x.get("name", "")) for x in records if str(x.get("name", "")) and any(re.search(p, str(x.get("name", "")), re.I) for p in patterns)})
                row = lookup.get((provrow["UID"], category), {})
                got = sorted(x for x in row.get("exact_matched_trait_names", "").split(";") if x)
                if names != got or int(row.get("matched_record_count", -1)) != sum(any(re.search(p, str(x.get("name", "")), re.I) for p in patterns) for x in records):
                    fail(errors, "WASTEWATER_COUNTS_UNREPRODUCIBLE", f"{provrow['UID']} {category}")
    except Exception as exc:
        fail(errors, "WASTEWATER_INVALID", str(exc))

    try:
        sem = strict_load(root / "outputs/evidence_semantics_audit.json")
        actual = set(sem.get("actual_observation_fields", []))
        if not {"database_record", "record_url", "tax_id", "trait", "value"}.issubset(actual) or sem.get("invented_three_state_field") is not False:
            fail(errors, "EVIDENCE_SEMANTICS_UNSUPPORTED")
        conflicts = strict_load(root / "outputs/source_conflict_examples.json")
        if not 0 <= conflicts.get("available_count", -1) <= 3 or conflicts.get("available_count") != len(conflicts.get("examples", [])):
            fail(errors, "SOURCE_CONFLICT_COUNT_INVALID")
    except Exception as exc:
        fail(errors, "EVIDENCE_SEMANTICS_INVALID", str(exc))

    try:
        matrix = strict_load(root / "requirements/requirement_to_evidence_matrix.json")
        if not isinstance(matrix, list) or len(matrix) != 16:
            fail(errors, "REQUIREMENT_MATRIX_COUNT_INVALID")
        else:
            for row, (rid, meaning) in zip(matrix, MEANINGS):
                if row.get("requirement_id") != rid or row.get("meaning") != meaning:
                    fail(errors, "REQUIREMENT_MEANING_MISMATCH", rid)
                if row.get("evidence_status") not in ALLOWED_STATUS:
                    fail(errors, "REQUIREMENT_STATUS_INVALID", rid)
                if row.get("evidence_status") == "PASS_EVIDENCE_COMPLETE" and not row.get("verified_now"):
                    fail(errors, "REQUIREMENT_VERIFICATION_FLAG_INVALID", rid)
    except Exception as exc:
        fail(errors, "REQUIREMENT_MATRIX_INVALID", str(exc))

    try:
        scope = strict_load(root / "outputs/scope_compliance.json")
        prohibited = ["gpu_requested_or_used", "checkpoint_inference_training_evaluation", "portraits_or_bulk_database_workflow", "production_implementation", "credentials_packaged", "cookie_files_remaining"]
        if any(scope.get(k) is not False for k in prohibited):
            fail(errors, "SCOPE_COMPLIANCE_INVALID")
    except Exception as exc:
        fail(errors, "SCOPE_JSON_INVALID", str(exc))

    neg = root / "logs/negative_tests.csv"
    if neg.exists():
        try:
            nr = read_rows(neg)
            if len(nr) != 5 or sum(r.get("rejected") == "true" and r.get("exit_code") == "1" and r.get("observed_expected_diagnostic") == "true" for r in nr) != 5:
                fail(errors, "NEGATIVE_TESTS_NOT_ALL_REJECTED")
        except Exception as exc:
            fail(errors, "NEGATIVE_TEST_LOG_INVALID", str(exc))

    final = root / "FINAL_STATUS.txt"
    if final.exists():
        token = final.read_text(encoding="utf-8").strip()
        if token == "MT_D5A1_READY_FOR_LOCAL_AUDIT_DOCUMENTED_API_UNAVAILABLE":
            try:
                matrix = strict_load(root / "requirements/requirement_to_evidence_matrix.json")
                if any(r.get("evidence_status") != "PASS_EVIDENCE_COMPLETE" for r in matrix):
                    fail(errors, "READY_TOKEN_UNSUPPORTED_BY_MATRIX")
            except Exception:
                fail(errors, "READY_TOKEN_MATRIX_INVALID")

    manifest = root / "MANIFEST.sha256"
    if manifest.exists():
        expected: dict[str, str] = {}
        for line in manifest.read_text(encoding="utf-8").splitlines():
            if not line:
                continue
            try:
                sha, rel = line.split("  ", 1)
            except ValueError:
                fail(errors, "MANIFEST_LINE_INVALID", line)
                continue
            if rel in expected:
                fail(errors, "MANIFEST_DUPLICATE_PATH", rel)
            expected[rel] = sha
        actual = sorted(str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and p != manifest)
        if sorted(expected) != actual:
            fail(errors, "MANIFEST_FILE_SET_MISMATCH")
        for rel, sha in expected.items():
            p = root / rel
            if p.is_file() and digest(p)[1] != sha:
                fail(errors, "MANIFEST_HASH_MISMATCH", rel)
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--inherited-root", type=Path)
    args = parser.parse_args()
    root = args.package_root.resolve()
    inherited = args.inherited_root.resolve() if args.inherited_root else discover_inherited(root)
    errors = validate(root, inherited)
    if errors:
        for item in errors:
            print(item, file=sys.stderr)
        return 1
    print("MT_D5A1_VALIDATION_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
